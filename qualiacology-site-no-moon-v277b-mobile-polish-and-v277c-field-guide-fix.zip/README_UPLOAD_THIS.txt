Qualiacology site — v277b risen-walkers (mobile polish + boss-arena phasing)
                   + v277c field-guide boss-card persistence repair (Archon, Sun)

Upload contents to site root. Layered on top of the prior v277 risen-walkers
bundle. Two No Moon patches in this bundle:

================================================================================
1. NO MOON v277b — risen walkers, mobile polish + boss-arena phasing
================================================================================

Build tag:  qual.v277b-risen-walkers-mobile-polish.2026-05-24.v277b
Cache key:  no-moon-v277b-risen-walkers-mobile-polish-v277b

Why this patch:
   Mobile play feedback on v277/ChatGPT-v276 showed three problems:
   (a) bodies woke too fast — felt like instant pops, not a slow rise
   (b) the standing enemy was much smaller and shaped totally different from
       the prone body, so the transition felt like a swap rather than a rise
   (c) in the First Walker arena, all bodies rose at once + the boss = chaos,
       and the player reported odd flashes during the boss fight

What changed (vs v277):

   Timing — slower, more deliberate.
   - Pre-rise breath:           1.4s normal rooms, 2.0s Buried Habitat
                                (was 0.95s / 1.45s)
   - Per-body stagger:          0–1.5s after the breath  (was 0–0.55s)
   - Rise duration per body:    3.0s                     (was 1.15s)
   So total quickest body =     1.4s + 0s + 3.0s = 4.4s before first attack
       slowest body in arena =  2.0s + 1.5s + 3.0s = 6.5s before first attack

   Standing astronaut is bigger.
   - r=22 (was r=18). Draw scales by 1.4× so the on-screen footprint is
     roughly 70 × 80 px, much closer to the prone body's ~90 × 90 px.
     The transition reads as "the same astronaut stood up", not "small new
     thing appeared".

   Rising animation has three visual phases over the 3 seconds.
   - 0.00–0.50s: under-glow blooms beneath the body; a few cyan sparks orbit
   - 0.50–1.00s: standing-ghost silhouette starts forming above the prone
                 body, scaling up from 0.55× to 1.40× as it rises ~26 px
   - 1.00–3.00s: ghost reaches full size; visor pinprick saturates
   At t=3.0s the prone body is filtered out of the v262 render pass and the
   real standing astronaut enemy takes over.

   Boss-arena phased wakes.
   - On entry, only ARENA_INITIAL_WAKES (=2) bodies are queued to rise.
   - When the First Walker drops below 60% HP, 2 more queue.
   - When the First Walker drops below 30% HP, all remaining queue.
   - Cap on concurrent risen walkers in the arena: 5
   - Cap in normal Drowned Sky rooms: 3
   So the boss fight stays readable: you face the boss plus a small ring of
   risen walkers, and the threat ramps with the boss's own phase escalation
   rather than spiking on entry.

   Other polish.
   - Ceiling-hung astronaut suits stay decorative — they don't wake. A
     hanging-from-the-ceiling corpse standing up just looked wrong.
   - The freshly-spawned standing enemy has 0.5s of damage invulnerability,
     enforced both as e.hitInvuln and as a damageEnemy wrap returning false.
     (Previously hit-invuln alone could be edge-cased.)
   - Spawning a risen walker now forces room.cleared = false and
     state.level.cleared = false so doors snap shut if the room had already
     auto-cleared (this matters for "path" Drowned Sky rooms that start with
     no initial enemies).
   - renderWorld stash/restore wraps in try/finally — a base-render throw
     can no longer permanently strand the room's remains array filtered.
   - State scrubbed on every fresh Descend (per-room wake flags + per-body
     queue/rising/risen flags wiped in the startGame wrap).

   Console:
       noMoonCurrentSelfTest()    -> ok: true, points at v277b
       noMoonV277SelfTest()       -> same data
       noMoonV277Debug()          -> per-room status, timings, active count
       noMoonV277bDebug()         -> alias

================================================================================
2. NO MOON v277c — Field Guide boss-card persistence repair
================================================================================

Build tag:  qual.v277c-boss-card-persist.2026-05-24.v277c
            (informational — v277b tag wins the HUD banner)

Why this patch:
   Diagnosis of the "field guide cards aren't showing up after I beat the
   last 3" report revealed that the two main-route end-boss cards in the
   base v71 BOSS_CARDS71 deck — Archon and Sun — never write their defeats
   to save.defeatedBosses. There's no persistence code for them at all.
   The Field Guide reveal check (bossSaveSet71 at line 41271) merges
   save.defeatedBosses + mirror.defeatedBosses, so without the write the
   cards stay locked forever, no matter how many times you kill the bosses.

What this patch does:
   Wraps killEnemy. On kill, persists the matching defeatedBosses flag
   and calls safeWriteSave():

      typeId === 'archon'             -> save.defeatedBosses.archon = true
      typeId === 'sunCore' (or 'sun') -> save.defeatedBosses.sun = true

   Also adds an OPT-IN escape hatch for the First Walker QA-mode block at
   line 65777 (persistFirstWalkerDefeat returns false if any of three QA
   flags is set — _v259QaRunActive, _v260QaTrialMode, _v260QaEverActiveThisRun).
   That block is intentional and is NOT bypassed by default. To bypass it
   (so QA-augmented runs credit the First Walker too):

       state._v277cBypassQaForFirstWalker = true

   in the console. Set it before defeating the First Walker. With the
   bypass on, the v277c killEnemy wrap will persist
   save.defeatedBosses.firstWalker = true directly, side-stepping the QA
   guard.

   Drowned Sun was NOT touched. It already persists correctly via v81's
   recordDrownedSkyVictory80 at line 46428, and it has no QA guard.

   Console:
       noMoonV277cDebug() -> shows current save.defeatedBosses state and
                             whether the First Walker bypass is armed

================================================================================
QA path after upload
================================================================================

1. /clear.html -> Reset save AND clear cache. START -> Passenger -> Descend
   lands on Floor 1 (v275 hard-guard intact).

2. Open Field Guide on the title screen. Boss cards should all be locked
   on a fresh save.

3. Run any route to the final boss.
   - Beat Null Archon. Return to title. Open Field Guide. ARCHON CARD
     should now be revealed.  (v277c repair)
   - Or take the Sun Throne alt route, beat The Sun. The SUN CARD should
     now reveal.  (v277c repair)
   - Or take the Drowned Sky alt route. The First Walker arena should
     show 2 risen walkers on entry. Drop the boss below 60% HP — 2 more
     should rise. Drop to 30% — all remaining. Beat the boss + walkers.
     The DROWNED SUN card was already working; FIRST WALKER card requires
     not-in-QA-mode OR the bypass flag.

4. Mobile (the original complaint): the rise should now feel slow and
   deliberate. ~4–6 seconds from entering a room to the first walker
   standing. Standing astronaut should look mass-comparable to the prone
   body, not a small different thing. No flickering on top of the prone
   body (it's filtered out of the v262 render pass once fully risen).

5. noMoonCurrentSelfTest() should report v277b ok:true.
   noMoonV277cDebug().defeatedBosses should reflect any new persists.

================================================================================
Site content (unchanged from prior bundle)
================================================================================

- Vibrant visual pass on index.html + book.html (aurora, rainbow hero
  titles, breathing glows, blockquote gradient edges, card halos).
- Book figure scaffolding with the two infographics in place at
  assets/book/five-axis-framework.webp and
  assets/book/three-levels-understanding.webp.
- Discord URL = discord.gg/NwvxKxUJpC everywhere.
- Removed book sections preserved.
