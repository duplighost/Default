# No Moon v235 — Sun route flow + obstacle-quiet + drowned-sun arena fixes

Built on v234 (which keeps the QA tap zone for testing).

Build tag: qual.sun-flow-obstacle-quiet-arena.2026-05-17.v235
SW cache:  no-moon-sun-flow-obstacle-quiet-arena-v235

## Changes

1. **Obstacle explosions disabled**: damageObstacle is wrapped to suppress
   spawnRing/spawnSpark/shake/chainDamageEnemy/damagePlayer/addRoomHazard/
   the "volatile chain detonates" message during the call. Obstacles
   still take damage and break — they just don't blast/cascade/drop a
   hazard underneath. Kills the mobile slowdown trigger.

2. **Sun room: no hazards on the seal spots**: the sun boss
   (tickSunBoss39 phase 1) was adding a damaging pulse hazard ON the
   3 seal positions every 2.1 s. We wrap addRoomHazard so any hazard
   placed at a non-broken seal in a sun-throne room is dropped. The
   boss still fires its rings and bursts.

3. **Seal "STAND HERE" overlay**: renderWorld wrapped to draw a clear
   cyan diamond + downward arrow + "STAND HERE" text over each unbroken
   seal in the throne room. The seals no longer look like yellow oval
   hazards.

4. **Sun victory: open crater on first clear, no Return Sigil**:
   v77InstallSunVictoryObjects wrapped to force priorSunClears>=1
   (crater always opens). The Return Sigil ("go home" teleporter) is
   suppressed. Only the Drowned Sky portal remains.

5. **Drowned-Sun boss**:
   - Position clamped to (wall + r + 48) away from walls — no more
     corner-stuck.
   - Boss-room back door forced inactive while the boss is alive.
     Player cannot leave mid-fight.

6. **Cold Lantern prompt**: when the lantern appears after boss death,
   renderWorld draws a beam of light + glow + "TOUCH THE LANTERN"
   prompt above it so the player knows what to collect.

## Stack

v99 -> rebuilt -> v230 -> v233 (mobile=PC) -> v234 (QA tap) -> v235 (this)

## Console

  noMoonCurrentSelfTest()
  noMoonV235SelfTest()
  noMoonV235Debug()
  noMoonQAToSunBattle()   // from v234, still works
