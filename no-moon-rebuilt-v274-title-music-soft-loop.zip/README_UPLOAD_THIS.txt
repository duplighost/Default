No Moon v274 — title music soft loop

Upload the contents of this ZIP to the site root, preserving folders.

Stable checkpoint preserved:
- v269 mobile title / portrait / passenger-scroll fixes intact.
- v270 + v271 First Walker boss trophy / field guide intact.
- v272/v272b title video restore + decoder fix intact.
- v273 title toggle restore intact.
- Service worker registration remains disabled.
- The bad v265 Passenger List/front-door title branch is absent.

v274 additions:
- Soft-loop on the two title music m4a files. The audible content
  discontinuity at the loop boundary is now hidden inside a brief volume
  duck: volume tapers to 0 over the last 0.30s of the track, then ramps
  back to 0.55 over the first 0.25s after restart. The waveform jolt
  still happens, but during near-silence so it should be much less
  perceptible.
- Implementation hooks HTMLMediaElement.prototype.play and only attaches
  the soft-loop behavior to audio elements whose src matches the title
  music URL pattern. Every other audio element passes through unchanged.

Trade-off:
- There is now a noticeable volume dip every loop iteration (~0.55s of
  audible quieter audio around the boundary). If that bothers you more
  than the original click, just delete this install block to revert.

Console checks:
noMoonV274SelfTest()    // expect ok:true, installed:true
noMoonV274Debug()       // shows attached count, loops count, playWraps
noMoonV273SelfTest()    // toggles still visible
noMoonV272SelfTest()    // video still ok
