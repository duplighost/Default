Qualiacology site update — Discord URL swap + book section cleanup

Upload the contents of this ZIP to the site root, preserving folder structure.
This bundle ships on top of the v275 fresh-run reveal hard-guard No Moon build,
which fixed the Descend-triggers-zoomout regression. No-Moon game code is
unchanged from v275 hard-guard.

Content edits in this bundle:

1. Discord links updated.
   - https://discord.gg/psychopharmacology  ->  https://discord.gg/NwvxKxUJpC
   - "discord.gg/psychopharmacology" display text  ->  "discord.gg/NwvxKxUJpC"
   - Applied in both index.html (5 occurrences) and book.html (3 occurrences,
     including the case-variant "Discord.gg/psychopharmacology" in the
     Community section paragraph).
   - Internal page anchor "#about-the-psychopharmacology-community" left alone
     (that is a page-internal jump, not a Discord URL).
   - Descriptive prose like "Discord community" / "psychopharmacology" /
     "3,000+ member psychopharmacology Discord community" left intact since
     those are not links.

2. Book sections removed.
   - "Some Medications I Think Actually Work" (was h2 #some-medications-i-think-actually-work)
   - "Some Treatments You Probably Shouldn't Bother With" (was h2 #some-treatments-you-probably-shouldn't-b)
   - Both section bodies removed in full.
   - No TOC entries pointed at either section (already verified), so no TOC
     fixes were needed. Adjacent sections "Supporting Others: A Guide for
     Family and Friends" and "Q&A" now flow directly into each other.

Console / quick QA after upload:
- Open the book, scroll past "Supporting Others" -> next section should be Q&A.
- Click any "Join the Discord" / footer Discord link -> opens new tab to
  discord.gg/NwvxKxUJpC.
- noMoonCurrentSelfTest() in the No Moon console should still pass (v275
  hard-guard unchanged).
