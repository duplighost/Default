# No Moon v79 — The Drowned Sky + The Drowned Sun + Cold Lantern

Build tag: `qual.drowned-sky-collapsed-sun.2026-05-13.v79`
Service worker cache: `no-moon-drowned-sky-collapsed-sun-v79`
Drop-in replacement for v78.

## Upload instructions
Unzip and copy the contents to your web root. Folder layout matches v78.

```
/index.html                                          (landing, unchanged)
/book.html                                           (unchanged)
/no-moon.html                                        (unchanged)
/_redirects                                          (unchanged)
/no-moon-sw.js                                       (root cleanup SW, unchanged)
/assets/favicon.svg                                  (root branding, unchanged)
/assets/icon-192.png                                 (unchanged)
/assets/icon-512.png                                 (unchanged)
/assets/qualiacology-og.png                          (unchanged)
/assets/site.webmanifest                             (unchanged)
/no-moon/index.html                                  <- v79 IIFE injected
/no-moon/game_inline.js                              <- maintenance mirror
/no-moon/no-moon-sw.js                               <- CACHE_NAME bumped to v79
/assets/no-moon/...                                  (unchanged from v78)
```

## What v79 adds

### The Drowned Sky — a second route after the Sun

After your **second or later** clear of the regular Sun route, the crater in the throne room stays open. Walking into the open crater used to do nothing. Now it descends into a new biome.

```
crater touch  ->  fade transition  ->  Drowned Sky entry room
                                       ↓ (clear, side door)
                                       Drowned Sky mid room
                                       ↓ (clear, side door)
                                       Drowned Well — the boss arena
```

Three rooms. Dark space-gradient background, distant starfield, sparse cold-light beacons. Drifting cold-tide particles instead of ambient dust.

### New enemies

**Cold Orbiter** — small dark sphere with a pale crescent rim. Orbits the player at ~220px, fires a single bullet inward every ~1 second. Teaches its movement by holding the orbit.

**Wake Comet** — blue-white head, locks direction with a clear telegraph (yellow ring + warning tail), then dashes in a straight line. Tail is brighter while telegraphing so you can read the path before it happens.

### The Drowned Sun (final boss)

Dark core with a cold blue/violet corona, eight slow flares spinning around it.

- **Phase 1** (full HP → 50%): slow center orbit. Fires 12-bullet rings on a 2.4s cadence, aimed 3-bullet bursts on 1.8s. Periodically spawns a single Cold Orbiter (every ~7.5s) to give you something else to track.
- **Phase 2** (≤ 50% HP): orbits the room. Faster aimed bursts (1.1s), 16-bullet rings (1.8s), and a 9-bullet sweeping forward ray (4.5s). Briefly flashes white when crossing the phase line.
- Contact damage if you stand on the body.

Boss-bar reads: **THE DROWNED SUN**.

### Victory: the Cold Lantern

When the Drowned Sun dies:

1. Room is safed immediately (same v77 helper — no leftover damage can take the win).
2. Sun core implodes (white/blue rings, particle bloom, slow-mo, "THE WELL FALLS QUIET" message).
3. A **Cold Lantern** appears where the boss died — a dashed violet ring with a suspended cold star inside it, pale orbit hint around the outside.
4. Walk into the Cold Lantern to claim the win.
5. Overlay reads:
   - Title: `THE LIGHT STAYS DEAD`
   - Body: `You followed the Sun into the place underneath light, and brought back a Cold Lantern.`
   - Button: `Wake in Safe Haven as [your character]`

### Persistence

- `save.victories.drownedSkyClears` — increments on each Cold Lantern touch.
- `save.defeatedBosses.drownedSun` — set true on first Drowned Sun death.
- Mirror (`noMoonProgress_v68`) gets the same fields.
- **After your first Drowned Sky clear**, the open Sun crater in the throne room renders a small cold-trophy overlay: a dashed cold ring around the rim with a tiny suspended cold star. The game remembers your win visibly without a single line of text.

### Entering the Drowned Sky still counts as a Sun clear

If you walk into the open crater instead of touching the Return Sigil, you still get credit for the regular Sun route victory — `victories.sunClears` increments at crater touch.

### Debug
- `state.v79Debug()` / `noMoonV79Debug()` — full snapshot: in-Drowned-Sky flag, room label, beacons, doors, Cold Lantern state, clear count, drowned-sun-defeated flag, full v78/v77/v76 chain.
- `noMoonV79ForceEnter()` — manually install Drowned Sky rooms on the current level (testing).
- `noMoonV79ForceKillBoss()` — kill the Drowned Sun if it's alive in the current room (testing the victory flow).

## Renaming

Names live in a single `V79_NAMES` block at the top of the v79 IIFE. Changing them only requires editing that one block:

```js
const V79_NAMES = {
  biome: 'The Drowned Sky',
  bossDisplay: 'The Drowned Sun',
  bossBar: 'THE DROWNED SUN',
  trophy: 'Cold Lantern',
  winTitle: 'THE LIGHT STAYS DEAD',
  winBody: 'You followed the Sun into the place underneath light, and brought back a Cold Lantern.'
};
```

## Verification (in browser, after hard refresh)

1. `state.v79Debug()` returns ok, `buildTag` ends `.v79`.
2. Beat the regular Sun route at least once — confirm crater seals on first clear.
3. Start a new run, beat Sun route a second time. The crater stays open.
4. Walk into the open crater. Fade transition → you land in the Drowned Sky entry room.
5. Cold Orbiter + Wake Comet enemies in entry room. Beacons pulse softly.
6. Clear the entry → side door opens → mid room with 3 enemies.
7. Clear the mid room → side door opens → boss arena with the Drowned Sun.
8. Drowned Sun phase 1: slow center, ring + burst attacks, spawns an orbiter every 7s.
9. Drown the Sun to 50% HP → flash → phase 2 begins (faster, sweep rays).
10. Kill the boss → immediate safety, Cold Lantern appears at boss death point.
11. Walk into Cold Lantern → win overlay: "THE LIGHT STAYS DEAD".
12. Restart — confirm `victories.drownedSkyClears = 1`, `defeatedBosses.drownedSun = true`.
13. Beat Sun route again — the open crater now has the cold-trophy overlay.

If anything looks wrong, capture `noMoonV79Debug()` to console and share it.

## Preserved from prior builds
- v78 Moots strict-unlock + universal lock CSS + star reroll button rebuild.
- v77 Sun fight readability + post-boss safety + touch-to-win Return Sigil.
- v76 starless doors, Night Ferry copy, passenger polish.
- Older v46-v75 fixes.
