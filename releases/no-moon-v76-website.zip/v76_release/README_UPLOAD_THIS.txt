# No Moon v76 — Route Integrity + Useful Stars + Passenger Polish

Build tag: `qual.route-integrity-stars-passengers.2026-05-13.v76`
Service worker cache: `no-moon-route-stars-passengers-v76`
Drop-in replacement for the v75 final-master-merge zip.

## Upload instructions
Unzip and copy the contents to your web root. The folder layout matches v75 exactly — nothing moves. The service worker will auto-invalidate the v75 cache on first visit after upload.

```
/index.html              (your landing page, unchanged from v75)
/book.html               (unchanged)
/no-moon.html            (unchanged)
/_redirects              (unchanged)
/no-moon-sw.js           (root cleanup SW, unchanged)
/no-moon/index.html      <- updated (v76 IIFE injected before final renderCodexStats)
/no-moon/game_inline.js  <- updated (maintenance mirror, same content as inline)
/no-moon/no-moon-sw.js   <- updated (CACHE_NAME bumped to v76)
/assets/no-moon/characters/moots-portrait.webp   <- updated (new art)
/assets/no-moon/characters/vesper-portrait.webp  <- updated (new art)
/assets/no-moon/characters/*.webp                (other portraits unchanged)
/assets/no-moon/bosses/*.webp                    (unchanged)
/assets/no-moon/title/*.webp                     (unchanged)
```

## What changed in v76

**Real bugs fixed from the v75 playtest:**

- **Night Ferry death copy.** The Sky-route boss was painting "THE GRAVEN WARDEN IS DEAD" on death because `bossDefeatLine` had no branch for `typeId === 'v59NightFerry'` and fell through to the base function. v23/v24.2 wraps handled `falseMoon` and `spiggot` but the Ferry was missed. v76 wraps the function and returns "THE NIGHT FERRY DROPS ANCHOR" for the ferry, falls back to base for everything else. Also fixes `bossProperName` / `bossHonorific`.

- **Starless approach + Ferry dock doors moving with the player.** v71 wrapped `renderWorld` to draw its doors AFTER the base function restored the world transform. Result: the door art painted in screen space while collision lived in world space. v76 wraps `renderWorld` outermost, snapshots `_v71StarlessDoors`, blanks them so v71's inner draw is a no-op, then redraws under the actual camera transform. The Ferry Dock commit portal becomes visible.

- **Stars stopped meaning anything.** The v57 star market was hidden by v60/v70 cleanup. Restored one useful lever: a reroll button on the draft UI. "Reroll grafts — N★". Base cost 5 stars, +3 per reroll inside the same draft. No store text wall.

- **Moots / Vesper card polish.**
  - Suppressed the v66 `.card.selected::after { content:'SELECTED' }` badge that overlapped the Moots name; replaced with a glow + border.
  - Rewrote Moots and Vesper card descriptions with story copy ("Left Safe Haven convinced fate was a habit, not a law" / "Stepped off the Night Ferry with a ticket the elders swore did not exist").
  - Tags updated to match.

- **New character portraits.** Moots = purple crescent + violet glyph circle. Vesper = blue moon-crown over water. Both normalized to 520×740 WebP @ q92 to match the other portraits.

**Diagnostic helper:**

- `state.v76Debug()` / `window.noMoonV76Debug()` — dumps selectedCharId, save.selectedCharId, player.template.id, last 12 messages, level contract, room label, draft state, stars. Use this if "begin again as Sol but Mire shows up in the first room" happens again — we'll know if it's a real template mismatch or just the Gravemire Liturgy graft's "Mire" short name appearing.
- `state.v76GrantStars(20)` / `window.noMoonV76GrantStars(20)` — testing helper to credit stars.

**What was deferred (intentionally) to v77:**

- Replacing baked-in ground text ("BEYOND THIS POINT, THE MOON WATCHES", "TURN BACK. SAFETY ENDS HERE.", "SAFE BELOW", etc.) with visual symbols. This is a direct source edit, not a tail wrapper — too risky to combine with the v76 fixes.
- Dark / blackout floor frequency tuning. Currently rare by design (v40 guards it from triggering before floor 3 on desktop / floor 4 on mobile). User mentioned a possible moon-debt hook but said this isn't urgent.

## Verification

In the browser, after hard refresh:

1. Title screen renders with new portraits visible.
2. Open `state.v75SelfCheck()` in console — `ok: true`, all characters present.
3. Open `state.v76Debug()` — `buildTag` ends with `.v76`, `version` is the v76 string.
4. Select Moots — name no longer overlaps the SELECTED badge area; new portrait shows.
5. Pick up any draft. Widget reads "★ N / Reroll grafts — 5★". With enough stars, clicking the button rerolls cards and drops stars by the cost.
6. Take Sky/Starless route to Night Ferry — doors stay anchored to walls and the dock teleporter is visible. On Ferry death: "THE NIGHT FERRY DROPS ANCHOR", no Graven Warden text.
7. If the Sol/Mire issue happens: open console, run `noMoonV76Debug()`, save the JSON — that's what diagnoses it.

## Files preserved from v75

The v75 dev guide, validation doc, and manifest sha256 are NOT included in this zip. If you want them, grab the v75 originals. They reference v75-specific paths so I haven't carried them forward; a fresh v76 dev guide can come later if useful.
