# No Moon v80 — Drowned Sky Stage + Drowned Sun Phase 3 + Safe Haven Cold Lantern

Build tag: `qual.drowned-sky-stage-eclipse-trophy.2026-05-14.v80`
Service worker cache: `no-moon-drowned-sky-stage-eclipse-trophy-v80`
Drop-in replacement for v79.

## Upload
Unzip and copy to web root. Folder layout matches v79.

```
/index.html, /book.html, /no-moon.html, /_redirects   (unchanged)
/no-moon-sw.js                                        (root cleanup SW)
/assets/{favicon.svg, icon-192.png, icon-512.png,
         qualiacology-og.png, site.webmanifest}      (root branding)
/no-moon/index.html                                   <- v80 IIFE injected
/no-moon/game_inline.js                               <- maintenance mirror
/no-moon/no-moon-sw.js                                <- CACHE bumped to v80
/assets/no-moon/...                                   (unchanged from v79)
```

## What v80 turns the Drowned Sky into

### A real stage — 8 rooms, branching

v79 was a 3-room sketch. v80 makes it a proper stage:

```
Cold Threshold (entry)
   ↓
Drowned Corridor (spine)
   ↓
Drowned Expanse (open)
   ↓
The Forked Tide (fork — 2 doors visible)
   ↓                          ↓
The Quiet Ring (ring)    The Long Comet (spine)
   ↓                          ↓
        The Hollow Vigil (preboss — calm room with Eclipse Manta + Orbiter)
                              ↓
               The Drowned Well — boss arena
```

Each room kind has its own layout (entry / spine / open / ring / fork / preboss / boss) with appropriate sizes, obstacle patterns, and enemy palettes. Backgrounds vary slightly per kind (boss arena has a darker "well" gradient; ring rooms have a faint floor circle; fork rooms have two converging path lines).

You walk through 6 of the 8 rooms depending on which fork door you pick. Both forks converge at The Hollow Vigil.

### Two new enemies

**Eclipse Manta** — wide dark wing shape with cold-light rim. Drifts slowly toward you. Contact damage. **Its presence dims any nearby navigation beacon** within ~250px (an occlusion radius), which is why the rooms it appears in feel darker and harder to read.

**Gravity Stone** — stationary cracked black stone with orbiting dust. **Pulls you and your projectiles** toward it (player pull radius ~360px, projectile pull radius ~220px). No direct damage. Forces you to re-plan when one's in your path. Beatable.

### The Drowned Sun — now 3 phases

HP raised from 140 → 220 to fit the longer stage.

- **Phase 1** (full HP → 55%): slow center orbit. Rings every 2.4s, 3-bullet bursts every 1.8s, spawns a Cold Orbiter every ~8.5s.
- **Phase 2** (≤ 55% HP): orbits the room. Faster aimed 5-bullet bursts (1.1s), 16-bullet rings (1.8s), single sweep ray (4.5s).
- **Phase 3** (≤ 20% HP): final desperation. Faster tighter orbit. 6-bullet bursts (0.95s), 20-bullet rings (1.5s), **crossed double sweep rays** (3.8s). Spawns weak Gravity Stones around the arena edge (14s). Briefly **eclipses** the screen (screen darkens to ~55% briefly, so the boss + bullets become the only things you can see).

Boss bar reads `THE DROWNED SUN` with **three pips** to the right of the label — they fill as phases progress so you can see how close the fight is to ending.

A phase transition flashes white, clears hostile projectiles (so you don't eat carryover), and shakes the screen (extra shake on the phase-3 transition).

### Cold Lantern victory (same as v79 but on this bigger fight)
- Drowned Sun dies → room safed instantly → Cold Lantern appears at the death point.
- Touch the Cold Lantern → `THE LIGHT STAYS DEAD` overlay → `Wake in Safe Haven as [name]`.
- Persists: `save.victories.drownedSkyClears++`, `save.defeatedBosses.drownedSun = true`, mirrored to `noMoonProgress_v68`.

### Safe Haven Cold Lantern shrine — persistent trophy

After your **first Drowned Sky clear**, the next time you spawn into Safe Haven the room renders a small **Cold Lantern shrine** at room.width × 0.22, room.height × 0.32 (top-left quadrant, doesn't block the door or spawn).

- Warm-haven stone plinth with a cold inset rim.
- Suspended cold star above it, with 6 orbiting needles and a dashed violet frame ring.
- **Multiple clears**: extra orbiting rings appear around the trophy, one per additional clear, capped at 4. A small `×N` count appears below the plinth for clear counts ≥ 2.

The game remembers your win **visibly** without a line of explanatory text.

### Sun-clear credit still happens at crater touch

Walking into the open Sun crater records `victories.sunClears++` for the regular Sun route (so you don't lose that win when you take the harder ending).

## Debug helpers

```js
state.v80Debug()              // full snapshot (room/enemies/beacons/doors/clears/eclipse pulse)
noMoonV80Debug()              // same, on window
noMoonV80ForceEnter()         // skip the crater requirement, install the stage on current level
noMoonV80ForceKillBoss()      // instantly kill the Drowned Sun if it's alive (testing victory)
```

## What v80 doesn't do (deferred)

- **Hidden secret room** — the fork doesn't yet have a third door to a bonus chamber. Easy v81 add.
- **A whole 2nd biome flavor** — the Drowned Sky is one biome family. Could split into "Cold Tide" / "Eclipse Hollow" sub-families in v81.
- **Per-room music** — currently uses the existing global music. Audio-pass v81/v82.
- **Mobile perf** — still deferred. v67 gearDock + v70 drawBiomeSignature per-frame writes/draws noted previously.

## Verification

After hard refresh:

1. `state.v80Debug()` returns ok, `buildTag` ends `.v80`.
2. Beat regular Sun route once (crater seals).
3. Beat regular Sun route a second time (crater stays open).
4. Walk into open crater → fade → land in **Cold Threshold**.
5. Walk through 4 rooms, pick a fork (A or B), walk through 2 more, reach **The Hollow Vigil**, then **The Drowned Well**.
6. Fight the Drowned Sun across 3 phases. Watch the pips on the boss bar fill.
7. Kill the boss → Cold Lantern appears → touch it → `THE LIGHT STAYS DEAD`.
8. Restart, head back into Safe Haven → confirm Cold Lantern shrine renders in top-left.
9. Clear it a second time → confirm a second orbiting ring appears.

If anything feels off, capture `noMoonV80Debug()` and `noMoonV79Debug()` to console and share.

## Preserved
- v79 base Drowned Sky systems (Cold Orbiter + Wake Comet, Cold Lantern object, save fields).
- v78 Moots strict-unlock + star reroll widget.
- v77 Sun fight readability + touch-to-win + post-boss safety.
- v76 starless doors, Night Ferry copy, passenger polish.
- Older v46-v75 fixes.
