# No Moon v92 — Claude-reconciled polished Netlify build

Build tag: `qual.claude-reconciled-polished-netlify.2026-05-13.v92`
Game service-worker cache: `no-moon-claude-reconciled-polished-netlify-v92`

Upload the contents of this folder directly to your Netlify site root. Keep the folder structure exactly as-is:

- `/index.html`
- `/book.html`
- `/no-moon.html`
- `/_redirects`
- `/assets/...`
- `/no-moon/index.html`
- `/no-moon/game_inline.js`
- `/no-moon/no-moon-sw.js`

This build reconciles Claude's v89 safe startup rollback with the safer v90/v91 re-ports of the later fixes, then adds v92 manifest/build/title polish. It deliberately does not reintroduce the v86-v88 Codex MutationObserver loop pattern.

Console checks after deploy:
- `state.v92Debug()`
- `state.v92SelfTest()`
- `noMoonCurrentSelfTest()`

After upload, hard-refresh once so the browser drops any old v88/v89/v90/v91 service-worker cache.

Additional final polish in this packaged v92:
- v91/v92 build stamping is now idempotent instead of rewriting DOM labels every frame.
- Visible Field Guide/Codex repairs are throttled while still repairing immediately on open/render.
- v92 is the final active Drowned Sun card repair path and keeps exactly one canonical Drowned Sun card.

--- Previous README follows ---
# No Moon v91 — Claude-reconciled stable totality Netlify build

Build tag: `qual.claude-reconciled-stable-totality.2026-05-13.v91`
Game service-worker cache: `no-moon-claude-reconciled-stable-totality-v91`

Upload the contents of this folder directly to your Netlify site root. Keep the folder structure exactly as-is.

This build uses the boot-stable Claude v89 / Pro v85 recovery line, keeps the v90 safe convergence fixes, and adds a final v91 owner for Codex repair, cache busting, and debug/build stamping.

Console checks after deploy:
- `state.v91Debug()`
- `state.v91SelfTest()`
- `noMoonV91RepairCodex()`

After upload, hard-refresh once so the browser drops any old v88/v89/v90 service-worker cache.
