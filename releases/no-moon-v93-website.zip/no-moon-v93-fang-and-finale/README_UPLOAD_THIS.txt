# No Moon v93 — Fang & Finale build

Build tag: `qual.fang-and-finale.2026-05-14.v93`
SW cache:  `no-moon-fang-and-finale-v93`

Based on Pro's v92 (claude-reconciled-polished-netlify). v93 adds one
IIFE on top of v92, no changes to the existing patch tower.

## What's new in v93

### Captains as mini-bosses (the "Fang" pass)

The five Captain types (Bell-Fed / Ash-Drunk / Perched Witness /
Doorbreaker / Saintless) now feel like real mini-bosses instead of
"slightly fatter enemy with a name." Specifically:

- **Bigger visual presence** — a breathing outer halo, an orbiting
  inner crown ring with four glyph dots, a soft size boost specific
  to each captain (Doorbreaker has the biggest aura, Perched Witness
  the most contained).
- **On-spawn telegraph** — when a captain becomes visible to the
  player, a single bright ring expands outward from its position
  over ~1s, so the player feels the room shift.
- **Visible health bar** above the title, only shown once the
  captain has actually taken damage. Makes the fight feel readable.
- **Themed kill rewards** — every captain death now drops a bonus
  splinter cluster (3–6 splinters depending on type) PLUS one themed
  special drop:
   - Bell-Fed → repair (HP back)
   - Ash-Drunk → extra-large splinter cluster (6 instead of 3)
   - Perched Witness → module (item mod)
   - Doorbreaker → repair (HP back)
   - Saintless → module (item mod)
- **Ghost cameo** — the first time you enter a room *adjacent to*
  a captain's room on a given floor, a silhouette of the captain
  peeks in from the connecting door, lingers half a second, and
  darts back. Pure visual — no AI hook on the real captain, no
  collision, can't be interacted with. It only ever happens once
  per captain per floor.

### Sun finale polish

Two changes to the post-Sun-boss room:

1. **First-clear crater reveal.** On your *first* Sun defeat the
   crater used to seal up silently while you headed for the Return
   Sigil. Now it briefly *opens* first — a cold blue glow leaks
   out for about 0.6s, then v77's brown lid grows in over the rest
   of the existing animation. You learn the crater exists while
   you're already locked into ending the run, which is exactly
   when you can't be tempted to ignore the sigil.
2. **Re-run sigil hierarchy.** On any subsequent Sun defeat the
   crater is already open and active. The Return Sigil now draws
   in a dimmed, slightly shrunken state in that condition, so you
   don't accidentally run for it out of habit and end the run when
   you wanted the Drowned Sky route. The crater's particle glow
   stays at full brightness — it's the louder of the two now.

## Build chain
```
v76–v82 (Claude) → v83–v85 (Pro) → v89 (Claude recovery)
                → v90 → v91 → v92 (Pro) → v93 (Claude)
```

v86/v87/v88 are still deliberately skipped — they shipped the codex
DOM-mutation loop. v93 does NOT install any MutationObserver. The
v92 codex layer remains the canonical Codex owner; v93 doesn't touch
the Codex DOM at all.

## Console checks after upload
- `state.v93Debug()` — shows current captain in room, active cameos,
  crater-reveal state, stats.
- `state.v93SelfTest()` — synthetic captain-reward + cameo idempotency
  checks, plus build tag check.
- `noMoonCurrentDebug()` / `noMoonCurrentSelfTest()` now point at v93.

## Upload
Unzip and copy to web root, replacing all the v92 files. Hard refresh
once after upload so the browser drops the v92 service-worker cache.
