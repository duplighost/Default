# No Moon — Bytewhore Pro Supplement for v82

**Audience:** Pro/GPT or a developer coming in cold after Claude’s v82 handoff.  
**Purpose:** supplement `01_CLAUDE_v82_BUILD_HANDOFF.md` with design intent, testing priorities, user-context constraints, and continuation warnings.  
**Current archive inspected for this guide:** v82 website archive → extracted folder `v82_release/`. Claude’s own `01_CLAUDE_v82_BUILD_HANDOFF.md` is included beside this file.  
**Current build tag in code:** `qual.nadir-black-anchor-active.2026-05-14.v82`.  
**Current game service-worker cache:** `no-moon-nadir-black-anchor-active-v82`.

This guide is written for someone who does **not** know the game. Read `00_START_HERE_FOR_PRO.md`, then Claude’s `01_CLAUDE_v82_BUILD_HANDOFF.md`, then this supplement before touching code. The codebase is playable and ambitious, but it is also a stacked tower of historical patch-IIFEs. Treat it like live archaeology: there are load-bearing ghosts in the walls.

---

## 0. Current status in one page

The latest package is **v82**. It already includes the post-Sun route, the Drowned Sun, the Nadir unlock, and Nadir’s Black Anchor active.

The historical path matters:

```text
v75 = final master merge baseline
v76 = Starless route fix + star reroll + passenger polish
v77 = Sun fight readability + post-boss safety + crater/Return Sigil
v78 = Moots lock fix + reroll widget rebuild
v79 = initial Drowned Sky / Drowned Sun / Cold Lantern sketch
v80 = expanded Drowned Sky stage + phase-3 Drowned Sun + Safe Haven Cold Lantern trophy
v81 = Nadir passenger + Drowned Sun Field Guide card + Nadir live form + orbit weapon
v82 = Nadir Black Anchor active + mobile performance throttles
```

The current build has:

```text
- Single-file Canvas/WebAudio twin-stick roguelike shooter.
- Safe Haven hub.
- Character/passenger selection.
- Grafts/relics/draft choices.
- Star reroll economy restored.
- Starless route and Night Ferry unlock path.
- Sun route with improved shade/seal readability.
- Major-boss post-death safety.
- Sun crater + Return Sigil touch-to-win.
- Second-or-later Sun clear can open the crater route.
- Drowned Sky dark-space route.
- The Drowned Sun final boss.
- Cold Lantern true-victory object.
- Safe Haven Cold Lantern shrine after Drowned Sky clear.
- Nadir final passenger unlock after Drowned Sun kill / Drowned Sky victory state.
- Nadir portrait + custom in-game live form.
- Nadir low-star orbit weapon.
- Nadir Black Anchor active.
- Drowned Sun Field Guide boss card.
```

Do **not** start from older v75/v76 assumptions. They explain the architecture, but v82 already implements a lot of the planned feature work.

---

## 1. First thing to do with any new archive

The user may give you a newer Claude archive after this guide was written. If that happens, do not blindly apply this guide as if v82 is still current.

First:

```bash
unzip latest.zip -d latest_inspect
find latest_inspect -maxdepth 3 -type f | sort | sed -n '1,200p'
```

Then identify the game root. In the current v82 archive, files are nested under:

```text
v82_release/
```

Inside that folder are the real website-root files:

```text
v82_release/index.html
v82_release/no-moon.html
v82_release/book.html
v82_release/_redirects
v82_release/assets/
v82_release/no-moon/
v82_release/no-moon/index.html
v82_release/no-moon/game_inline.js
v82_release/no-moon/no-moon-sw.js
```

If preparing a deploy zip, the deployed website root should contain `index.html`, `assets/`, and `no-moon/` at the top level. Do not deploy a package where the browser paths become `/v82_release/assets/...` unless the hosting provider specifically strips the wrapper folder.

---

## 2. Non-negotiable source discipline

### 2.1 The live game logic is duplicated

The game source exists in two places:

```text
no-moon/game_inline.js
no-moon/index.html embedded <script>
```

In the v82 archive, the embedded script and `game_inline.js` are exactly synced. Preserve that.

When editing game code:

1. Edit `no-moon/game_inline.js`.
2. Re-embed it into `no-moon/index.html`.
3. Verify exact equality.

Use this from the site root:

```python
from pathlib import Path
import re

game = Path('no-moon/game_inline.js').read_text(encoding='utf-8')
html_path = Path('no-moon/index.html')
html = html_path.read_text(encoding='utf-8')

html = re.sub(
    r'(?s)<script>\n.*?\n</script>',
    '<script>\n' + game + '\n</script>',
    html,
    count=1,
)

html_path.write_text(html, encoding='utf-8')
```

Verify:

```python
from pathlib import Path
import re, hashlib

game = Path('no-moon/game_inline.js').read_text(encoding='utf-8')
html = Path('no-moon/index.html').read_text(encoding='utf-8')
embedded = re.search(r'(?s)<script>\n(.*?)\n</script>', html).group(1)

print('synced:', game == embedded)
print('game sha256:', hashlib.sha256(game.encode()).hexdigest())
print('embedded sha256:', hashlib.sha256(embedded.encode()).hexdigest())
```

### 2.2 Syntax-check every time

```bash
node --check no-moon/game_inline.js
```

If you directly edit the embedded script in `index.html`, extract it to a temp file and run `node --check` against that too. Better: never directly edit the embedded script. Edit `game_inline.js`, then sync.

### 2.3 Service worker cache must be bumped when code or assets change

The active game service worker is:

```text
no-moon/no-moon-sw.js
```

Current v82:

```js
const CACHE_NAME = 'no-moon-nadir-black-anchor-active-v82';
```

Current `ASSETS` includes:

```js
'../assets/no-moon/characters/rook-portrait.webp',
'../assets/no-moon/characters/nyx-portrait.webp',
'../assets/no-moon/characters/sol-portrait.webp',
'../assets/no-moon/characters/mire-portrait.webp',
'../assets/no-moon/characters/moots-portrait.webp',
'../assets/no-moon/characters/vesper-portrait.webp',
'../assets/no-moon/characters/nadir-portrait.webp',
'../assets/no-moon/title/no-moon-title-desktop.webp',
'../assets/no-moon/title/no-moon-title-mobile.webp',
'../assets/no-moon/title/no-moon-title-poster.webp',
'../assets/no-moon/bosses/card-back.webp',
'../assets/no-moon/bosses/false-moon-card.webp',
'../assets/no-moon/bosses/warden-card.webp',
'../assets/no-moon/bosses/night-ferry-card.webp',
'../assets/no-moon/bosses/archon-card.webp',
'../assets/no-moon/bosses/spiggot-card.webp',
'../assets/no-moon/bosses/sun-card.webp',
'../assets/no-moon/bosses/drowned-sun-card.webp'
```

The root-level worker:

```text
no-moon-sw.js
```

is only a cleanup worker that unregisters old root-scope workers and deletes old `no-moon-*` caches. Do not confuse it with the active game worker.

### 2.4 Root site assets must stay present

Current v82 package includes these at the site root under `assets/`:

```text
assets/favicon.svg
assets/icon-192.png
assets/icon-512.png
assets/qualiacology-og.png
assets/site.webmanifest
```

They are not game-critical, but they are used for favicon, app icon, manifest, and social preview. Prior packaging accidentally omitted them, causing live 404s. Preserve them in every full deploy.

### 2.5 Current v82 static validation already done here

For the inspected archive:

```text
node --check no-moon/game_inline.js      passed
embedded script sync                      exact match
all character portraits                   520×740 WebP
all boss cards                            640×860 WebP
root website assets                       present
no-moon/no-moon-sw.js                     cache bumped to v82 and includes Nadir + Drowned Sun assets
```

Useful current hashes from the inspected files:

```text
no-moon-v82-website.zip            6d63b75f2c830b4ce3318edc7148b0f25f6fe920c30963ebfc54a4d2d94bdf9f
no-moon/game_inline.js             abedf14046061cd441f4417944108fa7a245832967351ccb1b9402ab1a6bac77
no-moon/no-moon-sw.js              5c0b663fe4a764814e2124648346f8f5d2f7e3470acd4a4703bb1e783a04f53a
README_UPLOAD_THIS.txt             d83d48ee3c5763c395910b62da4a554c037d199aeb0519feabe9e5c948382429
```

---

## 3. Architecture: how this codebase is shaped

### 3.1 Single closure, many late patch-IIFEs

Most important game functions are closure-local, not globals. The file ends with a large guarded closure. Late version patches are IIFEs inside that closure.

The current tail looks conceptually like:

```js
// v76 IIFE
// v77 IIFE
// v78 IIFE
// v79 IIFE
// v80 IIFE
// v81 IIFE
// v82 IIFE

renderCodexStats();

})();
```

If you add a new patch and need access to functions like `renderWorld`, `updateGame`, `drawPlayer`, `currentRoom`, `firePlayerWeapon`, `killEnemy`, etc., add the new IIFE **inside the main closure before `renderCodexStats();`**.

Do not put gameplay patch logic after the final `})();`. Outside the closure you only see exported debug crumbs and `window` state; you will not be able to safely wrap the actual internals.

### 3.2 Wrapper order matters

The build has many wrappers around the same functions:

```text
renderWorld
updateGame
updateEnemies
drawEnemy
drawPlayer
drawHUD
renderDraftUI
renderCharacterCards
updateOverlay
killEnemy
damagePlayer
setRoomCleared
safeWriteSave
startGame
openCodex
renderCodexStats
spawnSpark
spawnRing
drawAmbientWorld
```

Before wrapping any function, search for existing wrappers:

```bash
grep -n "functionName.__v" no-moon/game_inline.js
grep -n "const base.*functionName\|functionName = function" no-moon/game_inline.js
```

Use a unique guard flag, for example:

```js
if (typeof updateGame === 'function' && !updateGame.__v83Whatever) {
  const baseUpdate83 = updateGame;
  updateGame = function updateGameV83(dt) {
    // pre
    const out = baseUpdate83.apply(this, arguments);
    // post
    return out;
  };
  updateGame.__v83Whatever = true;
}
```

When you need to beat an older wrapper in the same frame, do your work **before** calling the base function. v80 does this for crater entry so it beats v79 and v77’s crater touch handlers.

### 3.3 Direct source edits vs tail wrappers

Tail wrappers are excellent for maintaining a layered release history. But some systems are better as direct edits if they already live deep inside older code.

Current v77 made direct edits inside v39 Sun-route code, then added tail helpers:

```text
- shared shade/seal spots
- removed seal self-damage
- heat meter model
- no combat quote text for Sun shade
- tag sun damage sources before damagePlayer
- install crater + Return Sigil on Sun death
- draw crater/sigil under world transform
- cap Sun bleach overlay
```

Do not assume every v77 behavior is in the v77 IIFE. Some is baked into earlier v39 sites.

---

## 4. Game model and route overview

### 4.1 Core loop

No Moon is a browser-based Canvas/WebAudio twin-stick roguelike shooter:

```text
character select
→ start run from Safe Haven / route start
→ room graph
→ clear enemies
→ collect stars/splinters
→ draft grafts/relics/modules
→ spend stars to reroll draft offers
→ route bosses and branches
→ victory objects / return choices
→ persistent unlocks and Safe Haven trophies
```

The game should communicate through movement, objects, lights, projectiles, silhouettes, UI state, and environmental consequence. Keep live-combat text rare.

### 4.2 Current roster

```text
Rook   — Bulwark / shotgun / tankier
Nyx    — fast needle-fire / glassier
Sol    — balanced twin-fire / Sun-route relevant
Mire   — slower / spore or secret-sense identity
Moots  — reroll / fate manipulation / Boon Moots
Vesper — Night Ferry / Starless route stowaway
Nadir  — final Drowned Sun unlock / gravity control / low-star orbit + Black Anchor
```

### 4.3 Existing route spine

The late-game route graph has become layered:

```text
Safe Haven / normal descent
→ regular route bosses
→ Graven Warden / Bellway-related state
→ Starless side path / Night Ferry
→ Vesper unlock
→ Sun route / Sun final boss
→ Sun crater + Return Sigil
→ later Sun clear: crater open
→ Drowned Sky route
→ Drowned Sun
→ Cold Lantern victory
→ Nadir unlock + Drowned Sun Field Guide reveal + Safe Haven Cold Lantern shrine
```

The Drowned Sky route is no longer just a plan. It exists in v80/v82.

---

## 5. Version-by-version current patch map

This is the fastest way to understand what Claude already did.

### 5.1 v76 — Route Integrity + Useful Stars + Passenger Polish

Installed as:

```js
// === v76 — Route Integrity + Useful Stars + Passenger Polish =======
const V76_VERSION = 'qual.route-integrity-stars-passengers.2026-05-13.v76';
```

Main jobs:

```text
- Fix Starless door / Ferry Dock rendering in world space.
- Fix Night Ferry boss naming by wrapping bossDefeatLine, bossProperName, bossHonorific.
- Restore compact star-reroll widget under draft cards.
- Polish Moots/Vesper cards and selected-card style.
- Add debug helpers.
```

Important details:

```text
- Starless doors are stored in world coords. v71 drew them after camera restore; v76 prevents v71 wrong drawing and redraws them under world transform.
- The old v57 Star Market remains buried; v76/v78 use #v76StarTrade as a new widget.
- v76 star reroll was later rebuilt in v78 because the click handler could be swallowed.
```

Debug:

```js
noMoonV76Debug()
noMoonV76GrantStars(20)
```

### 5.2 v77 — Sunfall Safety + Sun Readability

Installed as:

```js
// === v77 — Sunfall Safety + Sun Readability ========================
const V77_VERSION = 'qual.sunfall-safety-readability.2026-05-13.v77';
```

Main jobs:

```text
- Make major boss rooms safe after major-boss death.
- Prevent post-boss leftover damage from stealing wins.
- Add Sun damage-source tagging.
- Add Sun crater and Return Sigil physical victory objects.
- Add Sun heat meter in place of heavy instruction text.
```

Major-boss safety:

```js
const MAJOR_BOSS_IDS = ['warden', 'archon', 'sunCore', 'v59NightFerry'];
```

`makeMajorBossRoomSafe77(room, bossId, opts)`:

```text
- marks room cleared
- clears hostile projectiles
- empties hazards/traps/quote strikes
- for Sun: breaks all seals and disables seal burn
- removes non-boss adds
- grants player invulnerability
- sets _v77MajorBossDefeated on the room
```

`damagePlayer` is wrapped so if `room._v77MajorBossDefeated` is true while in play mode, damage is blocked. This means Drowned Sun can also use the safety system by explicitly calling `state.v77MakeMajorBossRoomSafe(room, 'v80DrownedSun', ...)` even though `v80DrownedSun` is not in `MAJOR_BOSS_IDS`.

Sun victory objects:

```text
- On Sun death, v39 calls state.v77InstallSunVictoryObjects(room, enemy, priorSunClears).
- A stable crater is placed at room center-ish, not at the exact kill position.
- Return Sigil appears below it.
- Player touches Return Sigil to complete normal Sun victory.
- On first Sun clear, crater is sealed.
- On later Sun clears, crater is open and active.
```

Important subtlety:

```text
v77's own crater touch handler originally only counted touches and deactivated the crater. v80 later intercepts the crater BEFORE v77 so the Drowned Sky route starts instead of just deactivating the crater.
```

Debug:

```js
noMoonV77Debug()
noMoonDamageDebug()
noMoonV77MakeMajorBossRoomSafe()
```

### 5.3 v78 — Moots Lock Fix + Star Reroll Widget Rebuild

Installed as:

```js
// === v78 — Moots lock fix + Star reroll widget rebuild =============
const V78_VERSION = 'qual.moots-lock-reroll-polish.2026-05-13.v78';
```

Main jobs:

```text
- Fix Moots appearing unlocked on death screen.
- Fix false-unlock from reaching final boss room without actually winning.
- Rebuild star reroll widget because v76 delegated click handler was unreliable.
- Center reroll widget instead of stretching it across the whole draft panel.
- Reset reroll counter per draft.
```

Strict Moots unlock condition:

```text
Moots should unlock after a real route clear / win state, not merely entering the final boss room.
```

Star reroll:

```text
Widget ID: #v76StarTrade
Button ID: #v78RerollBtn
Cost: 5★ + 3★ per reroll in current draft
Reroll counter: state.draft._v76StarRerolls
Reset: when new draft/biomeIndex changes
```

Important implementation point:

```text
v78 owns the reroll logic end-to-end and binds onclick directly to the button. Do not reintroduce capture-phase delegated click weirdness unless there is a strong reason.
```

Debug:

```js
noMoonV78Debug()
noMoonV78Reroll()
```

### 5.4 v79 — The Drowned Sky + The Drowned Sun + Cold Lantern

Installed as:

```js
// === v79 — The Drowned Sky + The Drowned Sun + Cold Lantern ========
const V79_VERSION = 'qual.drowned-sky-collapsed-sun.2026-05-13.v79';
```

v79 was the first implementation of the post-Sun route:

```text
open Sun crater touch
→ Drowned Sky entry room
→ mid room
→ boss room with The Drowned Sun
→ boss dies, Cold Lantern appears
→ touch Cold Lantern → THE LIGHT STAYS DEAD overlay
```

v79 still exists in the code, but v80 supersedes it with a larger stage and deliberately blocks v79 from double-installing.

v79 enemy registrations still matter because v80 reuses some enemy types:

```text
v79Orbiter      = Cold Orbiter
v79WakeComet    = Wake Comet
v79DrownedSun   = original sketch boss, superseded by v80DrownedSun
```

Debug:

```js
noMoonV79Debug()
noMoonV79ForceEnter()
noMoonV79ForceKillBoss()
```

### 5.5 v80 — Drowned Sky Stage + Phase 3 + Safe Haven Cold Lantern

Installed as:

```js
// === v80 — Drowned Sky Stage + Phase 3 + Safe Haven Cold Lantern ===
const V80_VERSION = 'qual.drowned-sky-stage-eclipse-trophy.2026-05-14.v80';
```

This is the real current Drowned Sky route.

Main jobs:

```text
- Expands Drowned Sky from 3 rooms into an 8-room stage.
- Adds room variety and branching.
- Adds Eclipse Manta and Gravity Stone enemies.
- Adds v80DrownedSun as a separate boss with 3 phases.
- Adds Cold Lantern victory object.
- Records Drowned Sky/Drowned Sun victory.
- Draws persistent Safe Haven Cold Lantern shrine after first clear.
```

Crater entry behavior:

```text
v80 wraps updateGame and checks open Sun crater BEFORE calling the older updateGame chain.
If player touches the open crater:
  installDrownedSkyStage80()
  crater.active = false
  state._v79InDrownedSky = true   // stop v79 from installing too
  state._v80InDrownedSky = true
```

Drowned Sky stage graph:

```text
Cold Threshold
  → Drowned Corridor
  → Drowned Expanse
  → The Forked Tide
      → The Quiet Ring
      → The Long Comet
  → The Hollow Vigil
  → The Drowned Well
```

Internal room kinds:

```text
entry
spine
open
fork
ring
spine  (side branch B)
preboss
boss
```

Door objects are custom `_v80Doors`, not normal base doors. Doors activate when `needsCleared` is satisfied.

Drowned Sky enemy palette:

```text
v79Orbiter       = Cold Orbiter
v79WakeComet     = Wake Comet
v80EclipseManta  = slow dark manta; visually occludes beacons; contact damage
v80GravityStone  = stationary gravity puller; pulls player and player bullets
```

Drowned Sun boss:

```text
typeId: v80DrownedSun
boss bar: THE DROWNED SUN
hp: 220
r: 64
```

Boss phases:

```text
Phase 1 (>55% hp)
- anchored near arena center
- rings
- bursts
- occasional Cold Orbiter summon

Phase 2 (55%–20% hp)
- orbiting movement
- faster aimed bursts
- rings
- sweep volleys

Phase 3 (≤20% hp)
- faster smaller orbit
- double/crossed sweeps
- stronger rings/bursts
- spawns weakened Gravity Stones near arena edge
- triggers eclipse-pulse darkening
```

Drowned Sun death:

```text
- v80 killEnemy wrapper detects v80DrownedSun.
- Calls state.v77MakeMajorBossRoomSafe(room, 'v80DrownedSun', { invuln: 999 }).
- Spawns room._v80ColdLantern at boss death point.
- Shows rings/sparks/slow-mo.
- Pushes: THE WELL FALLS QUIET.
- Player must touch Cold Lantern to complete victory.
```

Victory persistence on Cold Lantern touch:

```js
save.victories.drownedSkyClears += 1
save.defeatedBosses.drownedSun = true
save.careerAudit.lastDrownedSkyAt = Date.now()
save.careerAudit.lastDrownedSkyBuild = V80_VERSION
```

Also mirrors progress to:

```text
localStorage key: noMoonProgress_v68
mirror.victories.drownedSkyClears
mirror.defeatedBosses.drownedSun
```

Victory overlay:

```text
Title: THE LIGHT STAYS DEAD
Body: You followed the Sun into the place underneath light, and brought back a Cold Lantern.
Button: Wake in Safe Haven as [Passenger]
```

Safe Haven Cold Lantern shrine:

```text
- Drawn by v80 inside renderWorld wrapper.
- Only appears in Safe Haven if drownedSkyClears > 0.
- Positioned in top-left quadrant.
- Multi-clears add orbiting rings/dots, capped visually.
```

Debug:

```js
noMoonV80Debug()
noMoonV80ForceEnter()
noMoonV80ForceKillBoss()
```

### 5.6 v81 — Nadir Final Passenger + Drowned Sun Field Guide Card

Installed as:

```js
// === v81 — Nadir Final Passenger + Drowned Sun Field Guide Card ====
const V81_VERSION = 'qual.drowned-sun-nadir-final-passenger.2026-05-14.v81';
```

Main jobs:

```text
- Add Nadir as final unlockable passenger.
- Strictly lock Nadir until Drowned Sun victory state exists.
- Add Nadir portrait/card data.
- Add custom in-game Nadir live form.
- Add custom Nadir low-star orbit weapon.
- Append Drowned Sun card to the Field Guide boss deck.
- Reveal Drowned Sun boss card only when Drowned Sun is defeated / Drowned Sky clear exists.
```

Nadir character:

```js
id: 'nadir'
name: 'Nadir'
title: 'Low-Star Diver'
accent: '#8fdcff'
maxHp: 5
speed: 252
damage: 1.02
fireDelay: 0.24
weapon: 'nadirOrbit'
desc: 'Found below the Drowned Sun. Three low stars orbit him, bending bullets, pulling enemies, and making the dark answer back.'
tags: ['Unlockable', 'Gravity control', 'Orbit shots']
unlockHint: 'Defeat the Drowned Sun.'
portrait: '../assets/no-moon/characters/nadir-portrait.webp'
```

Strict unlock condition:

```text
Nadir is considered unlocked if either save or mirror contains:
- defeatedBosses.drownedSun = true, OR
- victories.drownedSkyClears > 0, OR
- victories.drownedSunClears > 0.
```

Important actual-current behavior:

```text
v81 also wraps killEnemy. When v80DrownedSun or v79DrownedSun dies, it immediately writes defeatedBosses.drownedSun = true and unlockedCharacters.nadir = true, pushes 'NADIR SURFACES', and refreshes cards/codex.

v80 still requires Cold Lantern touch to complete the true win overlay and increment drownedSkyClears.

So in current v82, Nadir can be marked unlocked on Drowned Sun kill, just before the player touches the Cold Lantern. This matches “unlocked after beating Drowned Sun,” but if the user ever wants “only after touching the final victory object,” move the v81 unlock write from killEnemy into the Cold Lantern victory path or gate it on drownedSkyClears only.
```

Nadir card lock guard:

```text
- Adds .v81NadirLocked + .v68Locked if not strictly unlocked.
- Adds badge: 'Locked · defeat the Drowned Sun' or 'Unlocked · low-star orbit'.
- Document-capture click guard blocks locked Nadir before prior handlers can select/promote him.
- startGame guard falls back to Rook if locked Nadir is somehow selected.
```

Nadir live in-game form:

```text
- v81 wraps drawPlayer entirely for Nadir.
- Does not rely on the portrait image.
- Draws a dark/black-sun core body with cyan glow, drowned-gold fracture, orbit rings, and 3 orbiting star dots.
```

Nadir weapon actual implementation:

```text
Low-Star Orbit is implemented as 3 ready/spent star charges.
When firing:
  - if one or more stars are ready, fires up to 3 forward bullets in a tight fan.
  - each fired star goes on 0.72s cooldown.
  - bullet speed 760, radius 5, damage 0.78 × player.damage, pierce 1.
  - if no stars are ready, fires a weak fallback spark so the weapon never feels completely dead.
```

This is **not** a true returning-bullet implementation. The stars are visible readiness/cooldown resources, not physical boomerang projectiles. If asked to upgrade it later, preserve the rhythm and readability.

Drowned Sun Field Guide card:

```text
v71's boss card list is closure-local. v81 cannot mutate BOSS_CARDS71 directly. Instead it DOM-appends a 7th card after v71 renders and rewrites the revealed count.
```

Rendered when revealed:

```html
<img src="../assets/no-moon/bosses/drowned-sun-card.webp" alt="Drowned Sun">
<span class="v71BossName">Drowned Sun</span>
<span class="v71BossStatus">Defeated</span>
```

When locked:

```html
<img src="../assets/no-moon/bosses/card-back.webp" alt="Sealed boss card">
<span class="v71BossSeal">Sealed</span>
```

Debug:

```js
noMoonV81Debug()
noMoonV81UnlockNadir()
noMoonV81LockNadir()
```

### 5.7 v82 — Nadir Black Anchor Active + Mobile Perf Throttles

Installed as:

```js
// === v82 — Nadir's Black Anchor active + mobile perf throttles =====
const V82_VERSION = 'qual.nadir-black-anchor-active.2026-05-14.v82';
```

Main jobs:

```text
- Add Nadir-specific active ability: Black Anchor.
- Add Nadir active HUD slot.
- Add keyboard and tap input for active.
- Add mobile performance throttles for sparks/rings/ambient drawing.
```

Black Anchor config:

```js
RADIUS: 110,
LIFE: 3.5,
SLOW_MAX: 0.34,
SLOW_FLOOR: 0.70,
PULL_FORCE_PIXELS: 52,
COLLAPSE_DAMAGE: 1.8,
COLLAPSE_R_FRAC: 0.72,
AIM_CAP_PX: 320,
ROOM_NEED: 3,
USE_COOLDOWN_AFTER_FIRE: 0.40,
KEY: 'e'
```

Black Anchor behavior:

```text
- Only active while playing as Nadir.
- Starts ready when a Nadir run begins.
- Press E or tap the HUD slot.
- Anchor is placed at world-space mouse cursor, capped 320px from the player.
- Only one anchor at a time; using again replaces the existing room anchor.
- Lives 3.5 seconds.
- Slows enemy bullets inside radius, but excludes bossBeam/sunRay/majorHazard and large bullets.
- Gently pulls non-boss enemies toward center.
- Does not affect bosses.
- On expiry, collapse pulse damages non-boss enemies inside 0.72 × radius for 1.8 damage.
- Charges by room clears: 3 normal room clears = ready. Boss-room clear = full charge.
```

HUD slot:

```text
- Drawn only for Nadir.
- Uses existing active-slot geometry when available.
- Left/lower-left HUD card.
- Icon is dark disc + cyan halo + orbit ring.
- Label: BLACK ANCHOR.
- Ready text: E / TAP TO PLACE.
- Charging text: LACING X/3.
- Progress bar reflects readiness/lacing.
```

Mobile performance throttles:

```js
state.v82BlackAnchor.config.MOBILE_AMBIENT_SKIP = true;
state.v82BlackAnchor.config.MOBILE_SPARK_HALF = true;
state.v82BlackAnchor.config.MOBILE_RING_LIMIT = 4;
```

Effects:

```text
- On mobile width W < 720, spawnSpark count is halved.
- On mobile, spawnRing is capped to 4 rings per frame.
- On mobile, drawAmbientWorld skips every other call.
```

Toggle at runtime for testing:

```js
state.v82BlackAnchor.config.MOBILE_AMBIENT_SKIP = false;
state.v82BlackAnchor.config.MOBILE_SPARK_HALF = false;
state.v82BlackAnchor.config.MOBILE_RING_LIMIT = 0;
```

Debug:

```js
noMoonV82Debug()
noMoonV82ChargeAnchor()
noMoonV82UseAnchor()
```

---

## 6. Asset map and visual constraints

### 6.1 Character portraits

All current character portrait assets are **520×740 WebP**:

```text
assets/no-moon/characters/rook-portrait.webp
assets/no-moon/characters/nyx-portrait.webp
assets/no-moon/characters/sol-portrait.webp
assets/no-moon/characters/mire-portrait.webp
assets/no-moon/characters/moots-portrait.webp
assets/no-moon/characters/vesper-portrait.webp
assets/no-moon/characters/nadir-portrait.webp
```

The selection screen does not display the full vertical image as a poster. It crops into a shorter card panel. Keep important details in the center: head, torso, key symbolic object.

Nadir portrait already exists in v82:

```text
assets/no-moon/characters/nadir-portrait.webp
```

If replacing it, preserve:

```text
- 520×740 dimensions
- WebP format
- no text / no frame
- strong center silhouette
- black-sun head
- three low stars / orbit identity
- cold cyan + drowned gold palette
```

### 6.2 Boss cards

All boss card assets are **640×860 WebP**:

```text
assets/no-moon/bosses/card-back.webp
assets/no-moon/bosses/false-moon-card.webp
assets/no-moon/bosses/warden-card.webp
assets/no-moon/bosses/night-ferry-card.webp
assets/no-moon/bosses/archon-card.webp
assets/no-moon/bosses/spiggot-card.webp
assets/no-moon/bosses/sun-card.webp
assets/no-moon/bosses/drowned-sun-card.webp
```

The Field Guide displays each boss card image as a short horizontal crop:

```css
.v71BossCard img {
  width: 100%;
  height: 168px;
  object-fit: cover;
}
```

So boss identity must survive the central horizontal band. Do not place all important detail only at the top or bottom.

Drowned Sun card already exists in v82:

```text
assets/no-moon/bosses/drowned-sun-card.webp
```

It is appended to the Field Guide boss deck by v81 DOM code rather than base `BOSS_CARDS71` mutation.

### 6.3 Title assets

Current title assets:

```text
assets/no-moon/title/no-moon-title-desktop.webp
assets/no-moon/title/no-moon-title-mobile.webp
assets/no-moon/title/no-moon-title-poster.webp
```

Preserve and add to service worker if changed.

---

## 7. Current save/progress keys and unlock state

The code writes several save/mirror locations. Important ones for current work:

```text
SAVE_KEY / noMoonSave_v1                  primary save, depending on existing base constant
noMoonProgress_v68                        mirror/career persistence used by later patches
noMoon.v39.sunPathClearCount              localStorage clear count for Sun path
```

Important current save fields:

```js
state.save.unlockedCharacters.moots
state.save.unlockedCharacters.vesper
state.save.unlockedCharacters.nadir

state.save.defeatedBosses.drownedSun
state.save.victories.drownedSkyClears
state.save.victories.drownedSunClears
state.save.victories.sunClears
state.save.victories.routeClears
state.save.lifetime.wins

state.save.careerAudit.lastUnlock
state.save.careerAudit.lastUnlockReason
state.save.careerAudit.lastUnlockBuild
state.save.careerAudit.lastDrownedSkyAt
state.save.careerAudit.lastDrownedSkyBuild
```

Moots strict unlock is handled in v78. Nadir strict unlock is handled in v81. Be very careful adding generic character unlock logic: new characters can accidentally become unlocked if old code assumes “not explicitly locked = available.”

---

## 8. Debug helper cheat sheet

Open the game, then use the browser console.

### Build and latest state

```js
noMoonV82Debug()
```

This includes v81 debug nested inside, which includes v80 debug nested inside, etc.

### Drowned Sky

```js
noMoonV80Debug()
noMoonV80ForceEnter()
noMoonV80ForceKillBoss()
```

`noMoonV80ForceEnter()` installs/enters Drowned Sky if a run/level/player exists. It is the main fast way to test the route.

### Nadir

```js
noMoonV81Debug()
noMoonV81UnlockNadir()
noMoonV81LockNadir()
```

Use `noMoonV81UnlockNadir()` for testing the character without beating Drowned Sun every time. Use `noMoonV81LockNadir()` to verify strict lock UI.

### Black Anchor

```js
noMoonV82ChargeAnchor()
noMoonV82UseAnchor()
```

### Star reroll

```js
noMoonV76GrantStars(20)
noMoonV78Reroll()
noMoonV78Debug()
```

### Sun fight and post-boss safety

```js
noMoonV77Debug()
noMoonDamageDebug()
```

### Starless route / older systems

```js
noMoonV76Debug()
noMoonV71Debug()
```

Available exact helpers may depend on mode and which wrappers have installed, but the current v82 archive exposes the v76–v82 helpers.

---

## 9. Important current behavior to verify in-browser

Do not call the build “good” just because syntax passes. Test the game organs.

### 9.1 Package/shell

```text
- /assets/favicon.svg opens.
- /assets/site.webmanifest opens.
- /assets/icon-192.png opens.
- /assets/icon-512.png opens.
- /assets/qualiacology-og.png opens.
- /no-moon/ loads after hard refresh.
- Browser console can run noMoonV82Debug().
- noMoonV82Debug().buildTag should end in .v82 or noMoonV82Debug().version should be v82 if buildTag gets overwritten by older timers.
```

### 9.2 Character selection

```text
- Rook, Nyx, Sol, Mire, Moots, Vesper, Nadir all render.
- Nadir portrait appears in card.
- Nadir locked state appears on fresh save.
- Clicking locked Nadir is blocked.
- noMoonV81UnlockNadir() unlocks him.
- After unlock, selecting Nadir starts as Nadir.
- Starting locked Nadir cannot bypass lock; startGame falls back to Rook.
```

### 9.3 Nadir in-game

```text
- Nadir live form is not generic/Mire/Rook.
- It shows black-sun core and three orbiting stars.
- Shooting uses low-star orbit fan/cooldown behavior.
- When all stars are spent, weak fallback shot prevents total dead-fire feel.
- noMoonV81Debug().nadirStars reports ready/cd values.
```

### 9.4 Black Anchor

```text
- Start Nadir run: noMoonV82Debug().anchor.charges should be 1.
- HUD slot visible only for Nadir.
- Press E: anchor appears near cursor/world aim, capped 320px from player.
- Tap HUD slot: anchor places.
- Anchor slows enemy bullets but does not freeze them.
- Anchor pulls non-boss enemies.
- Bosses do not move.
- Collapse pulse damages non-boss enemies.
- After use, HUD says LACING 0/3.
- Clearing 3 hostile rooms recharges it.
- noMoonV82ChargeAnchor() makes it ready for testing.
```

### 9.5 Star reroll

```text
- Draft screen shows compact centered star-reroll pill.
- With stars: button says Reroll grafts — 5★, then 8★, then 11★ within same draft.
- Without stars: button says Need X★ more.
- Clicking button actually rerolls cards.
- Cost counter resets on a new draft.
```

### 9.6 Sun fight / Sun victory

```text
- Shade/seal circles align.
- Seal circle does not damage the player just for standing in it.
- Heat meter replaces “FIND SHADE” style instruction text.
- Damage source feedback is usable via noMoonDamageDebug().
- On Sun death, room becomes safe immediately.
- No leftover hazard can kill the player after Sun dies.
- Crater appears at stable location.
- Return Sigil appears.
- First Sun clear: crater is sealed; Return Sigil completes normal win.
- Later Sun clear: crater is open and entering it starts Drowned Sky via v80.
```

### 9.7 Drowned Sky

```text
- On second-or-later Sun crater entry, v80 Drowned Sky starts, not v79’s shorter sketch.
- noMoonV80Debug().inDrownedSky is true.
- Stage starts at Cold Threshold.
- Door graph works through Drowned Corridor, Drowned Expanse, Forked Tide, side branch, Hollow Vigil, Drowned Well.
- Doors stay visually anchored in room/world space.
- Beacons render and can be visually occluded by Eclipse Mantas.
- Gravity Stones pull player/bullets without becoming unreadable.
- Drowned Sun boss bar says THE DROWNED SUN and shows phase pips.
- Phase 3 happens at low HP.
- On Drowned Sun death, the room becomes safe immediately.
- Cold Lantern appears.
- Touching Cold Lantern shows THE LIGHT STAYS DEAD overlay and writes save progress.
```

### 9.8 Field Guide

```text
- Field Guide → The Defeated shows original boss cards plus Drowned Sun sealed card.
- Before Drowned Sun victory/unlock: Drowned Sun card uses card-back and Sealed.
- After Drowned Sun defeat/unlock: Drowned Sun card uses drowned-sun-card.webp and says Drowned Sun / Defeated.
- Count text denominator becomes /7 and numerator increments when revealed.
```

### 9.9 Safe Haven trophy

```text
- After Drowned Sky clear, Safe Haven draws a Cold Lantern shrine in top-left quadrant.
- Multiple clears add additional orbit/ring visual layers rather than duplicate clutter.
```

### 9.10 Mobile

```text
- On mobile width W < 720, noMoonV82Debug().isMobile is true.
- Black Anchor HUD slot fits and is tappable.
- Mobile perf throttles engage: mobileSparksHalved, mobileRingsDropped, mobileAmbientSkips can increment.
- If visual density becomes too sparse, toggle the v82 config flags for testing.
```

---

## 10. Known design tensions / likely next work

This section is where a future model should look before “improving” things.

### 10.1 Drowned Sky may need playtest tuning

The route exists, but likely needs tuning:

```text
- difficulty curve across 8 rooms
- room length and enemy density
- whether both fork branches feel worth taking
- whether Drowned Sky feels dark-space readable rather than empty or too busy
- whether Gravity Stones are fair on mobile
- whether Eclipse Manta occlusion is readable or just visual noise
- whether boss phase 3 is fair after a full route
```

### 10.2 Drowned Sun boss clarity is probably the next important gameplay polish

Potential tuning targets:

```text
- reduce untelegraphed projectile density
- ensure phase transitions clear bullets and communicate phase change
- distinguish enemy bullets, gravity effects, beacons, anchor effects, and boss corona
- check whether phase 3 eclipse darkening hides hazards too much
- ensure Black Anchor cannot trivialize ordinary bullets but also feels meaningful
- add/inspect damage source tagging for Drowned Sun if deaths feel unclear
```

### 10.3 Nadir unlock timing: boss death vs Cold Lantern touch

Current actual behavior:

```text
Drowned Sun kill → v81 immediately sets defeatedBosses.drownedSun and unlocks Nadir.
Cold Lantern touch → v80 completes the true win overlay and increments drownedSkyClears.
```

This is probably acceptable because the user said Nadir unlocks after beating Drowned Sun. But if the desired rule becomes “unlock only after touching the final victory object,” change v81’s killEnemy unlock behavior.

Safer stricter version:

```text
- v81 killEnemy may push/queue “NADIR SURFACES” visually but should not save unlock.
- v80 completeDrownedSkyVictory80() / recordDrownedSkyVictory80() writes defeatedBosses.drownedSun.
- v81 safeWriteSave pre-hook syncs Nadir afterward.
```

Do not make this change unless the user explicitly wants the stricter touch-to-claim behavior.

### 10.4 Nadir weapon design differs from original concept

Original brainstorm imagined physical returning stars. Current implementation uses three cooldown charges and a tight fan. That is simpler and probably more stable.

If upgrading:

```text
- preserve visual readiness (three orbiting stars)
- preserve fire rhythm
- avoid making it a full physics boomerang mess unless there is time to test thoroughly
- keep fallback shot or ensure “no stars ready” feedback is clear
```

### 10.5 Black Anchor may need boss/hazard exclusions tightened

Current exclusions:

```text
b.bossBeam
b.sunRay
b.majorHazard
large bullets where b.r > 12
boss enemies are not pulled
```

If a later boss uses different bullet flags, Black Anchor may slow things it should not. For major boss rays/laser-like hazards, explicitly set one of these flags or add a new exclusion.

### 10.6 Mobile throttles are global wrappers

v82 wraps `spawnSpark`, `spawnRing`, and `drawAmbientWorld` globally on mobile. This improves performance but can alter all later visuals.

If future art feels missing on mobile, check:

```js
state.v82BlackAnchor.config.MOBILE_AMBIENT_SKIP
state.v82BlackAnchor.config.MOBILE_SPARK_HALF
state.v82BlackAnchor.config.MOBILE_RING_LIMIT
```

Do not add a particle-heavy feature and then wonder why mobile drops half of it. v82 may be intentionally thinning it.

### 10.7 Field Guide appended Drowned Sun card is DOM-level

Because v81 appends the Drowned Sun card after v71 renders, future changes to v71’s Field Guide DOM structure can break Drowned Sun display/counts. If reworking Field Guide, either:

```text
- update appendDrownedSunBossCard81(), or
- finally refactor BOSS_CARDS71 / boss card data into a mutable/exposed registry.
```

The second option is cleaner but riskier.

### 10.8 Build tags can be overwritten by older wrappers

Each late patch sets `state.buildTag`; older timeouts can sometimes stamp an old tag. Trust the newest explicit debug function first:

```js
noMoonV82Debug().version
```

If `state.buildTag` lies, add late `tag83()` timeouts and call tag in relevant wrappers.

---

## 11. How to add a future v83 patch safely

If continuing after v82, add a new IIFE just before:

```js
renderCodexStats();

})();
```

Skeleton:

```js
// ===================================================================
// === v83 — Short Accurate Title ====================================
// ===================================================================
(function installV83ShortAccurateTitle() {
  const V83_VERSION = 'qual.short-accurate-title.2026-05-14.v83';
  const CACHE83 = 'no-moon-short-accurate-title-v83';
  if (typeof state === 'undefined' || !state) return;
  if (state.v83ShortAccurateTitle && state.v83ShortAccurateTitle.installed) return;

  const sys = state.v83ShortAccurateTitle = {
    installed: true,
    version: V83_VERSION,
    cacheExpected: CACHE83,
    stats: { lastError: null }
  };

  const N = (v, f = 0) => {
    const x = Number(v);
    return Number.isFinite(x) ? x : f;
  };

  function log83(e, where) {
    const msg = (where || 'v83') + ': ' + (e && (e.stack || e.message || String(e)) || 'unknown');
    sys.stats.lastError = msg;
    try { console.warn('[No Moon v83]', msg, e); } catch (_) {}
  }

  function tag83() { try { state.buildTag = V83_VERSION; } catch (_) {} }

  // wrappers / helpers here

  state.v83Debug = function v83Debug() {
    return {
      version: V83_VERSION,
      buildTag: state.buildTag,
      cacheExpected: CACHE83,
      stats: Object.assign({}, sys.stats),
      v82: typeof state.v82Debug === 'function' ? state.v82Debug() : null
    };
  };

  try {
    tag83();
    setTimeout(tag83, 0);
    setTimeout(tag83, 350);
    setTimeout(tag83, 1400);
    if (typeof window !== 'undefined') {
      window.__NO_MOON_V83_SHORT_ACCURATE_TITLE__ = sys;
      window.noMoonV83Debug = function () { return state.v83Debug(); };
    }
  } catch (e) { log83(e, 'install'); }
  state.buildTag = V83_VERSION;
})();
```

Then:

```text
1. Re-embed game_inline.js into no-moon/index.html.
2. Bump no-moon/no-moon-sw.js CACHE_NAME.
3. Add any new assets to ASSETS.
4. Run node --check.
5. Verify embedded sync.
6. Repack with flat website root.
7. Test in browser with hard refresh and debug helpers.
```

---

## 12. Practical commands for Pro

From a fresh working directory:

```bash
unzip /mnt/data/no-moon-v82-website.zip -d work
cd work/v82_release
node --check no-moon/game_inline.js
```

Verify sync:

```python
from pathlib import Path
import re, hashlib

game = Path('no-moon/game_inline.js').read_text(encoding='utf-8')
html = Path('no-moon/index.html').read_text(encoding='utf-8')
embedded = re.search(r'(?s)<script>\n(.*?)\n</script>', html).group(1)
print(game == embedded)
print(hashlib.sha256(game.encode()).hexdigest())
print(hashlib.sha256(embedded.encode()).hexdigest())
```

Asset dimensions:

```python
from pathlib import Path
from PIL import Image

for folder in ['assets/no-moon/characters', 'assets/no-moon/bosses']:
    print(folder)
    for p in sorted(Path(folder).glob('*')):
        im = Image.open(p)
        print(p.name, im.size)
```

Repack deploy root after edits:

```bash
# from inside the website-root folder, e.g. work/v82_release
zip -r ../../no-moon-v83-website.zip . \
  -x "*.DS_Store" "__MACOSX/*" "*.map"
```

Check zip root:

```bash
unzip -l ../../no-moon-v83-website.zip | sed -n '1,80p'
```

Top-level should show:

```text
index.html
no-moon.html
book.html
_redirects
assets/...
no-moon/...
```

not:

```text
v83_release/index.html
```

unless the uploader/deployer is known to strip that folder.

---

## 13. User-facing design preferences that matter here

These are not generic style notes; they affect implementation decisions.

```text
- Make the game visually readable.
- Avoid making players read during live play.
- Text is okay for Field Guide, cards, overlays, rare ceremony, debug.
- Combat feedback should use silhouette, animation, color, object state, lighting, arena changes, projectile behavior, sound, and persistent environmental consequence.
- Do not take control away from the player when a physical object could do the job.
- Major boss deaths should make the room safe immediately. Losing after killing a major boss feels awful.
- Victory should often be touched/claimed physically: Return Sigil, Cold Lantern, core, trophy object.
- Safe Haven should remember major victories through visible persistent objects.
- The game should feel beautiful first and cursed second.
- Dark/space content should be readable darkness, not monitor-fighting darkness.
```

The Drowned Sky route is specifically supposed to be space-dark rather than candle-cave dark. Current v80 uses beacons, starfields, cold nebulae, orbiting hazards, and gravity enemies. Continue in that direction.

---

## 14. What not to do casually

Do not casually:

```text
- Move code outside the main closure.
- Patch only no-moon/index.html and forget game_inline.js.
- Patch only game_inline.js and forget to re-embed.
- Forget to bump no-moon/no-moon-sw.js cache.
- Omit root assets from a full deploy.
- Reintroduce the old full Star Market when the compact reroll widget already exists.
- Add live-combat paragraphs to explain mechanics.
- Add a new final character without strict lock guards.
- Assume portrait art creates the in-game live form; Nadir needed custom drawPlayer logic.
- Assume Drowned Sun is in v71’s boss-card data; it is appended by v81 after render.
- Let major bosses leave damaging hazards after death.
- Let Black Anchor affect boss beams/rays unless deliberately designed and tested.
- Trust state.buildTag alone if a newer debug function says otherwise.
```

---

## 15. Current best next-step checklist

If Pro is asked to continue from v82, likely useful targets are:

```text
1. Playtest Drowned Sky route end-to-end.
2. Tune Drowned Sky enemy density and room length.
3. Tune Drowned Sun phase-3 clarity/difficulty.
4. Verify Drowned Sun death cannot leave damage sources.
5. Verify Cold Lantern touch reliably completes win and save writes.
6. Verify Nadir unlock/codex reveal behavior matches user expectation.
7. Verify Nadir low-star orbit feels distinct but not weak.
8. Verify Black Anchor is useful without trivializing rooms.
9. Verify mobile throttles help without making the game visually dead.
10. Preserve all deploy/package/source-sync rules.
```

If the user reports a bug, start with the appropriate debug function and inspect the actual current state. This game has enough layered history that guessing is how you summon a bug with a hat and a law degree.

---

## 16. Fast mental model for the current endgame

```text
Beat the Sun once:
  Sun dies safely.
  Crater appears but seals.
  Return Sigil appears.
  Touch Return Sigil for normal Sun victory.

Beat the Sun again/later:
  Sun dies safely.
  Crater appears open.
  Return Sigil still exists.
  Touch Return Sigil for normal win OR enter crater.

Enter crater:
  v80 intercept starts The Drowned Sky.
  Drowned Sky is an 8-room dark-space stage.

Reach The Drowned Well:
  Fight The Drowned Sun, a 3-phase dark-space final boss.

Defeat The Drowned Sun:
  Room is safed.
  Cold Lantern appears.
  v81 currently also marks Drowned Sun defeated/Nadir unlocked immediately on boss death.

Touch Cold Lantern:
  True victory overlay: THE LIGHT STAYS DEAD.
  save.victories.drownedSkyClears increments.
  save.defeatedBosses.drownedSun true.
  Safe Haven later shows Cold Lantern shrine.
  Nadir and Drowned Sun card are strictly revealed by this same victory state.
```

That is the current spine. Protect it.
