# PRO UPDATE — v85 deep bugfix pass

The source in this folder has been patched beyond the v84 reroll/Warden rescue. Current deploy build: `qual.deep-bugfix-boss-anchor-codex.2026-05-13.v85`. Current game SW cache: `no-moon-deep-bugfix-boss-anchor-codex-v85`.

Latest fixes:

- Boss-death safety now calls the normal room-clear cascade for standard boss rooms instead of marking rooms cleared first. This is the root fix for inactive bellways, missing Warden Starless side path/Ferry objects, and missing active-charge credit.
- Sun Core and Drowned Sky remain on their custom Return Sigil / Cold Lantern victory objects instead of being accidentally converted into normal bellway rooms.
- Reroll controls no longer kill synthetic clicks with pointerdown `preventDefault()`, and reroll refuses to spend stars if the visible cards cannot actually change.
- Black Anchor now aims correctly on touch, excludes/tag-backs boss bullets more reliably, and Drowned Sun sweep rays now carry the proper `r` collision radius.
- Drowned Sky custom clears grant Nadir/Moots active-charge credit once per room.
- Drowned Sun Codex card/count is repaired after any boss-deck rerender.
- Moots deepest-floor false-unlock evidence was removed, and unknown future passengers are no longer scrubbed locked by v83's old allowlist.
- Added `noMoonV85SelfTest()` for quick console validation of the repaired systems.

The original v82/v83/v84 notes below are preserved as context.

---

# PRO UPDATE — v84 reroll + Warden bellway rescue

The source in this folder has been patched beyond the previous v83 hardening pass. Current deploy build: `qual.reroll-bellway-rescue.2026-05-13.v84`. Current game SW cache: `no-moon-reroll-bellway-rescue-v84`.

Latest hotfixes:

- Star reroll now fires directly on pointerdown/click and redraws the graft cards immediately. The reroll button no longer depends on a synthetic click that can be swallowed.
- Warden/Archon boss-safety cleanup now re-runs the normal bellway-clear pipeline so the bellway/next-route portal and boss draft cannot be skipped after the room is made safe.
- Verified in-browser with a forced reroll and a reproduced Warden inactive-bellway state.

The original v82/v83 notes below are preserved as context.

---

# 00 — START HERE FOR PRO / GPT

This archive is the current **No Moon v82 website package** plus Markdown handoffs so Pro/GPT can get up to speed before touching the code.

The game code and assets are intentionally unchanged from the v82 package Claude provided. This bundle only renames and clarifies the handoff documents.

## Read in this order

1. **`00_START_HERE_FOR_PRO.md`** — this file. Use it to understand what each handoff file is and what not to do first.
2. **`01_CLAUDE_v82_BUILD_HANDOFF.md`** — Claude’s implementation handoff. This is the most important map of what Claude says he actually built from v76 through v82.
3. **`02_BYTEWHORE_SUPPLEMENT_DESIGN_AND_NEXT_WORK.md`** — additional design/context/testing guide from ChatGPT/Bytewhore. It explains intent, risks, user preferences, next-work priorities, and common failure modes.
4. Then inspect the actual code. Do not trust any handoff blindly if a newer archive exists.

## Archive layout

```text
v82_release/
  index.html
  no-moon.html
  book.html
  _redirects
  assets/
  no-moon/
  00_START_HERE_FOR_PRO.md
  01_CLAUDE_v82_BUILD_HANDOFF.md
  02_BYTEWHORE_SUPPLEMENT_DESIGN_AND_NEXT_WORK.md
```

For deployment, the website root should contain the **contents** of `v82_release/`, not an extra `/v82_release/` folder layer, unless the hosting/deploy system strips that wrapper automatically.

## Current build, according to the v82 handoff

```text
Build:  qual.nadir-black-anchor-active.2026-05-14.v82
Cache:  no-moon-nadir-black-anchor-active-v82
Route:  Sun clear → crater → Drowned Sky → Drowned Sun → Cold Lantern → Nadir unlock
```

## Do not start by rewriting architecture

No Moon is a single-file Canvas/WebAudio roguelike with a large closure-local patch tower. Many functions are not globals. New wrappers usually need to live inside the main closure near the tail of `no-moon/game_inline.js`, before the final boot calls. Then the script must be re-embedded into `no-moon/index.html` so the standalone source and embedded source stay synced.

Before changing anything, confirm:

```text
no-moon/game_inline.js and embedded script in no-moon/index.html are synced
node --check no-moon/game_inline.js passes
node --check no-moon/no-moon-sw.js passes
service worker cache is bumped if game/assets change
```

## What changed recently

Claude’s v82 work added/finished the post-Sun route chain and Nadir:

```text
v76: route integrity, useful stars, passenger polish
v77: Sunfall safety/readability, major-boss room safety, crater/Return Sigil
v78: Moots strict-lock and reroll polish
v79: first Drowned Sky / Drowned Sun sketch
v80: real Drowned Sky stage, Drowned Sun boss, Cold Lantern victory object
v81: Nadir passenger, Drowned Sun Field Guide card, unlock flow
v82: Nadir Black Anchor active
```

## Highest-value first checks for Pro

Run/playtest these before doing new work:

```js
noMoonV82Debug()
noMoonV82ChargeAnchor()
noMoonV82UseAnchor()
noMoonV80ForceEnter()
noMoonV80ForceKillBoss()
noMoonV81LockNadir()
noMoonV81UnlockNadir()
noMoonV76GrantStars(20)
```

Focus especially on:

```text
Nadir locked before Drowned Sun and unlocked after Drowned Sun
Drowned Sun Field Guide card locked before victory and revealed after victory
Drowned Sun death makes room safe immediately
Cold Lantern appears and completes true victory on touch
Nadir live form and orbit weapon look distinct in-game
Black Anchor works on desktop and mobile without tanking performance
service worker does not serve stale assets
```

## Immediate next-work areas already identified

These are not commands to implement all at once. They are the active backlog:

```text
1. Hidden secret room off the Drowned Sky fork
2. Mobile gearDock / active-slot polish if UI crowds gameplay
3. Per-room or route-specific music/soundscape in Drowned Sky
4. Replace remaining ground/instruction text with symbols and visual grammar
5. Split Drowned Sky into clearer sub-biome moods if route feels samey
6. Balance Nadir orbit weapon and Black Anchor after real playtesting
7. Check all major bosses for post-death hazards that can still damage the player
```

## Core design rule

No Moon should communicate through object state, motion, silhouettes, light, shade, pickups, trophies, hazards, and room changes before it uses explanatory prose. Text is fine for Field Guide, cards, debug, and rare ceremony. Live combat should not make the player read when they should be dodging.
