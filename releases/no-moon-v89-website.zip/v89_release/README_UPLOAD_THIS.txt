# No Moon v89 — recovery build (Pro's v85 base + version bump)

Build tag: `qual.recovery-from-v88-codex-loop.2026-05-14.v89`
SW cache: `no-moon-recovery-from-v88-codex-loop-v89`

## What happened

Pro's v86 / v87 / v88 stacks shipped Codex repair functions that mutate the same overlay subtree their MutationObserver watches. The `repairingCodex8X` re-entrance flag does not save them because MutationObserver callbacks are microtask-deferred — they fire *after* the synchronous repair function returns and clears the flag. Net effect: every repair mutation queues another observer callback → another repair → another mutation → infinite hot DOM-mutation loop → frozen tab → "the website crashes on the game."

Pro independently identified this while I was still narrowing it down. Full diagnosis in `V88_CRASH_POSTMORTEM.md`.

## What v89 is

**v89 = Pro's v85 with a version bump and a fresh SW cache name.** Nothing else added.

v85 had the loop-breaker that v86 dropped — its codex observer uses `setTimeout(0)` to defer mutations to a macrotask plus a `_v85CodexRepairScheduled` flag. Boots cleanly.

The version + SW cache name change forces Alex's browser to drop the broken v88 cache and load v89 fresh on next visit.

## Build chain in v89
```
v76 → v77 → v78 → v79 → v80 → v81 → v82        (Claude)
v83                                              (Pro hardening)
v84 (Pro: reroll-bellway-rescue)
v85 (Pro: deep-bugfix-boss-anchor-codex)
v89 (Claude: version bump only)
```

**v86, v87, v88 deliberately skipped** — they shipped the codex loop.

## What's preserved
- v85 boss-room exit / Bellway repair watchdog
- v85 reroll button rescue (Pro's v84 with a fresh button id)
- v85 codex Drowned Sun card repair (with the safe setTimeout-deferred observer)
- v85 anchor + bullet tagging
- v85 self-test infrastructure
- All v76–v83 work

## What's lost (worth porting back later)
- v86's `chooseDifferent` reroll edge-case fix
- v86's document-capture reroll handler
- v87's `closeCustomVictoryExit` / `chargeCustomDrownedClear`
- v88's bullet `radius` ↔ `r` normalize
- v88's `state.v88SelfTest()` infrastructure

Each of these is sound design that should be re-added later as an isolated IIFE with the codex-loop pattern explicitly avoided (use macrotask deferral, or `mo.disconnect()` before in-overlay writes).

## Upload
Unzip and copy to web root. Same layout as the previous builds.

## Smoke test (after upload + hard refresh)
- Title screen appears
- "Descend" works → game starts
- `state.v89Debug()` returns `buildTag` ending `.v89`, `basedOn` mentioning v85
- Codex / Field Guide opens without freezing the tab
- Reroll widget in draft fires on click and changes the cards

If anything's broken, paste `state.v89Debug()` and `state.v85SelfTest()` to console and share the output.
