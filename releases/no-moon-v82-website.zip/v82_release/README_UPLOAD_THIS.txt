# No Moon v82 — Nadir's Black Anchor active + mobile perf throttles

Build tag: `qual.nadir-black-anchor-active.2026-05-14.v82`
Service worker cache: `no-moon-nadir-black-anchor-active-v82`
Drop-in replacement for v81. No new asset files — just code changes.

## Upload
Unzip and copy to web root. Folder layout matches v81 exactly.

```
/index.html, /book.html, /no-moon.html, /_redirects   (unchanged)
/no-moon-sw.js                                        (root cleanup SW)
/assets/{favicon.svg, icon-192.png, icon-512.png,
         qualiacology-og.png, site.webmanifest}       (root branding)
/no-moon/index.html                                   <- v82 IIFE injected
/no-moon/game_inline.js                               <- maintenance mirror
/no-moon/no-moon-sw.js                                <- CACHE bumped to v82
/assets/no-moon/...                                   (unchanged from v81)
```

## What v82 adds

### Black Anchor — Nadir's active

While playing as Nadir:
- **Press `E` or tap the HUD slot** to place a Black Anchor at the world-space mouse-cursor position. Capped to 320 px from the player so it never lands off-arena (auto-clamped along the aim line).
- Anchor lives **3.5 seconds**, radius **110 px**, **one anchor at a time** (placing again replaces the existing one).
- While alive:
  - **Slows enemy bullets** in radius by up to 34 % (less near edge, more near center). Capped so bullets never effectively freeze. Beam/sweep-ray bullets are excluded.
  - **Pulls non-boss enemies** gently toward the center. Pull strength scales by 1−d/R.
  - **Does not affect bosses** — their bullets, their movement, their hazards. Honest control, not invincibility.
- On expiry: **collapse pulse** — small ring + 1.8 damage to non-boss enemies in 0.72 × radius.
- Charges by clearing rooms: **3 cleared rooms = full charge**, 1 charge max. Boss-room clears count as 3 (full charge).

### HUD slot

A new card on the left side of the screen (reuses the v68 slot geometry, since Nadir and Moots are different characters and never coexist in a run):
- **Icon**: small dark disc with cyan halo + slow-rotating orbit ring
- **Title**: BLACK ANCHOR
- **State label**:
  - `LACING X/3` while charging
  - `E / TAP TO PLACE` when ready (with brighter glow)
- **Progress bar**: lacing progress while charging; full when ready
- **Pre-collapse warning**: when the anchor has < 30 % life left, its outer ring pulses brighter so you know it's about to detonate

### Visual

Anchor renders in world space under the camera transform: dark void at the center, violet/cyan dashed rim rotating slowly, inward-streaming dust dots (10 on mobile, 22 on desktop), brighter ring as it nears collapse, white flash on the collapse pulse.

### Mobile performance throttles

Three cheap throttles, all toggleable at `state.v82BlackAnchor.config`:

1. **`MOBILE_SPARK_HALF` (default true)** — when `W < 720`, `spawnSpark(x, y, color, count, speed)` floors `count` to half (minimum 1). Boss fights produce up to 100+ sparks/frame; mobile WebKit gets noticeably steadier.
2. **`MOBILE_RING_LIMIT` (default 4)** — when mobile, `spawnRing` is rate-limited to at most 4 rings per frame. Extras dropped silently. Death bursts + room-clear bursts stop dominating.
3. **`MOBILE_AMBIENT_SKIP` (default true)** — when mobile, `drawAmbientWorld` skips every other call. Ambient/biome signature effectively renders at 30 fps. Eliminates the 30–80 canvas paths per frame v70's biome signature was adding on top of the base ambient particles.

Toggleable at runtime if a throttle looks wrong in playtest:
```js
state.v82BlackAnchor.config.MOBILE_AMBIENT_SKIP = false;
state.v82BlackAnchor.config.MOBILE_SPARK_HALF = false;
state.v82BlackAnchor.config.MOBILE_RING_LIMIT = 0;  // 0 disables the limit
```

## Debug helpers

```js
state.v82Debug()             // full snapshot (anchor state, room anchors, mobile flags, stats, full chain back to v81/v80)
noMoonV82Debug()              // same, on window
noMoonV82ChargeAnchor()       // force a full charge (testing — instantly ready)
noMoonV82UseAnchor()          // manually fire from console
```

`state.v82Debug().stats` shows running counts of `bulletsSlowed`, `enemiesPulled`, `collapsePulses`, `mobileSparksHalved`, `mobileRingsDropped`, `mobileAmbientSkips` — useful for confirming the throttles are actually engaging on a mobile device.

## Verification

After hard refresh:

1. **Lock check**: confirm Nadir still locked behind the Drowned Sun. `noMoonV81Debug()` returns `nadirStrictUnlocked: false` for a fresh save. Run `noMoonV81UnlockNadir()` to bypass for testing.
2. **`state.v82Debug()`**: `buildTag` ends `.v82`, `isMobile` matches your viewport, `anchor.charges` starts at 0 on title screen.
3. **Start as Nadir**: `state.v82Debug()` reports `anchor.charges: 1` (the startGame wrap gives Nadir a starting charge).
4. **HUD slot** appears in the lower-left for Nadir only. Not visible for other characters.
5. **Place via E**: anchor appears at cursor world position. Cooldown briefly disables fire. Slot label flips to `LACING 0/3`.
6. **Place via tap on slot**: same result. Mobile-friendly hitbox.
7. **Slow effect** — place anchor between you and a gunner; bullets visibly slow in radius but never freeze.
8. **Pull effect** — small enemies drift toward center. **Bosses don't budge** — confirm with Warden / Drowned Sun.
9. **Collapse pulse** — after 3.5s, ring + damage to non-bosses in 0.72×r.
10. **Charge by clearing rooms** — 3 clears = ready.
11. **Mobile**:
    - Open on phone or DevTools mobile profile.
    - `state.v82Debug()` shows `isMobile: true`.
    - Run Drowned Sky to phase 3, confirm frame rate is steadier than v81.
    - Particle counts feel reasonable, not eerily empty.
12. **Cross-build**:
    - `noMoonV81Debug()` still works (Nadir orbit weapon firing)
    - `noMoonV80Debug()` still works (Drowned Sky stage)
    - Beat Drowned Sun → Nadir unlocks → start as Nadir → Black Anchor slot appears and the active works

## Preserved from prior builds
- v81 Nadir character + custom orbit weapon + custom in-game form + Drowned Sun field-guide card
- v80 Drowned Sky stage (8 rooms, 3-phase boss, Safe Haven Cold Lantern shrine)
- v79 base Drowned Sky systems
- v78 Moots strict-unlock + star reroll widget
- v77 Sun fight readability + post-boss safety + touch-to-win
- v76 starless doors, Night Ferry copy, passenger polish
- Older v46-v75 fixes
