# No Moon v77 — Sunfall Safety + Sun Readability

Build tag: `qual.sunfall-safety-readability.2026-05-13.v77`
Service worker cache: `no-moon-sunfall-safety-readability-v77`
Drop-in replacement for the fixed v76 website zip.

## Upload instructions
Unzip and copy the contents to your web root. Folder layout matches v76 exactly. The service worker will auto-invalidate the v76 cache on first visit.

```
/index.html                                          (landing, unchanged)
/book.html                                           (unchanged)
/no-moon.html                                        (unchanged)
/_redirects                                          (unchanged)
/no-moon-sw.js                                       (root cleanup SW, unchanged)
/assets/favicon.svg                                  (root branding, unchanged)
/assets/icon-192.png                                 (unchanged)
/assets/icon-512.png                                 (unchanged)
/assets/qualiacology-og.png                          (unchanged)
/assets/site.webmanifest                             (unchanged)
/no-moon/index.html                                  <- v77 IIFE injected + v39 Sun edits
/no-moon/game_inline.js                              <- maintenance mirror, same as inline
/no-moon/no-moon-sw.js                               <- CACHE_NAME bumped to v77
/assets/no-moon/characters/*.webp                    (Moots/Vesper portraits from v76)
/assets/no-moon/bosses/*.webp                        (unchanged)
/assets/no-moon/title/*.webp                         (unchanged)
```

## What changed in v77

### Major boss post-death safety (universal)
After defeating a major boss — Graven Warden, Null Archon, Night Ferry, or the Sun — the room becomes safe IMMEDIATELY. Hostile bullets cleared, hazards/traps/quote strikes wiped, player invulnerable. No leftover boss damage can take the win. Implemented via:
- A `damagePlayer` wrap that blocks all damage when `room._v77MajorBossDefeated` is set.
- A `killEnemy` wrap that calls `makeMajorBossRoomSafe77` when the dead enemy's `typeId` matches one of: `warden`, `archon`, `sunCore`, `v59NightFerry`.
- A direct edit to `beginSunDefeat39` so Sun-route victory uses the same helper.

### Sun fight readability

**Shade circles and seal rings now share the exact same coordinates.** Floor-2 shadows are now `parasol`-tagged — visible umbrella shape with pole + ribs casting a circular dark zone — and the seal you have to charge sits dead-center inside it. One rule to learn: stand in the dark circle.

**The seal does not damage you anymore.** Standing in your own objective space should not feel like an unmarked hazard. Pressure now comes from the Sun's external attacks (light heat outside shade, ray strikes, projectile rings).

**`STAND` / `BROKEN` text is gone.** Replaced with a charge arc that fills clockwise around the ring while you stand inside, then a cracked-ring pattern after the seal breaks. Three sun-pin sockets around the ring. A faint tether from each unbroken seal to the Sun so you understand they're connected.

**`FIND SHADE` text is gone.** Replaced with a small heat-meter ring above the boss bar. Fills gold while you're in the light; drains blue in shade; a damage tick fires when it tops out, tagged as `sun:sunlight`.

**Quote-strike sentences are gone from live combat.** The damage line itself still telegraphs (dashed yellow → solid white), but instead of `THE FIRST PAINTER WEPT` floating mid-screen, you get a row of ring-and-slash glyphs along the line. The danger is visible, the lore is not in your face mid-dodge.

**Boss-bar instruction phrase is gone.** Phase 1 used to say `THE SUN — WITNESS THE SEALS 1/3`. Now it just says `THE SUN` with three pips next to the label, lit as seals break.

**Bleach is capped while the Sun is alive.** The full-screen white wash used to climb to ~0.86 during phase 3, hiding hitboxes under bloom. Now capped at 0.56 while the boss lives; the cap lifts on death so the finale can bloom hard.

### Sun damage source tagging
Every Sun-damage path now sets `state._v77LastDamageSource` before calling `damagePlayer`. Tags:
- `sun:sunlight` — heat-meter overflow outside shade
- `sun:ray` — quote-strike ray hit
- `sun:contact` — Sun core body contact

Read it from the console: `noMoonDamageDebug()`.

### Sun defeat: touch-to-win
The auto-timeout is gone. When the Sun dies:
1. The room is safed immediately (player invulnerable).
2. A stable black crater forms at room center (NOT at the random Sun-kill position).
3. A Return Sigil — cool blue ring with a doorway slit — appears below the crater.
4. The Sun visually falls into the crater (the v69 finale anchor is moved to the crater).
5. **Touch the Return Sigil to complete the win.**
6. First Sun clear: crater seals over with debris. Later clears: crater stays open (visual nod toward a future descent route through it; no softlock if you walk into it).

### Diagnostic helpers
- `state.v77Debug()` / `window.noMoonV77Debug()` — full snapshot: build tag, room state (including crater + sigil), player heat, last damage source, plus nested v76 / v39 debug.
- `window.noMoonDamageDebug()` — just the last damage source tag.
- `window.noMoonV77MakeMajorBossRoomSafe(room, bossId, opts)` — manual safe-room trigger.

## What was preserved from v76
- Starless approach + Ferry dock doors still render in world space (v76 fix).
- Night Ferry death copy still reads "THE NIGHT FERRY DROPS ANCHOR" (v76 fix).
- Star reroll widget on draft UI (v76 feature).
- Moots / Vesper portraits + story descriptions (v76 feature).
- Root website assets present (favicon, icons, manifest, OG image).

## Verification

In the browser, after hard refresh:

1. `state.v77Debug()` returns ok with `buildTag` ending `.v77`.
2. Pick up Lantern Pup + Siphon Vane + Aegis Lattice — confirm v55 Little Saint Engine crown still orbits, saint-bursts still fire (v55 preserved).
3. Take Sky/Starless route → Night Ferry death still reads correctly (v76 preserved).
4. Star reroll widget still appears on draft (v76 preserved).
5. Get to Sun throne room:
   - Three parasol shadows visible, each with a seal ring exactly inside it.
   - Standing in any seal charges it (arc fills) without dealing damage.
   - Heat meter ring appears above HUD when you stand in bright light; drains in shade.
   - Sun boss bar reads `THE SUN ● ○ ○` with pips lighting as seals break.
   - Take a hit → `noMoonDamageDebug()` tells you what kind: `sun:sunlight` / `sun:ray` / `sun:contact`.
6. Kill the Sun:
   - Room becomes safe instantly. No damage possible.
   - Sun falls into a stable black crater at the center.
   - A Return Sigil appears below.
   - Walking into the Return Sigil triggers the normal Sun-route win overlay.
   - On second clear: crater stays open (a small visual nod; doesn't softlock).
7. Test any other major boss kill (Warden, Archon, Night Ferry) — confirm no post-death damage possible.

## Known deferred
- Replacing baked-in ground text ("BEYOND THIS POINT, THE MOON WATCHES" etc.) in the rest of the game. Direct source edit, not a tail wrapper — too much surface for v77.
- The Starless Well dark-space descent through the open crater is planned but not implemented. The open crater is visual only for now.
