# No Moon v78 — Moots lock fix + Star reroll rebuild

Build tag: `qual.moots-lock-reroll-polish.2026-05-13.v78`
Service worker cache: `no-moon-moots-lock-reroll-polish-v78`
Drop-in replacement for v77.

## Upload instructions
Unzip and copy the contents to your web root. Folder layout matches v77 exactly.

```
/index.html                                          (landing, unchanged)
/book.html                                           (unchanged)
/no-moon.html                                        (unchanged)
/_redirects                                          (unchanged)
/no-moon-sw.js                                       (root cleanup SW, unchanged)
/assets/favicon.svg                                  (root branding, unchanged)
/assets/icon-192.png                                 (unchanged)
/assets/icon-512.png                                 (unchanged)
/assets/qualiacology-og.png                          (unchanged)
/assets/site.webmanifest                             (unchanged)
/no-moon/index.html                                  <- v78 IIFE injected
/no-moon/game_inline.js                              <- maintenance mirror
/no-moon/no-moon-sw.js                               <- CACHE_NAME bumped to v78
/assets/no-moon/...                                  (unchanged from v77)
```

## What changed in v78

### Moots death-screen no longer looks unlocked

Two bugs combined to make Moots appear "more clickable" on the death overlay than at game start:

1. **CSS scope bug.** The `.v68Locked` greying/desaturation styling was scoped to `#overlay.v66TitleSelect` (the title's character-select pane) only. On the death overlay (a different overlay class), the locked styling never applied — so Moots rendered full-color, full-opacity, with no greyscale or `cursor: not-allowed`. v78 injects a universal `.card.v68Locked` rule that applies on every overlay mode.

2. **False-unlock from reaching the final floor.** `mootsSource70` and my v75 `evidence75('moots')` chain both treated `highestBiomeReached >= TOTAL_BIOMES (10)` as a Moots unlock condition. But `stats.deepest = max(prev, levelIndex + 1)` bumps to 10 simply by *entering* the final boss room (level 9). On death, `commitRunSummary('dead')` then writes `highestBiomeReached = max(prev, deepest)` = 10, which permanently false-unlocked Moots without a win. v78 enforces a strict-unlock guard: Moots requires `lifetime.wins > 0`, `victories.routeClears > 0`, or `achievements.wins_1.unlocked`. Anything else is scrubbed from both the in-memory save AND the localStorage mirror (`noMoonProgress_v68`).

A document-capture click guard fires before v70's `characterGrid` capture handler so v70 can't promote Moots on click before the strict check runs.

`startGame('moots')` now falls back to Rook if Moots isn't strictly unlocked.

### Star reroll widget rebuilt

User reported: button rendered, but **clicking did nothing even with enough stars**. Plus the layout had the star count on the far left and the button on the far right of the ~1100px draft panel.

Root cause for the click: v76's reroll handler was a delegated capture listener on `draftUI` looking for `[data-v76-star-action="reroll"]`. Something in the wrap chain between v76 install and the click was preventing the handler from firing.

v78 fix: takes ownership of the widget entirely.
- v78 redraws the `#v76StarTrade` element after every `renderDraftUI` (its wrap runs after v76's).
- New CSS: compact pill, max-width 380px, centered, with proper hover/active states.
- Button uses a NEW id (`v78RerollBtn`) so v76's selector misses it.
- Click is bound directly to the button via `btn.onclick = ...` — no event delegation, no capture-phase. If the click reaches the button, the reroll runs.
- Reroll logic runs in v78, doesn't rely on v76's `rerollDraftForStars76`.
- Disabled-state text is now actionable: `Need 3★ more` instead of a greyed-out `Reroll grafts — 5★`.
- The `_v76StarRerolls` counter (which determines escalating cost) now resets at the start of each draft, instead of carrying over across biomes.

Cost remains: first reroll 5★, second 8★, third 11★, etc.

### Diagnostic helper
- `state.v78Debug()` / `window.noMoonV78Debug()` — strict-unlock state, draft state, reroll stats.
- `window.noMoonV78Reroll()` — manual reroll trigger for testing.

## Mobile performance (noted, not patched here)

A scan turned up two specific per-frame mobile bottlenecks:
- v67's `gearDock()` writes ~16 inline DOM styles every frame (~5ms each on iOS Safari WebKit when the value actually changes).
- v70's `drawBiomeSignature70()` does 30–80 canvas `beginPath/arc/stroke` calls per frame.

Both are real but require either direct edits to v67/v70 (closure-local functions) or a tail patch that gates by state-change. Deferred. Not blocking gameplay.

## Verification

In the browser, after hard refresh:

1. `state.v78Debug()` returns ok with `mootsStrictUnlocked: false` (assuming you haven't won the route yet).
2. Reach the final boss room and die — return to title — Moots card should still be locked (greyed, with "Locked · clear a route" badge).
3. Die at any point — return to character select on death overlay — Moots card looks greyed and locked, NOT full-color.
4. Pick up a draft. Widget appears as a centered pill: `★ N` on the left, `Reroll grafts — 5★` on the right. Both visually close together.
5. With < 5 stars, button reads `Need N★ more` and is disabled.
6. With >= 5 stars, click button → cards change → star count drops by 5.
7. Click again → cost is now 8★ → if you have enough, cards change again.
8. Pick a card / advance to next biome → next draft starts with cost reset to 5★.

## Preserved from prior builds

- v77 Sun fight readability + post-boss safety + Sun touch-to-win
- v76 starless doors, Night Ferry copy, passenger polish
- v55 Little Saint Engine + earlier v46-v54 fixes
