# No Moon v84 — Claude follow-up bug fixes on top of Pro's v83

Build tag: `qual.claude-followup-bugfixes.2026-05-14.v84`
Service worker cache: `no-moon-claude-followup-bugfixes-v84`
Drop-in replacement for v83. No new asset files.

## Upload
Unzip and copy to your web root. Same layout as v83 / v82.

## What v84 fixes (six bugs from BUG_REPORT_FOR_PRO_v83.md)

### CRITICAL — Alex's playtest reports

**1. Boss-death over-clear** (Warden room missing the teleporter / secret door)

Root cause: v77's `makeMajorBossRoomSafe77` set `room.cleared = true` directly at line 43242, bypassing the `setRoomCleared(level, room)` cascade. This skipped:
- Setting `room.exit.active = true` (the breach door opening) → softlock risk
- v71's wrap that installs the Warden room's hidden wall door + Ferry teleporter
- v68's wrap that charges Moots' Boon Moots active on boss-room clears

v84 wraps `killEnemy` outermost. After a major boss death, if `room.cleared` is set but `room.exit.active` is still false, v84 calls `setRoomCleared` itself — running the cascade v77 was missing.

**2. Reroll graft button click never fired**

Root cause: v78 bound `btn.onpointerdown = (e) => { e.preventDefault(); }` at lines 43957–43959. `preventDefault()` on `pointerdown` cancels the synthetic click on iOS Safari + most desktop browsers.

v84 wraps `renderDraftUI`. After every render, it sets `btn.onpointerdown = null` on the reroll button, leaving v78's `btn.onclick` to fire normally. Stars now spend, cards now change.

### HIGH

**3. Black Anchor trivialized boss bullets**

v82 checked `b.bossBeam || b.sunRay || b.majorHazard` to skip boss-class bullets — nothing in the codebase ever set those flags. Anchor slowed all boss patterns.

v84 wraps `updateGame` POST-base. Each frame, if any `e.boss === true` enemy is alive, freshly-pushed enemy bullets get tagged `bossBeam = true`. v82's anchor skips them. Anchor still works on mooks during boss fights — just not boss patterns.

**4. Mobile Black Anchor placed at screen center**

Root cause: v82 reads `input.mouse.x/y`. Touch devices never fire `mousemove`/`mousedown` — `input.mouse` stays at its init default `(W/2, H/2)`. v82's fallback only caught `(0,0)`.

v84 binds document-capture `pointerdown` + `touchstart` handlers that fire BEFORE v82's canvas-capture handler. On touch sessions (`input.mouse.seen === false`), it rewrites `input.mouse.x/y` to the screen-space projection of "200 px ahead of the player in their aim direction". v82's aim now produces the correct world point.

### MEDIUM

**5. Codex boss-card count desync**

v71 sometimes re-renders the deck via internal unlock events that don't go through the wrapped `openCodex`/`renderCodexStats`. The Drowned Sun 7th card disappears, count stuck at "6/6".

v84 installs a `MutationObserver` on the codex overlay. Whenever `.v71BossGrid` mutates, it re-appends the Drowned Sun card if missing and rewrites the count.

**6. Moots false-unlock window from v75 evidence**

v75 still grants Moots on `highestBiomeReached >= 10`. v78 scrubs eventually but leaves a brief in-memory window.

v84 hooks `safeWriteSave` PRE + `renderCharacterCards` PRE with a strict scrub: Moots requires a real win signal (`lifetime.wins > 0`, `victories.routeClears > 0`, or `achievements.wins_1.unlocked`). Nothing else. False unlock can't persist past one frame.

## Debug helpers

```js
state.v84Debug()           // stats — how many of each fix actually fired
noMoonV84Debug()           // same, on window
```

Stats block tells you when fixes engage:
- `bossExitFixes` — cascade-runs after major boss kills (should be ≥ 1 after killing Warden)
- `rerollPointerdownCleared` — count of broken handlers nulled (climbs every draft render)
- `bossBulletsTagged` — total enemy bullets tagged during boss fights
- `mobileAimRewrites` — touch sessions that triggered the aim rewrite
- `codexDrownedSunAppends` + `codexCountRewrites` — codex observer interventions
- `mootsScrubs` — false-unlock recoveries

## Verification (after upload + hard refresh)

1. `state.v84Debug()` → `buildTag` ends `.v84`, `cacheExpected` matches.
2. `noMoonV71ForceWardenApproach()` → kill Warden → confirm "BELLWAY CLEAR" message appears, the hidden wall door + Ferry teleporter spawn in the room. `state.v84Debug().stats.bossExitFixes` ≥ 1.
3. `noMoonV80ForceEnter()` → clear a room → draft appears with reroll widget → click reroll → cards change, stars drop. `stats.rerollPointerdownCleared` ≥ 1.
4. Fight Drowned Sun with Black Anchor in the arena → sweep rays + rings should NOT slow inside the anchor. `stats.bossBulletsTagged` climbs.
5. Mobile / DevTools mobile profile → start Nadir run → tap HUD slot → anchor appears IN FRONT OF the character, not at screen center. `stats.mobileAimRewrites` ≥ 1.
6. Open Codex → "X/7 revealed" with 7 cards visible. After Drowned Sun death + reopen → count jumps + Drowned Sun art shows.

## Build stack
- v76 → v82: Claude
- v83: Pro / GPT-5.5 (Nadir-unlock hardening, anchor slot tap-swallow, default-unlock normalize)
- v84: Claude (six follow-up fixes layered on Pro's v83 hardening)
