# No Moon v94 — Drowned Sky Expansion

Build tag: `qual.drowned-sky-expansion.2026-05-14.v94`
SW cache:  `no-moon-drowned-sky-expansion-v94`

Based on v93 fang-and-finale. v94 adds one IIFE on top of v93, no
changes to the existing patch tower.

## What's new in v94

The Drowned Sky route (the post-Sun crater destination) was already
8 rooms with a fork after v80 — v94 makes it FEEL like a real biome
instead of a marked-out path through a hallway. Specifically:

### 1. Tidefall — the signature environmental hazard

Cold-blue vertical beams of light pulse down through every Drowned
Sky room. Each beam follows a three-phase cycle:

- **Warn** (~0.5s): faint column appears in a random spot.
- **Bright** (~0.8s): full intensity, deals 1 damage if you stand
  in it.
- **Fade** (~0.4s): bleeds out.

Beams spawn one at a time per cadence, with the cadence and beam
width set per room kind:

| Room kind | Beams active | Spawn cadence | Beam width |
|-----------|--------------|---------------|------------|
| entry     | 1            | every 2.6s    | 70px       |
| spine     | 2            | every 2.1s    | 78px       |
| open      | 2            | every 2.0s    | 82px       |
| fork      | 2            | every 2.2s    | 76px       |
| side A/B  | 3            | every 1.8s    | 70px       |
| preboss   | 2            | every 1.7s    | 84px       |
| boss      | 1            | every 3.0s    | 88px       |

Entry rooms are gentle to teach the mechanic. Side rooms are the
most punishing because they're optional. Boss rooms are restrained
so the Drowned Sun's own attacks remain readable.

You learn this hazard without words — you see the cold-light column
warn, then brighten, and you slide sideways. After one or two hits
you know what's coming.

### 2. Drift Lantern — new enemy type

A slow, floating cold-light orb. Drifts toward the player at 36
speed (very slow). 5 HP, cost 5 in the spawn budget. Two ways to
kill it:

- **Shoot it**: it drops normal loot and leaves a delayed
  explosion ring (~0.55s telegraph, then radial damage + push).
- **Ignore it for 8 seconds**: it self-detonates with the same
  explosion ring.

The "about to detonate" warning bloom comes on in the last second
of life so a careful player can step away.

### 3. Cache shrine in the fork — Submerged Reliquary

The Drowned Sky fork has two side rooms (sideA / sideB). On every
descent, a coin flip picks one of them to become a **Submerged
Reliquary** with:

- 1 guaranteed module pickup at room center.
- 2 Drift Lanterns flanking it (so the reward is contested).

Makes the fork into a real choice instead of a cosmetic branch.
Picked deterministically once per level (idempotent — re-entering
the room doesn't re-roll).

### 4. Ambient

Every Drowned Sky room now gets:

- **Falling stars** — thin bright streaks falling vertically at
  random columns. ~1 every 0.7–2.4s. Pure cosmetic, no damage.
  Cap of 7 concurrent stars per room.
- **Broken submerged pillars** — in open / fork / side rooms,
  3–4 tilted dark pillars rising from the bottom of the frame
  with cold-violet rim light and faint crack lines. Static
  cosmetic, no collision (preserves v80's gameplay geometry).

## Build chain
```
v76–v82 (Claude) → v83–v85 (Pro) → v89 (Claude recovery)
                → v90 → v91 → v92 (Pro)
                → v93 (Claude: Captain Fang + Sun Finale polish)
                → v94 (Claude: Drowned Sky Expansion)
```

v86/v87/v88 are still skipped — codex loop. v94 does NOT install
any MutationObserver, does NOT touch the Codex DOM, and does NOT
replace v80's room-build pipeline. It layers on top via
syncActiveRoom / updateGame / updateEnemies / drawAmbientWorld /
drawEnemy / killEnemy POST-base wraps.

## Console checks after upload
- `state.v94Debug()` — current room (drowned sky? what kind?
  cache shrine? beam count? star count?), drift lantern count,
  cache side pick, stats.
- `state.v94SelfTest()` — boot tag check, Drift Lantern type
  registered, Tidefall profile coverage, cache-side idempotency.
- `noMoonCurrentDebug()` and `noMoonCurrentSelfTest()` now point
  at v94.
- `noMoonV93Debug()` still works for the captain/sun-finale layer.

## Upload
Unzip and copy to web root, replacing all v93 files. Hard refresh
once after upload so the browser drops the v93 service-worker
cache.
