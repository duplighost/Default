# No Moon v81 — Nadir + Drowned Sun Field Guide Card

Build tag: `qual.drowned-sun-nadir-final-passenger.2026-05-14.v81`
Service worker cache: `no-moon-drowned-sun-nadir-final-passenger-v81`
Drop-in replacement for v80.

## Upload
Unzip and copy to web root. Folder layout matches v80 — just two new images.

```
/index.html, /book.html, /no-moon.html, /_redirects   (unchanged)
/no-moon-sw.js                                        (root cleanup SW)
/assets/{favicon.svg, icon-192.png, icon-512.png,
         qualiacology-og.png, site.webmanifest}       (root branding)
/no-moon/index.html                                   <- v81 IIFE injected
/no-moon/game_inline.js                               <- maintenance mirror
/no-moon/no-moon-sw.js                                <- CACHE bumped + 2 new assets
/assets/no-moon/characters/nadir-portrait.webp        <- NEW
/assets/no-moon/bosses/drowned-sun-card.webp          <- NEW
... rest unchanged from v80
```

## What v81 adds

### Nadir — Low-Star Diver, the final Passenger

The 7th Passenger card. **Locked until you defeat the Drowned Sun.**

- HP 5, Speed 252, Damage 1.02, Fire delay 0.24
- Weapon: **Low-Star Orbit** (custom branch)
  - Up to 3 simultaneous "stars" — each shot is one star
  - Each fired star cools down 0.72s before it can fire again
  - Stars pierce one enemy
  - If all 3 are on cooldown, fire emits a weak emergency spark so the controls never feel dead
- Card description: *"Found below the Drowned Sun. Three low stars orbit him, bending bullets, pulling enemies, and making the dark answer back."*
- Tags: `Unlockable`, `Gravity control`, `Orbit shots`
- Unlock hint: `Defeat the Drowned Sun.`

### Custom in-game form

Nadir doesn't inherit the generic body shape. v81 wraps `drawPlayer` so that when his template id is selected, a custom top-down form renders:
- Dark cloak (aim-aligned cubic-bezier silhouette)
- Black solar-disk head with a drowned-gold fracture
- Two orbit rings rotating opposite directions
- **Three orbiting stars** — bright when ready to fire, dim when on cooldown (so you can see your ammo state at a glance)
- Cool cyan gravity glow under everything
- Front aim glint

### Drowned Sun added to the Field Guide

Codex → **The Defeated** deck. The deck used to be `X/6 revealed`. Now it's `X/7 revealed` and the new 7th card is the Drowned Sun:
- Sealed (`card-back.webp` + "Sealed") until you've defeated the boss
- Revealed (`drowned-sun-card.webp` + "Drowned Sun" + "Defeated") afterwards

The v71 boss-deck array is closure-local, so the new card is appended via DOM after each Codex render, and the count text is rewritten in place.

### Unlock flow

Killing the Drowned Sun (v80's `v80DrownedSun` boss, also accepts v79's older `v79DrownedSun` for backwards compat) writes both:

```js
save.defeatedBosses.drownedSun = true
save.unlockedCharacters.nadir = true
save.victories.drownedSunClears = max(1, …)
```

Mirrored to `noMoonProgress_v68`. A short message pops in-world: `NADIR SURFACES`.

v80's Cold Lantern touch already writes the `drownedSun` flag too — v81 hooks `safeWriteSave` PRE so if you walk into the Cold Lantern after killing the boss in a way that bypassed the killEnemy hook, Nadir still auto-unlocks the next time the save is written.

### Strict-unlock guard

Same shape as v78's Moots fix:
- Document-capture click guard on the Nadir card — runs before v66/v68/v70 handlers, so locked Nadir can't be promoted by clicking the card.
- `startGame('nadir')` falls back to Rook if Nadir isn't strictly unlocked.
- `safeWriteSave` scrubs `save.unlockedCharacters.nadir = false` if the strict condition isn't met. Same for the mirror.

### Mobile

- Universal lock CSS from v78 still applies (`.card.v68Locked` works on every overlay mode).
- New `.v81NadirBadge` has explicit small-screen overrides at `max-width:720px` (smaller padding, smaller font, allows wrap).
- The Field Guide grid is already responsive (`repeat(3)` → `repeat(2)` at 820px → `1fr` at 460px) so the 7th card just adds a row on mobile.

### Debug helpers
- `state.v81Debug()` / `noMoonV81Debug()` — full snapshot (Nadir installed? strict-unlocked? in save? in mirror? Drowned Sun flag? Nadir star state? full v80/v79/v78 chain)
- `noMoonV81UnlockNadir()` — manually unlock Nadir (sets flags + re-renders)
- `noMoonV81LockNadir()` — manually re-lock for testing the lock UI

## Verification

After hard refresh:

1. `state.v81Debug()` returns ok. `nadirInstalled: true`, `nadirStrictUnlocked: false` (assuming you haven't beaten Drowned Sun yet).
2. Character select shows 7 cards. **Nadir is the rightmost, locked, with badge `Locked · defeat the Drowned Sun`.**
3. Click Nadir → pushMessage "Defeat the Drowned Sun to wake Nadir." Card stays locked.
4. Try `startGame('nadir')` from console while locked → falls back to Rook.
5. Open Codex → **Field Guide → The Defeated** shows `X/7 revealed`. 7th card is sealed.
6. Run `noMoonV81UnlockNadir()`. Nadir card becomes selectable with badge `Unlocked · low-star orbit`. Codex 7th card reveals with the Drowned Sun art.
7. Start a run as Nadir. **Live form**: black sun head + 3 orbiting cyan stars + dark cloak. **Firing**: stars deplete to dim/ghost when fired; they pop back to bright after ~0.72s. **Weapon damage**: feels close to twin-relay tier.
8. Mobile check: confirm Nadir card + badge readable at small width; confirm Codex deck shows 1-column at 460px.
9. Real playtest: descend through the open Sun crater, beat the Drowned Sun → confirm `NADIR SURFACES` message, confirm Nadir unlocks, confirm Drowned Sun Field Guide card reveals.

## Preserved from prior builds
- v80 Drowned Sky stage (8 rooms, 3-phase boss, Safe Haven Cold Lantern shrine)
- v79 base Drowned Sky systems
- v78 Moots strict-unlock + star reroll widget rebuild
- v77 Sun fight readability + post-boss safety + touch-to-win
- v76 starless doors, Night Ferry copy, passenger polish
- Older v46-v75 fixes
