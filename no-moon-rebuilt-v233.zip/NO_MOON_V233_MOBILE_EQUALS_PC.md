# No Moon v233 — Mobile equals PC

User insight: "why can't we just make the mobile one basically like the
PC one except for the sizing or stuff that needs to be changed for mobile?"

Answer: we can, and earlier mobile-specific "performance optimizations"
were the actual source of the decorated flicker.

## Stack

v99 (base) → rebuilt (consolidated patch) → v230 (Firefox obstacle ring
stabilizer — keeps the v98 spawn-safety disable that fixed PC) →
v233 (this — rips out mobile-specific FX gating so mobile runs the
PC render path).

Build tag: `qual.mobile-equals-pc.2026-05-17.v233`
Service worker cache: `no-moon-mobile-equals-pc-v233`

## What this layer does

Forces all mobile-specific FX gating off so mobile renders identically
to PC. Each item is a runtime config flip reasserted every `updateGame`
tick; no algorithm changes.

1. `state._v98SpawnSafeUntil = 0` — always. This is the actual PC fix
   from v230; we lift it out of v230's `lowFx()` gate so it applies
   regardless of device.
2. `state.v230LowFx = false` — turns off v230's damageObstacle FX
   suppressor and v230's tighter dt/particle clamps. Mobile renders
   explosions exactly like PC.
3. `state.v82BlackAnchor.config.MOBILE_AMBIENT_SKIP = false` — the
   "every other ambient frame" optimization that produced the 15Hz
   petal wink on mobile. Off.
4. `state.v82BlackAnchor.config.MOBILE_SPARK_HALF = false` — was
   halving spark count on mobile. Off, mobile sees the full count.
5. `state.v82BlackAnchor.config.MOBILE_RING_LIMIT = 0` — was capping
   rings to 4/frame on mobile. Off, no cap.
6. `state.v67HazardUiEndingClarity.config.hazardLanguage = true` —
   PC has this on, mobile gets it too. (v231 turned it off on low-FX;
   v233 supersedes that.)

Mobile-specific things that legitimately stay (engine handles already):
input mode (touch vs mouse/keyboard) and UI scaling.

## Console checks

```js
noMoonV233SelfTest()    // → ok: true; v82.ambientSkip: false; v230LowFx: false; hazardLanguage: true
noMoonV233Debug()       // see all the flag states
noMoonCurrentSelfTest() // alias
```

## Trade-off

If mobile hardware is genuinely too slow for the full PC render path,
this build will show real frame-rate drops instead of the decorated
flicker. That's diagnostic info, not a regression — we'll know where
the real performance wall is and can add ONE targeted cap if needed,
not a stack of misguided optimizations.
