Qualiacology site — No Moon v279 hybrid: v278b base + Archon + Seentists + OG

Upload contents to site root. This bundle uses ChatGPT v278b Mission Remnants as the base because it has the safer final-boss/remnant cleanup, then layers v279 polish on top: QA-respecting Archon Field Guide persistence/repair, Seentist Safe Haven identity visuals, real Open Graph landing pages/images, and removal of duplicate book PNG fallbacks.

Base build tag:
  qual.v278b-patient-mission-remnants-fieldguide.2026-05-24.v278b

Final build tag:
  qual.v279-hybrid-archon-seentists-og.2026-05-24.v279

Core preserved contracts:
  - no-moon/game_inline.js, index_script.js, and the inline script in
    no-moon/index.html are synced exactly.
  - Service-worker registration remains absent. Existing service-worker files
    are cleanup/unregister stubs only.
  - The v272-v275 title/start/passenger/fresh-run/ending guard stack is left
    intact.
  - Legacy bad title-branch strings remain absent from the shipped game code.

What changed from v277:

1. Replaced the fast room-entry Risen Walker cascade.
   v277 woke too many bodies too quickly and then snapped them into a smaller
   enemy that did not feel like the corpse that got up. v278b keeps the idea but
   changes the pacing and presentation.

2. Mission Remnants now rise slowly and read as the same astronaut body.
   - Mobile rise time is intentionally slower: roughly 3.75-4.6s depending on
     room/body seed.
   - Desktop is slower than v277 too: roughly 3.2-4.0s.
   - The body first twitches/queues, then draws a prone suit plus a standing
     suit fading upward, then becomes hittable.
   - During the rise, the suit has no real enemy hitbox/contact damage.
   - When active, it is a full standing astronaut suit with pale fabric, black
     visor, cyan visor leak, backpack/tether language, and a larger silhouette.

3. More nuanced Drowned Sky pacing.
   - The current room is the only room evaluated. Previous rooms do not wake in
     the background.
   - Ceiling/hanging remains stay decorative.
   - Not every corpse becomes hostile.
   - Cold/entry rooms stay quieter.
   - Broken Shipyard / Moon-Maw can wake a small number of floor bodies.
   - First Walker room wakes bodies in a paced way: one at entry, then phase
     pressure can wake more. Mobile cap is lower.

4. Final boss cleanup.
   - The Drowned Sun / final-boss room is explicitly excluded from Mission
     Remnant spawning.
   - If any cached/hot remnant state leaks into the final boss room, v278b marks
     the remains decorative, removes remnant enemies, clears remnant bullets,
     and clears leftover First Walker transient FX.
   - This should remove the odd remnant-origin flashes near the last boss. The
     Drowned Sun still has its own intentional eclipse/pulse visuals from older
     boss code.

5. Room-clear and trophy timing.
   - Queued, rising, or active Mission Remnants keep the room uncleared.
   - This prevents the First Walker arena from resolving while real remnant
     enemies are still present.
   - Broken Tether trophy offer is deferred if First Walker dies while remnant
     threats are still active, then released once they are cleared.

6. Field Guide repair/audit.
   - Existing boss-card systems are preserved.
   - v278b repairs/refreshes the Sun, First Walker, and Drowned Sun card states
     when the Field Guide opens or visible codex stats render.
   - QA evidence can show cards in-session, but v259/v260 intentionally block QA
     from becoming permanent career unlock evidence.
   - Real non-QA kills should persist through defeatedBosses/victories save
     evidence.

Console helpers:
  noMoonCurrentSelfTest()          -> now points at v279; should return ok:true
  noMoonV278SelfTest()             -> wrapper/registration test
  noMoonV278Debug()                -> current Drowned Sky/remnant/card evidence
  noMoonV278FieldGuideAudit()      -> late-boss evidence/card status
  noMoonV278FieldGuideStatus()     -> repair + return late-boss card status
  noMoonV278RepairFieldGuide()     -> force Field Guide repair pass
  noMoonV278SpawnRemnant()         -> test-spawn one remnant in current room
  noMoonV278WakeRemnants()         -> force current-room dormant remnants to wake
  noMoonV278ReleaseWalkerTrophy()  -> manually release deferred Walker trophy
                                     if testing gets weird

Recommended QA after upload:
  1. Visit /no-moon/?fresh=1.
  2. Confirm title video -> START -> Passenger Select -> Descend still works.
  3. Confirm no Moon zoomout fires on a fresh run.
  4. Play/QA into the Drowned Sky route.
  5. In Broken Shipyard or Moon-Maw, verify astronaut bodies do not instantly
     pop into a tiny enemy. They should slowly get up as the same full suit.
  6. On mobile, confirm the pacing feels readable and not like a flashbang.
  7. In the Buried Habitat, confirm First Walker pressure can wake suits without
     an all-body instant cascade.
  8. Defeat First Walker; if remnants remain, the room/trophy should wait until
     they are dead.
  9. Enter Drowned Sun / final boss. No Mission Remnants should wake there.
 10. Open Field Guide and run noMoonV278FieldGuideAudit() if late-boss cards
     look wrong.

Validation performed before this ZIP:
  - node --check no-moon/game_inline.js
  - node --check index_script.js
  - node --check no-moon/no-moon-sw.js
  - node --check no-moon-sw.js
  - index_script.js == no-moon/game_inline.js
  - no-moon/index.html inline script == "\n" + game_inline.js + "\n"
  - serviceWorker.register absent
  - legacy bad title strings absent from game code
  - v277 Risen Walker install block absent. Cleanup references to old
    v276/v277 remnant type names remain intentionally so final-boss purging can
    kill stale cached enemies if they appear.
  - v278b build marker present
  - node --check passed for game scripts/service worker stubs
  - noMoonV278FieldGuideAudit() exists and returns evidence/card status
  - unzip -t final ZIP

Hybrid v279 notes:
  - Base is ChatGPT v278b Mission Remnants because it has the safer Drowned Sun/final-boss sanitizing, remnant projectile purging, First Walker FX cleanup, room-clear guard, and trophy deferral.
  - Added a small QA-respecting Archon Field Guide persistence/repair layer. Real non-QA Archon kills write save.defeatedBosses.archon; QA kills can show as Seen this run without polluting career save data.
  - Added The Seentists as a visual/copy layer in Safe Haven only: slatted anti-moon baffles, crossed-out moon plaque, wrapped telescope, cover-one-eye figure, and title overlay wording. This does not add gameplay mechanics, hitboxes, room flags, enemies, routes, boss hooks, or ending hooks.
  - Added real Open Graph/Twitter-card metadata with absolute URLs: 1200x630 Open Graph images, plus separate exact 1200x600 Twitter/X large-card crops for /, /no-moon/, /doopliss/, /this-helped-someone/, /psychopharmacology/, and book.html. The section URLs are real 200 pages so link preview crawlers get unique heads, then browser users redirect to the intended section/page.
  - Removed the two large duplicate book PNG fallbacks and pointed those <img> fallbacks at the existing WebP files. OG images are versioned under /assets/og/.

Build tag:
  qual.v279-hybrid-archon-seentists-og.2026-05-24.v279

Console helpers added:
  noMoonV279SelfTest()
  noMoonV279Debug()
  noMoonV279RepairArchon()
  noMoonV279SeentistOverlay()
  noMoonCurrentSelfTest() -> now points at v279, which also checks v278 when available.


v280 additions:
- Replaced generated placeholder OG previews with the supplied final social images.
- Added exact 1200x630 Open Graph crops and 1200x600 Twitter/X crops under /assets/og/.
- Added very quiet site ambient music from Jelly Strobe (instrumental) as a compressed MP3 at /assets/audio/jelly-strobe-instrumental-v280.mp3.
- Ambient audio is enabled on the main site and book page only, starts after a user gesture to satisfy browser audio rules, loops quietly, has baked-in low gain for mobile safety, and has a small bottom-right toggle.
- No Moon game page intentionally does not load the site ambient script, so game audio/state stay isolated.
