Qualiacology site — vibrant pass + book figure scaffolding

Upload contents to site root. Layered on top of the previous Discord-swap
+ book-cleanup bundle. No Moon game is unchanged from v275 hard-guard.

What changed this bundle:

1. Visual: vibrant pass on index.html AND book.html.
   - Animated aurora layer (slow drifting multi-color glow) behind content.
   - Hero titles now use a shimmering rainbow gradient (pink to violet to
     cyan to gold) that slowly flows. No flicker; honors prefers-reduced-motion.
   - Section glows on the homepage now breathe in/out and are more saturated.
   - All H2 section headings get a small pink->violet->cyan accent bar above.
   - Cards (portal/music/game/book/community) lift on hover with a violet halo.
   - Blockquotes in the book now have a tri-color gradient edge.
   - Active nav link gets a vibrant gradient underline.
   - Brighter text selection color (pink/cyan blend).
   - Reduced-motion users see static versions; nothing breaks.

2. Book figures wired up in the right places.
   - "The Multi-Axial Framework: A Visual Guide" section now has a <figure>
     ready for assets/book/five-axis-framework.png (or .webp).
   - "Levels of Understanding: Three Ways to View" section now has a <figure>
     ready for assets/book/three-levels-understanding.png (or .webp).
   - Both figures use a .book-figure class with:
       * Centered, max-width to the reading column
       * Glowing violet edge that intensifies on hover
       * Capitalized cyan caption with delicate dash dividers
       * Responsive: scales down on mobile cleanly
   - GRACEFUL FALLBACK: if the image file is missing, the figure auto-hides
     via onerror (no broken-image icon). So you can preview the new layout
     before you upload the actual images.

To finish (one step):
   - Upload your two PNG/WebP files into assets/book/ with these names:
       assets/book/five-axis-framework.png
       assets/book/three-levels-understanding.png
     (WebP is preferred for file size; either format works. You can also
      use both a .webp and a .png side-by-side — the picture tag prefers
      WebP if present, falls back to PNG.)
   - That's it. The figures will appear automatically.

3. Discord URL swap and book section deletions preserved from prior bundle.

Quick QA after upload:
   - Open index.html: hero title should shimmer through pink/violet/cyan/gold.
   - Scroll past sections: glows should slowly breathe.
   - Hover any card: it should lift with a violet halo.
   - Open book.html: hero title shimmers, sections have small color accent bars,
     blockquotes have rainbow edges.
   - When images are uploaded to assets/book/: figures appear in the
     Multi-Axial Framework and Levels of Understanding sections.

   noMoonCurrentSelfTest() in the No Moon console should still pass.
