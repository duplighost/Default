# No Moon v240 — Sigil removed (not hidden), crater is the only exit

Build tag: qual.sigil-removed-crater-only.2026-05-19.v240
SW cache:  no-moon-sigil-removed-crater-only-v240

Layered on top of ChatGPT's v236 root-cause-surgery. Replaces v239's
"hide the sigil" approach with full object removal.

## Changes

1. Sigil REMOVED: each frame, in any room that has _v77SunReturnSigil,
   the property is set to null. Verified the surrounding guards still
   pass via the crater reference (43254, 48508, 48654, 49347, 50967,
   53514 all check `crater || sigil || ...`).

2. Crater forced open + active so it's the only path forward.

3. Obstacle dust crumble: 6 small brown sparks (count 2, speed 36-64)
   emitted after a breakable obstacle dies. Slips through ChatGPT's
   gold-burst suppression filter.

4. Tidefall beams off in non-boss Drowned Sky rooms. Boss arena
   keeps Tidefall.

## Console

  noMoonV240SelfTest()    // ok: true
  noMoonV240Debug()       // stats.sigilsRemoved, etc.
  noMoonV236SelfTest()    // ChatGPT v236 wraps still all true
