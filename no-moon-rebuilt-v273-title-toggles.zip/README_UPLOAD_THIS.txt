No Moon v273 — title toggles restored

Upload the contents of this ZIP to the site root, preserving folders.

Stable checkpoint preserved:
- v269 mobile title / portrait / passenger-scroll fixes intact.
- v270 + v271 First Walker boss trophy / field guide intact.
- v272/v272b title video restore + decoder fix intact.
- Service worker registration remains disabled.
- The bad v265 Passenger List/front-door title branch is absent.

v273 additions:
- Restores #audioToggle (SFX) and #musicToggle (BGM) visibility on the
  title screen across:
    * splash on desktop AND mobile (v66 + v268 hide rules overridden)
    * passenger select on mobile (v66's mobile @media hide rule overridden)
- #hudMenuBtn (settings cog) intentionally left hidden on splash.

What's NOT in v273:
- No music change. The two title music m4a files (Suno tracks) are still
  in assets/no-moon/title/. They'll play when you toggle music on. If you
  want them removed/replaced, that's a separate decision — your call.

Console checks:
noMoonV273SelfTest()    // expect ok:true with audio/music display!='none'
noMoonV273Debug()       // shows current toggle visibility
noMoonV272SelfTest()    // unchanged — video should still be ok
noMoonV271SelfTest()    // unchanged — trophy fix still ok
