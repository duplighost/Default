Qualiacology site — No Moon v310: full playtest-fix pass

Upload the CONTENTS of this folder to your site root (drop-in replacement).
Build tag (verify in the browser console with noMoonCurrentBuild()):
  qual.v310-full-playtest-fixes.2026-06-03.v310

v310 fixes all six reported issues (stacked on the v307 finished-release build):
  1. Boss "marker-drop" circles REMOVED. Those big rings that appeared when you
     stood back from a boss never dealt damage (a one-shot timing bug) and just
     piled up. Gone now. The sun-boss phase-1 "seal" circles you stand in to
     advance the fight are a SEPARATE system and are untouched.
  2. Sun light is CONTINUOUS instead of pulsing on a day/night cycle. Standing in
     open sun steadily fills the heat meter and costs health if you linger; shade
     drains it and is the safe spot. (Confirmed working live; the pace is gentle -
     say the word and I'll make the sun bite faster.)
  3. The hidden "pressure" penalty that secretly lowered max integrity is REDUCED:
     none until floor 8 (was floor 6), then -1 on floors 8-9 and -2 on floor 10
     (was -1/-2/-3 on 6/8/10). A +1 max-HP graft now visibly works on the mid
     floors instead of being silently cancelled.
  4. The minimap uses ONE stable renderer, so a fresh run and a restarted run draw
     the same room glyphs/links - no more run-dependent overlay making the map
     look different on a second run. (Merged from the v309 audit work.)
  5. The door "forecast" glyph coating is HIDDEN once a room is cleared, so cleared
     rooms have clean doorways. Uncleared rooms still hint what's behind each door.
  6. The floor map RETURNS after a boss. Map suppression now requires a genuinely
     LIVE boss or a truly-open reward draft; a defeated boss that lingered a frame
     in the enemy list used to keep the map hidden.

Verified headless: boots clean (0 errors), build tag = v310, the ending/route is
intact, markers gone, max-HP penalty reduced, sun continuous (live), minimap
renders, and the boss/draft map-gate releases for a dead boss while still hiding
for a live one. Issues 4 and 6 (map-after-boss) and 5 (door coating) are fixed by
construction + logic test; please confirm the in-game feel on your device.

------------------------------------------------------------------------------
(Older note, kept for reference)
Qualiacology site - No Moon v281: bloom skip for mobile + Firefox

Upload contents to site root. This is the v280 bundle (v278b Mission Remnants
+ v279 Archon/Seentists/OG + v280 ambient/social images) plus one small
performance patch: v281 skips the bloom pass on mobile viewports and Firefox.

v281 bloom skip patch:
  Build tag: n/a (does not override the v279 HUD tag — render-only change)
  Install block: installV281SafeBloomSkip (line 69936)

  What it does:
    Wraps drawBloomPass(). Before calling the base function, checks:
      - W < 760 (mobile viewport)
      - navigator.maxTouchPoints > 0 (touch device)
      - /Firefox/i in user agent
    If any is true, returns immediately — skips the canvas copy + blur(11px)
    + screen composite that runs every frame.

  What it does NOT do:
    - Does not touch gameplay, routing, saves, ending, or any state
    - Does not change desktop Chrome rendering (bloom still runs at >= 760px)
    - Does not remove the bloom function — just gates it
    - Does not affect any other patch in the v275-v279 stack

  Why:
    The bloom pass copies the full canvas to a half-res bloom canvas, applies
    ctx.filter = 'blur(11px) saturate(1.16)' and composites back with
    globalCompositeOperation = 'screen'. This is the single most expensive
    per-frame operation. Chrome desktop handles it well. Mobile phones and
    Firefox cannot — Firefox lags from room 1, mobile drops frames during
    particle-heavy moments (breakable explosions, pickup glows).

    v233 "Mobile equals PC" intentionally disabled all earlier mobile FX
    mitigations (ambient skip, spark half, ring limit) because those caused
    visible flickering. The bloom pass was never gated. This patch fills
    that gap.

  Visual difference on mobile/Firefox:
    The game looks slightly crisper/sharper — no soft blur halo around bright
    objects. All gameplay elements (player, enemies, obstacles, pickups, HUD,
    text, glows) render identically. Verified in headless Chromium via
    Playwright at 720x480 viewport.

  Console check:
    The patch is inside the game IIFE. No new window.* helpers are exposed
    (it's too simple to need debug functions). The existing self-tests
    (noMoonCurrentSelfTest, noMoonV279SelfTest, noMoonV278SelfTest) are
    unaffected.

Everything else from v280 is preserved:
  - v278b Mission Remnants (Drowned Sky astronaut enemies, slow rise,
    Drowned Sun room exclusion, room-clear guard, trophy deferral)
  - v279 Archon Field Guide persistence (QA-aware)
  - v279 Seentists visual/copy layer
  - v279/v280 Open Graph metadata + Twitter cards
  - v280 Jelly Strobe ambient audio on / and /book.html
  - Book figures (five-axis-framework.webp + three-levels-understanding.webp)
  - Vibrant visual pass on index.html + book.html
  - Discord URL swap + book section deletions
  - v275 fresh-run-reveal hard-guard
  - v274 re-entry prompt
  - All prior patch stack preserved

QA after upload:
  1. Chrome desktop: game should look identical to v280 (bloom still runs).
  2. Chrome mobile: game should look slightly less glowy but run smoother.
     Test breakable obstacles on floor 1 — the slowdown should be reduced.
  3. Firefox: game should be noticeably less laggy from room 1.
  4. /no-moon/?fresh=1 — confirm no ending zoom on fresh run.
  5. noMoonCurrentSelfTest() — should still return ok: true.
