# No Moon v234 — QA: Sun Battle tap zone (on top of v233)

Adds a "QA" button (44x44, top-left) and noMoonQAToSunBattle() function
that cheats into the sun fight with a second-playthrough save state.

Build tag: qual.qa-sun-battle-tap-zone.2026-05-17.v234
SW cache:  no-moon-qa-sun-battle-tap-zone-v234

What the QA button does:
1. localStorage['noMoon.v39.sunPathClearCount'] = '1'  (open-crater path)
2. Marks save as 2nd-run (wins>=1, defeatedBosses.sun=true)
3. startGame(currentChar) — fresh run
4. state.v39GoSun()  — teleport to sun throne
5. applyReward x6: marrow, marrow, amp, amp, rapid, frame
6. HP -> maxHp + 1.6s invuln

Console: noMoonQAToSunBattle()  /  noMoonV234SelfTest()  /  noMoonV234Debug()
