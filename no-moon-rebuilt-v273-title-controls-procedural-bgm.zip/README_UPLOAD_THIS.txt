No Moon v273 — title controls + procedural BGM

Base: Claude v272b title-video restore, preserving v271 First Walker field guide/trophy work.

Upload the contents of this ZIP to the site root, preserving folders.
Then open /clear.html once if an old browser cache is still sticky.
Clean test URL: /no-moon/?fresh=1

Focused changes:
- Keep the working title videos.
- Restore SFX/BGM toggles on title splash and mobile Passenger Select.
- Disable/remove old title-song m4a assets.
- Route title/character-select BGM through the original procedural synth instead.
- Preserve First Walker, Broken Tether, Drowned Sky expansion, Moon Skiffs, constellation branch, and service-worker-disabled state.

Console checks:
noMoonV273SelfTest()
noMoonV273Debug()
noMoonV272SelfTest()
noMoonV271SelfTest()
