No Moon v274 — ending re-entry + unlabeled Moon constellations + First Walker visual cleanup

Base: v273 title controls + procedural BGM.

Upload the contents of this ZIP to the site root, preserving folders.
Then open /clear.html once if an old browser cache is still sticky.
Clean test URL: /no-moon/?fresh=1

Focused changes:
- Stops the post-final-boss Moon pullback from looping/re-arming after completion.
- After the zoom-out/blink, shows a NO MOON re-entry prompt; pressing the main button starts a fresh Floor 1 run.
- Removes text labels from the boss Moon-pattern constellation overlays.
- Replaces the older overlapping constellation HUD/reveal add-ons with one unlabeled screen-space Moon map so the gameplay pattern and zoom-out pattern use the same coordinates.
- Changes the First Walker astronaut remains from pointer/reacher blobs into more detailed collapsed suit debris.
- Replaces arrowhead-looking Drowned Sky wrecks and the big offscreen edge arrows with subtler diegetic glints/scrap.
- Preserves v273 title controls/procedural BGM, v271 First Walker field guide/trophy work, and service-worker-disabled state.

Console checks:
noMoonV274SelfTest()
noMoonV274Debug()
noMoonV273SelfTest()
noMoonV271SelfTest()
