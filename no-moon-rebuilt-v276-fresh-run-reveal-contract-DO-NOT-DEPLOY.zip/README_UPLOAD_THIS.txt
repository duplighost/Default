No Moon v276 — fresh-run/reveal contract hardening

Upload contents to site root. This build is based on uploaded v275 and adds a narrow Passenger Select -> fresh run guard plus reveal gating. Title/video/UI code was not redesigned.
