# No Moon v235 — Validation Report

## Static checks

- [x] game_inline.js: v235 installer present
- [x] game_inline.js: build tag present
- [x] game_inline.js: cache present
- [x] game_inline.js: volatile wrapper present
- [x] game_inline.js: Sun seal pulse wrapper present
- [x] game_inline.js: first clear crater override present
- [x] game_inline.js: Drowned boss door lock present
- [x] game_inline.js: Cold Lantern ceremony present
- [x] index.html: v235 installer present
- [x] index.html: build tag present
- [x] index.html: cache present
- [x] index.html: volatile wrapper present
- [x] index.html: Sun seal pulse wrapper present
- [x] index.html: first clear crater override present
- [x] index.html: Drowned boss door lock present
- [x] index.html: Cold Lantern ceremony present
- [x] service worker cache v235

## Syntax checks run

- `node --check no-moon/game_inline.js` — passed
- Extracted inline `<script>` from `no-moon/index.html` and ran `node --check` — passed

## Important implementation notes

- Sun seal hazards were traced to the Sun boss phase-1 attack calling `addPulseHazard()` at one of the required seal coordinates. v235 retargets only that class of pulse hazard in the Sun throne room instead of deleting the hazard system.
- The actual seal pads are safe objectives in `updateSunSeals39()`; v235 changes their visual language to cyan objective pads so they do not read like damage circles.
- Volatile obstacle explosions are disabled by clearing `obstacle.volatile` before the existing detonation wrapper can see it. Normal obstacle breakage remains intact.
- The Drowned Sky door fix is scoped to `_v80RoomKind === "boss"` / `_v79RoomKind === "boss"` and only disables `_v80Doors` while the Drowned Sun is alive or the Cold Lantern is present.
- The Cold Lantern pickup is intercepted before v80's immediate win tick, creating a short ceremony and then recording the Drowned Sky victory.
