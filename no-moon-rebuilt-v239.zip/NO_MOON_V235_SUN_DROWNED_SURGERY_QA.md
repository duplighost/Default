# No Moon v235 — Sun / Drowned Sun Surgery QA

## Build

- Build tag: `qual.sun-drowned-surgery.2026-05-18.v235`
- Cache: `no-moon-sun-drowned-surgery-v235`
- Primary files patched:
  - `no-moon/index.html`
  - `no-moon/game_inline.js`
  - `no-moon/no-moon-sw.js`

## Findings

### Sun throne ground hazards

The suspicious hazardous circles in the first Sun boss room were not random room generation. In phase 1, `tickSunBoss39()` intentionally chose one of `room._v39SunSeals` and called `addPulseHazard(room, tx, ty, ...)` at that seal coordinate. That put a damaging pulse telegraph directly on top of the required stand-on objective pads.

v235 wraps `addPulseHazard()` and, only in the Sun throne room, retargets pulse hazards away from the seal pads. If no safe spot exists, the pulse is suppressed. v235 also scrubs existing pulse/ritual hazards overlapping the seals in that room.

### Sun seal pads

`updateSunSeals39()` does not damage the player; the pads themselves are safe objective pads. They looked dangerous because the visual language overlapped with hazard circles. v235 draws a cyan/white objective overlay on the pads during phase 1 so they read as “stand here” rather than “ground hazard.”

### First Sun clear routing

The rebuilt patch deliberately made first clear use a Return Sigil/go-home object and kept the crater sealed. v235 overrides only that first-clear state: the crater is open and active, and the Return Sigil is disabled/hidden. Later clear behavior is left mostly intact.

### Drowned Sky boss doorway

v80 created a back door in the Drowned Sun boss room, so the player could leave mid-fight. v235 locks only the boss-room `_v80Doors` while the boss is alive or the Cold Lantern is present. It does not broadly delete Drowned Sky doors, which protects the odd final-floor doorway network.

### Drowned Sun boss/victory

The Drowned Sun now gets:

- HP floor raised to at least 840 on first tune.
- Arena tethering to prevent wall-hugging.
- Extra readable bullet patterns layered over the existing v80 phase logic.
- A rotating corona/eclipse visual overlay.
- Cold Lantern pickup ceremony before the win screen.

## Manual QA checklist

1. Load `/no-moon/` and confirm the visible build tag is `qual.sun-drowned-surgery.2026-05-18.v235`.
2. Open console and run `noMoonV235SelfTest()`; expected `ok: true`.
3. Use the QA button to jump to Sun battle.
4. During Sun phase 1, confirm the three stand-on pads are cyan/white objective pads and that pulse hazards no longer spawn on top of them.
5. Break any volatile shard obstacle in a normal/shard room and confirm it breaks without chain explosion/player blast.
6. Kill the first Sun. Confirm the go-home sigil does not appear/activate and the crater is open/usable for Drowned Sky.
7. Enter Drowned Sky and reach the boss room. Confirm the back doorway does not let the player leave during the Drowned Sun fight.
8. Fight Drowned Sun. Confirm it stays inside the arena, uses the added patterns, and has a clearer crown/eclipse silhouette.
9. Kill Drowned Sun and touch the Cold Lantern. Confirm a short ceremony plays before the win overlay.

## Console diagnostics

`noMoonV235Debug()` exposes counters for retargeted/suppressed Sun pulses, removed seal-overlapping hazards, disabled volatile explosions, locked Drowned Sun doors, wall rescues, added boss patterns, and Cold Lantern ceremonies.
