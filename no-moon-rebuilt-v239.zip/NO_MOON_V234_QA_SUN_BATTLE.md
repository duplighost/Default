# No Moon v234 — QA: Sun Battle tap zone (on top of v233)

Adds a "QA" button (44x44, top-left) and noMoonQAToSunBattle() function
that cheats into the sun fight with a maxed-out loadout.

Build tag: qual.qa-sun-battle-tap-zone.2026-05-17.v234
SW cache:  no-moon-qa-sun-battle-tap-zone-v234

What the QA button does:
1. localStorage['noMoon.v39.sunPathClearCount'] = '1'  (open-crater path)
2. Marks save as 2nd-run (wins>=1, defeatedBosses.sun=true)
3. startGame(currentChar)
4. state.v39GoSun()  — teleport to sun throne
5. Maxed loadout:
   REWARDS:  rapid x8, amp x4, marrow x3, frame x2
   ITEMS:    sidecarLances x3, rearArray x2, splitWake x3, phaseDrill x3,
             hunterMycelia x3, staticLink x3, shrapnelChamber x2,
             lunarCaliber x3, echoChamber x2, moonShard x4,
             scavengerDrone x2, orbitalHalo x3,
             aegisLattice x2, hullScripture x3, siphonVane x4,
             sutureEngine x3, bloodTithe x2
6. HP -> maxHp, shield -> shieldMax, 1.6s invuln

Console: noMoonQAToSunBattle()  /  noMoonV234SelfTest()
