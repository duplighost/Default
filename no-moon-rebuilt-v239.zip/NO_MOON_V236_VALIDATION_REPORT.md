# No Moon v236 — Validation Report

Build tag: `qual.obstacle-crumble-sun-hazard-rootfix.2026-05-18.v236`  
Service worker cache: `no-moon-obstacle-crumble-sun-hazard-rootfix-v236`

## Static validation performed

- `node --check no-moon/game_inline.js` — PASS
- Extracted inline script from `no-moon/index.html` and ran `node --check` — PASS
- `node --check no-moon/no-moon-sw.js` — PASS
- `node --check no-moon-sw.js` — PASS
- Verified `no-moon/game_inline.js` and the inline script inside `no-moon/index.html` match exactly — PASS
- Verified v236 root-cause module appears exactly once — PASS
- Verified v236 wraps:
  - `spawnRing`
  - `spawnSpark`
  - `damageObstacle`
  - `addPulseHazard`
  - `updateGame`
- Verified the original root-cause source code remains present and is now intercepted rather than destructively edited:
  - base `damageObstacle()` obstacle death ring/spark burst
  - phase-1 Sun `addPulseHazard(... r: 92, activeR: 92, interval: 999, activeTime: 0.28 ...)`
- Verified v94 Tidefall and v80 Drowned Sun ray sources were inspected and documented, not altered.

## Root-cause findings

### Obstacle circular waves

The big circular wave was not the volatile-chain code after v235. It was the base breakable-obstacle kill FX in `damageObstacle()`. v235 disabled volatile detonation by clearing the obstacle's `volatile` flag before the volatile damage wrapper could fire, but ordinary breakable kills still called `spawnRing()` and `spawnSpark()`.

### First Sun chamber ground hazards

The remaining first-Sun chamber ground hazards were not random room hazards. They came from the Sun boss phase-1 attack in `tickSunBoss39()`. v235 retargeted the pulses away from the seal pads; v236 suppresses the exact phase-1 pulse hazard instead.

### Drowned Sky / Drowned Sun rays

Drowned Sky vertical rays are v94 Tidefall. They damage during the bright phase. Drowned Sun boss sweep rays are enemy bullets flagged as `sunRay` and `majorHazard`; they also damage. v236 leaves them alone by design.

## Limitations

This environment can run static syntax checks and inspect source logic, but it cannot perform a live browser/mobile playtest. The included manual QA checklist should be run on the phone after deploy, especially to confirm the service worker cache turns over and the obstacle wave is gone in the exact room Alex saw.
