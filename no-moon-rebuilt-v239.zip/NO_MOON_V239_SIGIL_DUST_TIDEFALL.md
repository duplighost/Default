# No Moon v239 — Sigil really gone, obstacle dust crumble, Tidefall off

Layered on top of ChatGPT v236 root-cause-surgery.

Build tag: qual.sigil-gone-obstacle-dust-tidefall-off.2026-05-19.v239
SW cache:  no-moon-sigil-gone-obstacle-dust-tidefall-off-v239

## Fixes

1. Return Sigil ("go home" teleporter): the rebuilt build's
   SunRoute.normalize re-activates it on both first-clear and later-clear
   paths. ChatGPT v235 only disables it when priorSunClears === 0, so
   QA-mode runs and any save with a prior clear keep the sigil visible.
   v239 unconditionally hides the sigil every frame in any room that has
   one (active=false, off-screen) and forces _v77SunCrater open+active so
   the Drowned Sky portal is the only way out.

2. Obstacle crumble dust: ChatGPT v236 makes obstacle breaks silent.
   v239 wraps damageObstacle one layer outside their wrap; after an
   obstacle dies it emits 6 small dust sparks (count 2 each, speed 36-64,
   brown palette). ChatGPT's filter suppresses gold rings/sparks
   count>=8 or speed>=85, so our smaller dust slips through.

3. v94 Tidefall vertical beams: ChatGPT v236 explicitly left them
   alone. v239 disables them in non-boss Drowned Sky rooms (clears
   _v94Tidefall.beams, sets profile.beamCount=-1, pushes nextSpawn to
   1e9). Boss arena keeps them.

## Console

  noMoonV239SelfTest()    // ok: true
  noMoonV239Debug()       // stats.sigilsHidden, crumbleDustEmits, tidefall...
  noMoonV236SelfTest()    // ChatGPT v236 wraps still all true
