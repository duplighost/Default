# No Moon v236 — Root-Cause Surgery QA

Build tag: `qual.obstacle-crumble-sun-hazard-rootfix.2026-05-18.v236`  
Service worker cache: `no-moon-obstacle-crumble-sun-hazard-rootfix-v236`

## What this patch changes

### 1. Breakable obstacles no longer emit the baseline death wave

Root cause found: the base engine `damageObstacle()` still spawned a yellow `spawnRing()` plus a high-speed `spawnSpark()` burst whenever any breakable obstacle was destroyed. v235 correctly disabled volatile chain detonation, but the ordinary break FX remained. That is the circular wave/line burst Alex saw after shooting a normal-looking obstacle.

Fix: v236 wraps `damageObstacle()`, `spawnRing()`, and `spawnSpark()` together. When a breakable obstacle is about to die, the wrapper arms a tiny coordinate-local muzzle. Only the gold obstacle-death ring and high-speed death spark burst at that obstacle position are suppressed. Small hit feedback, pickups, enemy death FX, boss FX, and reward collection FX are left alone.

### 2. First Sun boss phase-1 ground hazards are suppressed, not merely retargeted

Root cause found: `tickSunBoss39()` phase 1 creates a damaging pulse hazard using `addPulseHazard(room, tx, ty, { r: 92, activeR: 92, color: '#fff6b8', interval: 999, delay: 0.55, activeTime: 0.28, damage: 1 })`. v235 retargeted that hazard away from required seal pads so it no longer sat on the stand-on objectives, but the hazard still existed elsewhere in the chamber.

Fix: v236 suppresses that exact phase-1 Sun pulse hazard while the Sun boss is in phase 1. It also cleans any matching existing phase-1 pulse hazards in the Sun throne room during update ticks. It does **not** disable ordinary hazard systems globally.

### 3. Drowned Sky / Drowned Sun rays were inspected but not nerfed here

Root cause found: the Drowned Sky biome has v94 `Tidefall` vertical beams. They are intentional environmental hazards and do damage during their bright phase. The Drowned Sun boss also creates `sunRay` enemy bullets in later phases, and those also damage.

No change in v236: this patch intentionally leaves final-floor and Drowned Sun ray balance alone. Alex said the final floor/boss would be figured out later, so v236 only reports the cause through `noMoonV236Debug()` instead of mixing a final-biome redesign into this obstacle/Sun-room surgery.

## Console checks

```js
noMoonV236SelfTest()
noMoonV236Debug()
noMoonCurrentSelfTest()
noMoonCurrentDebug()
```

Expected:

- `noMoonV236SelfTest().ok === true`
- `buildTag === 'qual.obstacle-crumble-sun-hazard-rootfix.2026-05-18.v236'`
- `cacheExpected === 'no-moon-obstacle-crumble-sun-hazard-rootfix-v236'`
- `wraps.spawnRing`, `wraps.spawnSpark`, `wraps.damageObstacle`, `wraps.addPulseHazard`, and `wraps.updateGame` are all `true`

## Manual QA checklist

1. Hard refresh / clear site data on mobile after deploy so the v236 service worker replaces v235.
2. Enter a regular room with breakable obstacles.
   - Shoot a breakable obstacle until it dies.
   - Expected: it disappears / falls apart without the big yellow circular wave or outward line burst.
   - Expected: no volatile chain blast, no room-wide slowdown from obstacle FX.
3. Enter the first Sun boss chamber.
   - During phase 1, stand on the three required seal pads.
   - Expected: pads remain visually distinct objective pads.
   - Expected: no yellow pulse ground hazards appear elsewhere in the phase-1 chamber.
   - Expected: the Sun can still fire rings/bullets; only the phase-1 ground pulse hazard was suppressed.
4. Kill the Sun.
   - Expected: Drowned Sky crater opens on first clear as in v235.
   - Expected: go-home sigil remains disabled.
5. Enter Drowned Sky.
   - Expected: door graph remains unchanged from v235.
   - Expected: Tidefall beams may still appear and can still hurt; this is intentionally not changed in v236.
6. Enter Drowned Sun boss room.
   - Expected: boss-room back door remains locked during/after fight until Cold Lantern win flow, as in v235.
   - Expected: Drowned Sun rays/bullets remain unchanged in v236.

## Scope notes

- No broad hazard removal.
- No Drowned Sky doorway graph rewrite.
- No final-floor balance pass.
- No boss redesign in this patch.
- Service worker cache bumped so phones should not cling to stale v235 assets after deploy/hard refresh.
