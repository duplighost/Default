Qualiacology site — No Moon v308: boss-circle / sun-light / max-HP fixes

Upload the CONTENTS of this folder to your site root (drop-in replacement).
Build tag (verify in the browser console with noMoonCurrentBuild()):
  qual.v308-boss-marker-off-sun-continuous-hp-ease.2026-06-03.v308

v308 changes (stacked on the v307 finished-release build):
  1. Boss "marker-drop" circles removed. Those large rings that appeared on the
     ground during boss fights when you stood back never actually dealt damage
     (a one-shot timing bug) and just piled up - they're gone now. The sun-boss
     phase-1 "seal" circles you stand in to advance the fight are a SEPARATE
     system and are untouched.
  2. Sun light is now continuous instead of pulsing on a day/night cycle. In the
     sunny biome, standing in open sun steadily costs health (about 1 every
     ~2-3 seconds) and shade is the reliable safe spot. The old cycle kept
     switching the light off, so the heat meter almost never filled.
  3. The hidden "pressure" penalty that secretly lowered max integrity was
     reduced: no penalty until floor 8 (was floor 6), then -1 on floors 8-9 and
     -2 on floor 10 (was -1/-2/-3 on floors 6/8/10). A +1 max-HP graft now
     visibly works on the mid floors instead of being silently cancelled.

Not changed yet (still being investigated, need a repro): the map vanishing
after a boss, and the door "coating" that only shows on later runs.

------------------------------------------------------------------------------
(Older note, kept for reference)
Qualiacology site - No Moon v281: bloom skip for mobile + Firefox

Upload contents to site root. This is the v280 bundle (v278b Mission Remnants
+ v279 Archon/Seentists/OG + v280 ambient/social images) plus one small
performance patch: v281 skips the bloom pass on mobile viewports and Firefox.

v281 bloom skip patch:
  Build tag: n/a (does not override the v279 HUD tag — render-only change)
  Install block: installV281SafeBloomSkip (line 69936)

  What it does:
    Wraps drawBloomPass(). Before calling the base function, checks:
      - W < 760 (mobile viewport)
      - navigator.maxTouchPoints > 0 (touch device)
      - /Firefox/i in user agent
    If any is true, returns immediately — skips the canvas copy + blur(11px)
    + screen composite that runs every frame.

  What it does NOT do:
    - Does not touch gameplay, routing, saves, ending, or any state
    - Does not change desktop Chrome rendering (bloom still runs at >= 760px)
    - Does not remove the bloom function — just gates it
    - Does not affect any other patch in the v275-v279 stack

  Why:
    The bloom pass copies the full canvas to a half-res bloom canvas, applies
    ctx.filter = 'blur(11px) saturate(1.16)' and composites back with
    globalCompositeOperation = 'screen'. This is the single most expensive
    per-frame operation. Chrome desktop handles it well. Mobile phones and
    Firefox cannot — Firefox lags from room 1, mobile drops frames during
    particle-heavy moments (breakable explosions, pickup glows).

    v233 "Mobile equals PC" intentionally disabled all earlier mobile FX
    mitigations (ambient skip, spark half, ring limit) because those caused
    visible flickering. The bloom pass was never gated. This patch fills
    that gap.

  Visual difference on mobile/Firefox:
    The game looks slightly crisper/sharper — no soft blur halo around bright
    objects. All gameplay elements (player, enemies, obstacles, pickups, HUD,
    text, glows) render identically. Verified in headless Chromium via
    Playwright at 720x480 viewport.

  Console check:
    The patch is inside the game IIFE. No new window.* helpers are exposed
    (it's too simple to need debug functions). The existing self-tests
    (noMoonCurrentSelfTest, noMoonV279SelfTest, noMoonV278SelfTest) are
    unaffected.

Everything else from v280 is preserved:
  - v278b Mission Remnants (Drowned Sky astronaut enemies, slow rise,
    Drowned Sun room exclusion, room-clear guard, trophy deferral)
  - v279 Archon Field Guide persistence (QA-aware)
  - v279 Seentists visual/copy layer
  - v279/v280 Open Graph metadata + Twitter cards
  - v280 Jelly Strobe ambient audio on / and /book.html
  - Book figures (five-axis-framework.webp + three-levels-understanding.webp)
  - Vibrant visual pass on index.html + book.html
  - Discord URL swap + book section deletions
  - v275 fresh-run-reveal hard-guard
  - v274 re-entry prompt
  - All prior patch stack preserved

QA after upload:
  1. Chrome desktop: game should look identical to v280 (bloom still runs).
  2. Chrome mobile: game should look slightly less glowy but run smoother.
     Test breakable obstacles on floor 1 — the slowdown should be reduced.
  3. Firefox: game should be noticeably less laggy from room 1.
  4. /no-moon/?fresh=1 — confirm no ending zoom on fresh run.
  5. noMoonCurrentSelfTest() — should still return ok: true.
