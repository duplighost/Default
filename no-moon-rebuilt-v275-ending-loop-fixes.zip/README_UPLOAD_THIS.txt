No Moon v275 — ending soft-lock fix + replay popup + label hide + walker cleanup + constellation alignment

Upload the contents of this ZIP to the site root, preserving folders.

Stable checkpoint preserved:
- v269 mobile title / portrait / passenger-scroll fixes intact.
- v270 + v271 First Walker boss trophy / field guide intact.
- v272/v272b title video restore + decoder fix intact.
- v273 title toggle restore + procedural BGM (Suno tracks removed) intact.
- Service worker registration remains disabled.

v275 fixes (all four issues you flagged on the v273 procedural-BGM build):

1. Ending zoom-out infinite loop FIXED.
   The race was: v260's returnToTitleAfterReveal cleared _v251RevealCompleted
   before v261's showPassengerSelectAfterEnding saw it, and the persistent
   boss-defeat flags (_v80DrownedSunDefeated, _v39SunPathCompletedThisWin,
   etc.) survived to re-arm the reveal on the next tick. v275 detects
   post-reveal state, force-clears those persistent flags, and pins the
   state so the v258 replay popup ("New run as <character>") stays
   visible. Clicking the button starts a fresh run with the same passenger
   via the existing v258 hardStartFreshRun258 handler.

2. Field-guide boss-card labels hidden.
   CSS rule kills .v71BossName in the codex's "The Defeated" grid.
   Revealed cards show the boss image and "Defeated" status chip but
   not the boss name. Applies to all card sources (v71, v81 Drowned
   Sun, v271 First Walker).

3. First Walker astronaut decoration removed.
   The random astronaut "blobs" with random arrow-arms are cleared every
   frame from room._v262AstronautRemains. The boss fight progresses
   normally - only the decoration is removed. (We can re-add a coherent
   visual treatment in a later patch if you want.)

4. In-game constellation HUD shape now matches the zoom-out reveal.
   BOSS_SLOTS_260 and BOSS_SLOTS_261 angles updated to match
   BOSS_TYPE_CONSTELLATION (the array the actual reveal animation uses).
   The HUD is still small / top-of-screen, but the angular arrangement
   between bosses now mirrors the shape you'll see in the reveal.

Console checks:
noMoonV275SelfTest()                  // expect ok:true, installed:true, cssInjected:true
noMoonV275Debug()                     // full state + stats
noMoonV275ForceReplayPopup()          // manually trigger the replay popup
noMoonV275HardClearEndingState()      // emergency clear of all end-flags
noMoonV273SelfTest()                  // toggles still visible
noMoonV272SelfTest()                  // title video still ok
noMoonV271SelfTest()                  // First Walker trophy still ok
