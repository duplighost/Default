# No Moon v244 — Room-scar render kill on mobile

Build tag: qual.v244-mobile-scar-kill.2026-05-19.v244
SW cache:  no-moon-v244-mobile-scar-kill-v244

Layered on top of v243 (which is on top of ChatGPT v240 + my v242).

## Root cause for "quiet obstacle break still tanks mobile framerate"

drawRoomScars at game_inline.js:14630 renders a per-frame overlay for
every entry in room.scars. Each scar uses globalCompositeOperation =
'screen', radial gradient glows, and stroke loops. Per scar that's a
small cost, but they accumulate from:

  - obstacle breaks (addRoomScar :14548, :15157)
  - every non-boss enemy death (:15176)
  - captain deaths (:14702)

They render every frame for the rest of the room visit. On mobile with
5-10 kills + obstacle breaks the per-frame cost compounds until the
framerate dies. The user's "no explosion, no hazard, but slowdown
happened" matches exactly: the OBSTACLE break was clean (v243 muzzled
the FX), but the room had been collecting scars from killed enemies +
the obstacle's own scar, and they all keep rendering.

## Fix

On mobile (W < 720):
- addRoomScar no-ops (no new scars accumulate).
- drawRoomScars early-returns (no per-frame render cost).
- Each updateGame tick, room.scars is pruned to length 0 for the
  current room (catches scars added before this layer installed).

On desktop, drawRoomScars unchanged; addRoomScar caps the array to 16
entries FIFO so the same compounding doesn't bite weaker desktops.

## Verification

  noMoonV244SelfTest()    // ok: true
  noMoonV244Debug().stats // scarsBlocked / scarRendersBlocked / scarsTrimmed
  noMoonV243SelfTest()    // still ok
