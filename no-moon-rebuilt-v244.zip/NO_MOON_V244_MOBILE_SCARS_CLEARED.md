# No Moon v244 — Mobile-only: room scars cleared each tick

Build tag: qual.v244-mobile-scars-cleared.2026-05-19.v244
SW cache:  no-moon-v244-mobile-scars-cleared-v244

Layered on top of v243.

## Root cause for "quiet break still tanks mobile"

drawRoomScars at game_inline.js:14630 renders 'screen'-blend gradient
ellipses for every scar in room.scars, EVERY frame. Scars come from:
- obstacle breaks (addRoomScar :14548, :15157)
- non-boss enemy deaths (:15176)
- captain deaths (:14702)

Engine caps at 32 on mobile (:14416) but 32 gradient ellipses per
frame is still mobile-killing.

## Fix

Each updateGame tick on mobile (W < 720), walk current room +
state.level.rooms[].scars and set length = 0. drawRoomScars at :14632
short-circuits on the empty-array guard.

Mobile-only by design — desktop scars unchanged.

## Safety verified

- room.scars is only consumed by drawRoomScars at :14632 (purely
  visual, no gameplay).
- v27's sys.scars at :20388 is a SEPARATE memory-trail damage system
  for the "remembers" contract — untouched.
- The engine cap at :14416-14417 is harmless once arrays stay empty.

## Verification

  noMoonV244SelfTest()    // ok: true
  noMoonV244Debug().stats // scarsCleared (climbs during mobile play)
  noMoonV243SelfTest()    // still ok
