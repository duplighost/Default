# No Moon v244 — Room scars killed universally

Build tag: qual.v244-scars-killed.2026-05-19.v244
SW cache:  no-moon-v244-scars-killed-v244

Layered on top of v243.

## Root cause for "quiet obstacle break still tanks mobile"

drawRoomScars at game_inline.js:14630 renders a per-frame overlay for
each scar in room.scars. Scars accumulate from:
- obstacle breaks (addRoomScar :14548, :15157)
- every non-boss enemy death (:15176)
- captain deaths (:14702)
Each scar uses 'screen' blend mode + radial gradient + stroke loops
per frame, for the rest of the room visit.

The user's "obstacle broke quietly, nothing under it, but slowdown
happened" matches this: by the time they break the obstacle, the room
already has scars from kills, plus a new one from the obstacle. The
break itself was clean (v243's mobile-sterile wrap), but the per-frame
scar render cost is what kills the framerate.

## Fix

addRoomScar and drawRoomScars are closure-scoped inside
installFutureConsequencePass at :14295 so they aren't wrappable from
the outer layer. Instead we clear the data: each updateGame tick walk
state.level.rooms[].scars and pop them empty. drawRoomScars
short-circuits on `if (!room.scars.length) return` at :14632.

Applied universally (mobile + desktop). Scars are minor decorative
residue; no gameplay impact.

## Verification

  noMoonV244SelfTest()    // ok: true
  noMoonV244Debug().stats // scarsCleared (will climb during play)
  noMoonV243SelfTest()    // still ok
