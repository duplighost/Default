No Moon v272 — title video restore (on top of v271)

Upload the contents of this ZIP to the site root, preserving folders.

Stable checkpoint preserved:
- v269 mobile title / portrait / passenger-scroll fixes remain intact.
- v270 + v271 First Walker boss trophy / field guide remain intact.
- Service worker registration remains disabled.
- The bad v265 Passenger List/front-door title branch is absent.

v272 additions:
- Re-enables the v246 title screen video on the splash. v268's lockdown CSS
  had hidden #nmTitleMediaLayer with display:none !important. v272 adds a
  higher-specificity override that re-shows the layer pinned to the overlay
  box (100dvh + --nm-vh fallback), pointer-events:none so the START button
  still gets taps, and prefers-reduced-motion users still see only the
  static webp.
- Static webp background painted by v268/v269 is kept as a fallback for
  cases where the video fails to load or autoplay is denied.
- First-touch unlock listener nudges video playback on the first user gesture
  in case iOS Safari blocks autoplay until interaction.

Suggested test path:
/no-moon/?fresh=1
Title -> video should play behind the START button on splash -> tap START ->
Passenger Select -> Descend -> normal run.

Console checks:
noMoonV272SelfTest()    // expect ok:true with layerPresent and videos array
noMoonV272Debug()       // shows video state, paused/playing, readyState
noMoonV271SelfTest()    // unchanged — should still be ok
noMoonV271ForceWalkerTrophy()
