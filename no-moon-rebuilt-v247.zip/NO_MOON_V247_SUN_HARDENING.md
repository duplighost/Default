# No Moon v247 — Sun exposure hardening (on top of v246/v244)

Build tag: qual.v247-sun-exposure-hardening.2026-05-19.v247
SW cache:  no-moon-v247-sun-exposure-hardening-v247

## What v247 fixes from v246

ChatGPT's v246 review flagged three issues:

1. **Heat ghost across rooms.** v246 just `return`ed when leaving a
   sun room / cleared room / victory state — exposure froze, lingered,
   carried over to the next room. v247 drains exposure at 1.4/sec
   whenever the player is outside a sun-danger room OR the room is
   cleared OR the major boss is defeated. Heat ghost dies.

2. **Sun-room detection too narrow.** v246 only checked
   `_v39MoonPathRoom || _v39SunThrone`. QA / direct-entry rooms can
   have `_v39PathFloor` or `_v77SunCrater` set but not the first two,
   so sun damage silently bypassed. v247 matches ChatGPT v244's
   broader check: `_v39MoonPathRoom || _v39SunThrone ||
   _v39PathFloor != null || _v77SunCrater`.

3. **One-frame meter blink on burn.** v246 set `_v77SunHeat = 0`
   after damage, then mirrored back to 0.38 next tick. Meter
   flickered dark for one frame. v247 sets it directly to 0.38 so
   the visual matches the exposure reset.

## What stays the same

- Engine edit at top of `updateLightBurn39` still uses
  `state.__v246SunBrightnessIgnoring` as the kill switch (stable
  runtime contract, version-independent).
- ChatGPT v244 layer (boss nerf, heartbeat base fix, mobile scar
  render off, damage attribution, near-player heat ring) intact.
- Brightness-ignoring damage rule: 2 s open light = 1 hit; shade
  drains 1.5/sec.

## Verification

```js
noMoonV247SelfTest()           // ok: true
noMoonV247Debug().sun          // exposure, heat, state, burnCd
noMoonV247Debug().room.inSunDanger   // true on any sun-flagged room
noMoonV247Debug().stats.drainTicks   // climbs when outside sun rooms
noMoonV244SelfTest()           // still ok
state.__v246SunBrightnessIgnoring   // true (engine edit still gates on this)
state.__v244SunSingleHeatOwner      // true (SunRoute still muzzled)
state.__v247OwnsSunHeat              // true (v247 is authoritative tracker)
```

Manual:
1. Stand in a sun-danger room in open light. Heat climbs over ~2s.
2. Take the burn. Exposure resets to 0.38; meter visibly bumps to ~38%, no dark blink.
3. Move into a shadow patch. Exposure drains rapidly.
4. **Leave the room** (door / portal / room transition). Watch
   `noMoonV247Debug().sun.exposure` — it should DRAIN now (not freeze).
5. **Clear a sun room.** Exposure drains.
6. **Beat the sun boss / enter victory scene.** Exposure drains.
7. QA-mode direct entry: `noMoonV247Debug().room.inSunDanger`
   should report `true` for any room with `_v39PathFloor` or
   `_v77SunCrater` set.
