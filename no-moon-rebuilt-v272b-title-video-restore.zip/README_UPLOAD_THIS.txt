No Moon v272b — title video restore + mobile decoder fix

Upload the contents of this ZIP to the site root, preserving folders.

Stable checkpoint preserved:
- v269 mobile title / portrait / passenger-scroll fixes remain intact.
- v270 + v271 First Walker boss trophy / field guide remain intact.
- Service worker registration remains disabled.
- The bad v265 Passenger List/front-door title branch is absent.

v272 additions (kept from v272):
- Re-enables the v246 title screen video on the splash. v268's lockdown CSS
  had hidden #nmTitleMediaLayer with display:none !important. v272 adds a
  higher-specificity override that re-shows the layer pinned to the overlay
  box (100dvh + --nm-vh fallback), pointer-events:none so the START button
  still gets taps, and prefers-reduced-motion users still see only the
  static webp.
- Static webp background painted by v268/v269 is kept as a fallback for
  cases where the video fails to load or autoplay is denied.
- First-touch unlock listener nudges video playback on the first user gesture
  in case iOS Safari blocks autoplay until interaction.

v272b fix:
- nudgeV246 previously used v.style.display === 'none' to skip the hidden
  orientation's video. That only reads inline style; v246 hides the unused
  video via class-based CSS, so the check returned false on both elements
  and we played both. On mobile that meant both decoders were running and
  both currentTime counters were advancing in the background.
- Now using getComputedStyle to detect actual visibility, and explicitly
  pausing the hidden orientation's video to release its decoder. Battery /
  memory cost on mobile drops back to one active video at a time.

Suggested test path:
/no-moon/?fresh=1
Title -> video should play behind the START button on splash -> tap START ->
Passenger Select -> Descend -> normal run.

Console checks:
noMoonV272SelfTest()    // expect ok:true with layerPresent and videos array
noMoonV272Debug()       // shows video state, paused/playing, readyState
noMoonV271SelfTest()    // unchanged — should still be ok
noMoonV271ForceWalkerTrophy()
