# No Moon v241 — Per-species obstacle hazard drops killed

Layer on top of ChatGPT v239 (sun-route-crumble-marker-cleanup).

Build tag: qual.obstacle-hazard-drops-killed.2026-05-19.v241
SW cache:  no-moon-obstacle-hazard-drops-killed-v241

## Root cause of remaining slowdown

User reported some obstacles still cause unplayable mobile slowdown,
and "an obstacle with the ground thing that harms you underneath, even
when it didn't explode visibly." The cause is the engine's per-species
obstacle break (game_inline.js:14543-14580, called from the futureDamageObstacle
wrapper at :15151) which spawns animated GROUND HAZARDS at the obstacle
position:

  bellHusk       55% addPulseHazard   damage:1, r:58→70, interval:3.1
  rootCyst       55% addFogHazard     snare, r:82-122, slow:0.55
  falseIdol      55% addPulseHazard   damage:1, r:76→92, interval:2.7
  archiveLockbox 30% addLaneHazard    v/h beam, w:32, activeTime:0.42
  blackGlass        createBullet x7   enemy bullets ring (shrapnel)

Each hazard renders every frame via radial gradients/arcs and persists
for seconds. Multiple stacked = phone slowdown. The pulse hazards have
a 0.42s delay before visibly activating, which is why some appeared
to do damage "without an explosion."

## Fix

v241 wraps damageObstacle outside ChatGPT v236. During the call:

- addPulseHazard, addFogHazard, addLaneHazard temporarily no-op.
- createBullet temporarily filters out (owner==='enemy' && source==='blackGlass').
- Originals restored in finally{} so nothing else is affected.

After the call returns, also emits 6 small brown dust sparks (count 2,
speed 36-64) for the crumble visual.

Carries forward v240's sigil removal and v238's Tidefall-off-in-non-boss.

## Console

  noMoonV241SelfTest()    // ok: true
  noMoonV241Debug()       // stats.pulsesSuppressed / fogsSuppressed / lanesSuppressed / blackGlassBulletsSuppressed
