# No Moon v237 — Sun chamber no-deny + Tidefall biome off

Layer on top of v236 / v235 / rebuilt.

Build tag: qual.no-sun-deny-no-biome-beams.2026-05-18.v237
SW cache:  no-moon-no-sun-deny-no-biome-beams-v237

## What changes

1. Sun throne room: each frame, removes ANY pulse/ritual hazard. The
   sun boss can still ring-fire and quote-strike, but it can no longer
   deny floor space with damaging hazards.

2. The "sun rays in the last biome" are v94 Tidefall beams — vertical
   falling beams that v94 spawns in EVERY Drowned Sky room. They DO
   damage during their bright phase. v237 clears active beams and
   disables new spawns in NON-boss Drowned Sky rooms. The boss arena
   keeps them (challenge stays intact).

Implementation: one updateGame wrapper that, pre and post base call,
inspects the current room and (a) cleans pulse/ritual hazards out of
the sun throne; (b) zeroes _v94Tidefall.beams + sets beamCount=-1 in
non-boss Drowned Sky rooms.

Console:
  noMoonV237SelfTest()  // ok: true
  noMoonV237Debug()     // shows throneHazardsCleared, tidefallBeamsCleared
