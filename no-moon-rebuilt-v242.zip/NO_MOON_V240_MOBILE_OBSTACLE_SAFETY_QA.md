# No Moon v240 — Mobile Obstacle Safety + Drowned Sun Pass QA

Build tag: `qual.mobile-obstacle-safety-drowned-sun-pass.2026-05-19.v240`  
Cache: `no-moon-mobile-obstacle-safety-drowned-sun-pass-v240`

## Source baseline

Built from Alex's v239 baseline, not Claude's v238 Tidefall-off branch.

## Root causes addressed

### 1. Obstacle explosions still happening on mobile

v236/v239 removed the known gold death wave from `damageObstacle()`, but that was not the only obstacle-break FX path. Other obstacle break paths could still produce heavy rings, streaks, glow particles, bullets, or enemies:

- hidden wall/cache ambushes used non-gold `spawnRing()` / `spawnSpark()` paths;
- object-species breaks could spawn pulse/fog/lane hazards;
- black-glass objects could fire enemy bullets outward;
- false-idol style objects could spawn ambush enemies.

v240 adds a broader but scoped obstacle-break context. While a breakable obstacle is actually being destroyed, it suppresses rings, streak bursts, glow bursts, break-triggered floor hazards, break-triggered enemy bullets, and break-triggered ambush enemies near that obstacle. It leaves the small v239 dot-only crumble.

### 2. Hurt-floor circles under obstacles

The long-floor hazard pass avoided doors and secrets but did not sufficiently avoid breakable obstacle footprints. This could put a damaging/slowing floor hazard directly under an obstacle.

v240 removes only damaging floor hazards whose center overlaps a breakable obstacle footprint. It does not globally delete room hazards.

### 3. clear.html did not run

The packaged `clear.html` script had a broken JavaScript string caused by a literal newline inside the log append expression. The page rendered, but the button handler could fail to install. v240 rewrites the page with a robust button handler, visible logging, disabled-state behavior during cleanup, and a fallback No Moon link.

### 4. Drowned Sun still felt lame

v240 adds a first creative pass to the Drowned Sun without adding more floor damage:

- orbiting eclipse-lens visuals around the boss;
- capped lens bullet bursts fired from satellite positions, not just the boss body;
- arena-edge gate volleys so the fight uses the room instead of only a wall-hugging blob;
- extra wall nudging to keep the boss away from arena edges;
- a short death-collapse visual before the Cold Lantern/victory flow continues.

## Test checklist

1. Fresh mobile run from floor 1.
2. Break ordinary obstacles.
   - Expected: small crumble only.
   - No large outward circular wave.
   - No long streak-burst lines.
3. Break unusual/object-marked obstacles.
   - Expected: no instant floor hazard appears under/around the destroyed object.
   - No black-glass projectile explosion.
   - No surprise ambush from the object break.
4. Enter a room with floor hazards and obstacles.
   - Expected: hazards should not sit directly underneath breakable obstacles.
5. Open `/clear.html`.
   - Expected: button is tappable, log changes from Ready to Starting, service workers/caches are listed, then the page redirects to `/no-moon/?cache-cleared=...`.
6. Reach Drowned Sun.
   - Expected: boss has orbiting lens visuals and fires from lens/gate positions.
   - Boss should stay more central and less glued to walls.
   - No new floor hazards were added to the boss fight by v240.

## Debug hooks

In console:

```js
noMoonV240SelfTest()
noMoonV240Debug()
```

`noMoonV240Debug().stats` includes counts for suppressed obstacle rings/sparks, removed overlap hazards, suppressed break hazards/bullets/enemies, and Drowned Sun burst counts.
