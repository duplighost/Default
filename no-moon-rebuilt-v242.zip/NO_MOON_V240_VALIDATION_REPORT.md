# No Moon v240 — Validation Report

Build tag: `qual.mobile-obstacle-safety-drowned-sun-pass.2026-05-19.v240`  
Cache: `no-moon-mobile-obstacle-safety-drowned-sun-pass-v240`

## Validation performed

Static checks completed after patching and after embedding the inline script:

- `node --check no-moon/game_inline.js`
- extracted inline script from `no-moon/index.html`
- `node --check` on extracted inline script
- exact byte comparison: `no-moon/game_inline.js` matches the embedded inline script
- `node --check no-moon/no-moon-sw.js`
- `node --check no-moon-sw.js`
- extracted `clear.html` script
- `node --check` on extracted `clear.html` script

## Scope control

v240 does **not** rewrite the Drowned Sky doorway network. It keeps v239's Sun route behavior and only adds:

- broader obstacle-break FX/side-effect suppression;
- active-room hazard/obstacle overlap cleanup;
- clear-page repair;
- a first Drowned Sun creative attack/visual pass.

## Notes for live testing

This environment cannot run a live mobile browser playtest. Mobile performance still needs direct phone testing, especially because the original report was Android/mobile-specific and may interact with browser/device GPU behavior.

If an obstacle still appears to explode after v240, use `noMoonV240Debug().stats` immediately afterward. The important counters are:

- `obstacleRingsSuppressed`
- `obstacleSparksSuppressed`
- `obstacleBreakParticlesPruned`
- `breakHazardsSuppressed`
- `breakBulletsSuppressed`
- `breakBulletsPruned`
- `hiddenAmbushesSuppressed`
- `breakEnemiesPruned`
- `hazardsUnderObstaclesRemoved`

Those will tell us whether v240 caught the path or whether there is a remaining independent animation source.
