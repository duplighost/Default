# No Moon v239 — Sun Route / Crumble / Marker Cleanup QA

Base: `nomoonrebuiltv236_root_cause_surgery.zip`.

Build tag: `qual.sun-route-crumble-marker-cleanup.2026-05-19.v239`  
Cache: `no-moon-sun-route-crumble-marker-cleanup-v239`

## What changed

### 1. Sun boss clear has one route now
The old lower Return Sigil / “go home” object is neutralized whenever Sun victory objects exist.

The middle crater is forced open and active after the Sun dies, including first clear and QA-skip clears. The crater is now the only intended post-Sun route object.

Root cause: v234 QA mode deliberately forced `noMoon.v39.sunPathClearCount = 1`. v235 only removed the go-home sigil on the first-clear branch, so QA mode exercised the later-clear branch where older route code still kept the sigil alive.

### 2. Remaining Sun-room floor circles are suppressed by cause
The remaining damaging ground circles in the moving Sun phases match the older global boss marker-drop rhythm:

- boss enemies periodically call `addPulseHazard()` near the player
- shape: pulse/ritual hazard
- radius about 92
- `interval: 999`
- `activeTime` about 0.32
- Sun-colored
- `damage: 1`

v236 suppressed the phase-1 Sun boss’s own pulse hazard. v239 also suppresses this older generic boss-marker pulse when the current room is the Sun throne and the live boss is `sunCore`.

This does not touch bullets, rings, seal pads, Drowned Sky rooms, or non-Sun boss rooms.

### 3. Obstacle death gets a small crumble instead of a blast
v236 already muzzled the circular obstacle-death wave and streak burst. v239 adds a tiny dot-only crumble after a breakable obstacle is destroyed.

The crumble uses simple `dot` particles only:

- no `ring`
- no `streak`
- no glow bloom
- low particle count
- low speed

### 4. Drowned Sky door behavior confirmed
The Drowned Sky doors are intentional fight-to-open gates. Forward and fork doors use `needsCleared: true`, so they only read as usable once the current room is cleared. Back doors stay available unless the Drowned Sun boss-room lock disables them.

v239 does not redesign the Drowned Sky floor or Drowned Sun boss. It only records this finding in debug output.

## Phone test checklist

1. Upload the full zip contents to the site root.
2. Open with a cache-buster, e.g. `...?v=239-sun-route-test`.
3. Tap QA / use `noMoonQAToSunBattle()` to jump to the Sun fight.
4. Kill the first Sun boss.
   - Expected: the lower go-home sigil does not appear or does nothing if an old visual flashes for one frame.
   - Expected: the middle crater is open and takes you to Drowned Sky.
5. During the moving Sun phases:
   - Expected: no generic damaging ground marker circles are dropped under/near the player.
   - Expected: normal Sun bullets/rings/contact/light pressure can still hurt.
6. Break ordinary obstacles.
   - Expected: no circular outward blast wave.
   - Expected: a small debris crumble appears as dots.
7. Drowned Sky rooms:
   - Expected: forward/fork doors are dim until the room is cleared, then usable.
   - Expected: boss-room back door remains locked while the Drowned Sun / Cold Lantern state is active.

## Debug helpers

In console:

```js
noMoonCurrentDebug()
noMoonCurrentSelfTest()
noMoonV239Debug()
noMoonV239SelfTest()
```

Useful fields:

- `room.sunCrater`: should show `open: true`, `active: true`, `sealed: false`, `onlyExit: true` after Sun death before entering Drowned Sky.
- `room.sunReturnSigil`: should show `active: false`, `touched: true`, `removed: true`.
- `stats.sunMarkerPulsesSuppressed`: increments when the global Sun boss marker pulse tries to spawn.
- `stats.obstacleCrumbles`: increments when a breakable obstacle is destroyed.
- `room.drownedDoors`: shows each Drowned Sky door and whether it is currently readable/usable.
