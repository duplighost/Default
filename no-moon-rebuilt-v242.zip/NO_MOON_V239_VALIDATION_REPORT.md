# No Moon v239 — Validation Report

Build tag: `qual.sun-route-crumble-marker-cleanup.2026-05-19.v239`  
Cache: `no-moon-sun-route-crumble-marker-cleanup-v239`

## Scope

This build is based on v236, not Claude’s v238. It intentionally avoids the v238 Tidefall/ray change so the test branch stays clean.

Changed files:

- `no-moon/game_inline.js`
- `no-moon/index.html`
- `no-moon/no-moon-sw.js`
- `no-moon-sw.js`
- v239 docs/manifests

## Root-cause checks

### Go-home sigil after Sun death
Confirmed source: older Sun route code intentionally kept the Return Sigil for later clears. v234 QA mode forces second-run state, so v235’s first-clear-only removal did not apply. v239 now removes the sigil on all Sun-victory branches and keeps the crater as the only route object.

### Sun moving-phase floor circles
Confirmed likely source: older global boss marker-drop rhythm, not the Sun seal pads and not QA loadout. It calls `addPulseHazard()` for generic bosses. v239 suppresses only the Sun-throne / `sunCore` marker pulse shape.

### Obstacle circular wave
Already root-caused in v236: base `damageObstacle()` spawned a ring and a 16-spark burst on every breakable obstacle death. v239 leaves the v236 muzzle in place and adds a dot-only crumble after the obstacle breaks.

### Drowned Sky doors
Confirmed behavior: v80 Drowned Sky forward/fork doors use `needsCleared: true`. They are intended fight-to-open doors. v239 does not change this network.

## Static validation

Passed:

```bash
node --check no-moon/game_inline.js
node --check extracted_inline.js
node --check no-moon/no-moon-sw.js
node --check no-moon-sw.js
```

Also verified:

- extracted inline script from `no-moon/index.html` matches `no-moon/game_inline.js` exactly
- service worker cache name updated to `no-moon-sun-route-crumble-marker-cleanup-v239`
- only expected source files differ from v236 before docs/manifest additions

## Live playtest status

No live browser/mobile playtest was possible in this environment. The patch is intentionally layered and narrow, with console self-tests exposed through `noMoonV239SelfTest()`.
