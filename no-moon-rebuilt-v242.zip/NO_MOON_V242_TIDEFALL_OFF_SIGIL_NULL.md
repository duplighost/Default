# No Moon v242 — Tidefall off + sigil null, on top of ChatGPT v240

Build tag: qual.tidefall-off-sigil-null-on-v240.2026-05-19.v242
SW cache:  no-moon-tidefall-off-sigil-null-on-v240-v242

ChatGPT's v240 (mobile-obstacle-safety-drowned-sun-pass) already handles:
- Broader obstacle-break safety (gold + non-gold paths, hidden ambushes,
  black-glass shrapnel, per-species hazards, ambush enemies all suppressed)
- Hazard overlap cleanup (removes existing damaging hazards under obstacle
  footprints)
- clear.html fix
- Drowned Sun creative pass (orbiting lens visuals, gate volleys,
  wall nudging, death-collapse before victory)

v242 layers two small fixes that ChatGPT didn't include:

1. Sigil REMOVED (null), not just neutralized. The crater is the
   teleporter to Drowned Sky; no reason to keep the sigil object alive.
   Each frame: room._v77SunReturnSigil = null in any room that has one,
   plus force the crater open+active.

2. v94 Tidefall beams off in non-boss Drowned Sky rooms. Tidefall
   spawns vertical falling beams in every Drowned Sky room (the
   "sun rays" the user saw in the biome) and they damage during the
   bright phase. Boss arena keeps Tidefall.

## Console

  noMoonV242SelfTest()    // ok: true
  noMoonV242Debug()       // stats.sigilsRemoved, tidefallBeamsCleared
  noMoonV240SelfTest()    // ChatGPT v240 still installed
