# No Moon v236 — Quiet obstacle break (layered on top of ChatGPT's v235)

Build tag: qual.quiet-obstacle-break.2026-05-18.v236
SW cache:  no-moon-quiet-obstacle-break-v236

v235 disabled the VOLATILE chain by clearing obstacle.volatile.
But the BASE engine damageObstacle at game_inline.js:4460 ALWAYS spawns a
yellow ring (radius ~ obstacle.r * 1.4) and 16 sparks on every breakable
obstacle that dies. That ring is the "circular wave" still seen on
regular shoot-apart obstacles.

v236 wraps damageObstacle one layer deeper and muzzles spawnRing,
spawnSpark, shake, addRoomHazard/addPulseHazard/addLaneHazard/addFogHazard,
and chainDamageEnemy for the duration of the call. v235's logic still
runs (we call its wrapper as our base). Net: obstacles just fall apart.

Console:
  noMoonV236SelfTest()   // ok: true
