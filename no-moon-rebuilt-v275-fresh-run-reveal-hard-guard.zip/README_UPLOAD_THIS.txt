NO MOON — v275 fresh-run reveal hard guard

Upload the contents of this ZIP to the site root, preserving folder structure.

Build tag:
qual.v275-fresh-run-reveal-hard-guard.2026-05-24.v275

Cache token:
no-moon-v275-fresh-run-reveal-hard-guard-v275

Fixes over v274:
- Fixes the fresh-start regression where selecting a Passenger and pressing Descend could immediately start the Moon zoom-out.
- Root cause: v274's ending cleanup set shrine.stage = 'done'; older safety-net code treats an inactive done shrine as final-win evidence.
- v275 changes shrine cleanup to neutral 'fight' instead of terminal 'done'.
- Adds a document-level capture guard that clears stale ending/reveal flags before the old v251 start-button reveal listener can hijack a normal Descend click.
- Adds a short fresh-run reveal block around startGame so any immediate stale reveal/prompt is scrubbed back to live gameplay.
- Keeps v274's post-ending re-entry prompt, unlabeled moon pattern, unified constellation screen-space map, and First Walker/astronaut visual cleanup.

Console checks after upload:
- noMoonCurrentSelfTest()
- noMoonV275Debug()

Expected quick QA:
1. Open in incognito or clear site data.
2. Click START, select a Passenger, click Descend.
3. The game should enter Floor 1 gameplay, not the Moon zoom-out.
4. Beat/QA-trigger the final ending: the Moon zoom-out should play once.
5. After the blink, the NO MOON re-entry prompt should appear once.
6. Clicking Re-enter at Floor 1 should start gameplay, not replay the ending.
