# No Moon v238 — Tidefall beams off in non-boss Drowned Sky rooms

Layer on top of ChatGPT's v236 root-cause-surgery.

Build tag: qual.tidefall-biome-off.2026-05-18.v238
SW cache:  no-moon-tidefall-biome-off-v238

## What this fixes

ChatGPT's v236 explicitly left Tidefall alone ("may still appear and
can still hurt; intentionally not changed"). v94 Tidefall fires
vertical beams in EVERY Drowned Sky room — boss and non-boss alike.
Those vertical beams are what the user called "sun rays in the last
biome." They DO damage during the bright phase.

v238 wraps updateGame and each frame, in any non-boss Drowned Sky
room, clears _v94Tidefall.beams, sets tf.profile.beamCount = -1 so
the spawn gate is always closed, and pushes nextSpawn out to 1e9.
The boss arena keeps Tidefall (intended challenge).

## Console

  noMoonV238SelfTest()   // ok: true
  noMoonV238Debug()      // stats.tidefallBeamsCleared / tidefallRoomsMuted
  noMoonV236SelfTest()   // ChatGPT v236 wraps still all true
