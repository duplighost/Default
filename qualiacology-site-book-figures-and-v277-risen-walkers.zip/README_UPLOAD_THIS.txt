Qualiacology site — book figures dropped in + No Moon v277 risen walkers

Upload contents to site root. Layered on top of the prior vibrant-pass +
figure-scaffolding bundle. Adds the actual book figures and a new No Moon
gameplay layer (v277) where the dead astronauts wake up to fight.

What changed this bundle:

1. Book figures: actual WebP files dropped into assets/book/.
   - assets/book/five-axis-framework.webp       — Five Sources of Evidence
   - assets/book/three-levels-understanding.webp — Three Levels of Understanding
   The vibrant-pass <figure> markup in book.html (Multi-Axial Framework
   section and Levels of Understanding section) now resolves to these files
   instead of silently hiding via onerror. No book.html changes were needed
   — the picture/source/img scaffolding already pointed at these names.

2. No Moon — v277 risen walkers (layered on top of v275 hard-guard).
   Build tag:  qual.v277-risen-walkers.2026-05-24.v277
   Cache key:  no-moon-v277-risen-walkers-v277

   What it does:
   - The dead astronaut bodies that v262 places around the Drowned Sky
     biome (entry, shipyard, maw rooms, the Buried Habitat boss arena,
     and 12% of other Drowned Sky rooms) now wake up when the player
     walks into the room with them.
   - Wake sequence per room:
       * Player enters. Brief held breath (~0.95s, 1.45s in the boss arena).
       * Each body shimmers and gets a faint rising silhouette over ~1.15s.
         Staggered randomly across bodies for an unsettling cascade.
       * When the rise finishes, the prone body is hidden and a real
         "Risen Walker" enemy stands at that spot.
   - Risen Walker behavior:
       * Slow, heavy lurch toward the player (effective ~40 px/s).
       * Single ranged shot (#bde7ff bullet) every 1.7–2.7s at mid range
         (120–540 px). Visor pulses cyan; suit faintly sways.
       * 6.8 HP at base, scaled by floor like other enemies. Contact damage
         from the standard enemy contact path.
       * On death: cyan-dust burst + ring + counter. The standard kill
         loot pipeline still runs.
   - First Walker boss arena gets the heaviest cluster (6–8 bodies all
     rising at staggered times) and a one-shot "The bodies stir." message.
   - The astronaut visuals (drawAstronautRemain) for not-yet-risen bodies
     are unchanged — only fully-risen ones are filtered out of the v262
     prone-render pass.
   - Resets cleanly on every fresh Descend (per-room flags wiped in the
     startGame wrap, on top of v275's hard-guard).

   Where to feel it: take the Drowned Sky route after the Warden, push
   into any room with astronaut wreckage. The path to the First Walker
   (preboss -> shipyard -> maw -> walker) now has live enemies in the
   atmospheric rooms instead of purely decorative bodies.

   Console checks after upload:
       noMoonCurrentSelfTest()   -> ok:true (now points at v277)
       noMoonV277SelfTest()      -> ok:true, wraps:{...all true}
       noMoonV277Debug()         -> per-room status (armed, rising, risen)
       noMoonV275SelfTest()      -> still ok:true (hard-guard preserved)

3. Prior bundle preserved.
   - Discord URL swap (discord.gg/NwvxKxUJpC) preserved everywhere.
   - Book section deletions ("Some Medications I Think Actually Work",
     "Some Treatments You Probably Shouldn't Bother With") preserved.
   - Vibrant visual pass (aurora, rainbow titles, breathing glows, card
     halos, gradient blockquote edges) preserved.

Quick QA after upload:
   - Open book.html, scroll into "The Multi-Axial Framework: A Visual
     Guide to Sources of Truth": the 5-axis radial diagram should appear
     under the heading with caption "Figure 1 — Five Sources of Evidence".
   - Continue to "Levels of Understanding: Three Ways to View Medication
     Effects": the stacked 3-panel diagram should appear with caption
     "Figure 2 — Three Levels of Understanding".
   - Open No Moon in incognito or via /clear.html for a fresh save.
     START -> Passenger -> Descend should still land on Floor 1 gameplay
     (v275 hard-guard intact). The Moon zoomout must NOT fire on a fresh
     run.
   - Take the Drowned Sky route. In any room with astronaut wreckage on
     the floor or hanging from the ceiling, wait ~1 second after entering.
     The bodies should shimmer and rise into walking enemies that lurch
     toward you and fire single-shot bullets.
   - Buried Habitat (First Walker boss arena): on entry, after ~1.45s
     the ring of bodies around the shrine should rise in a staggered
     cascade. "The bodies stir." appears once.
   - Defeat the First Walker after dispatching the walkers. Boss-trophy
     draft (v270) and Field Guide card (v271) should still work.
   - End the route normally. After the Moon reveal + blink, the "Re-enter
     at Floor 1" prompt should still appear (v274), and clicking it must
     start Floor 1 fresh, not replay the ending (v275 guard intact).
