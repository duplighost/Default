# No Moon v246 — Brightness-ignoring sunlight (on top of ChatGPT v244)

Build tag: qual.v246-brightness-ignoring-sun.2026-05-19.v246
SW cache:  no-moon-v246-brightness-ignoring-sun-v246

## What v246 adds to ChatGPT v244

ChatGPT v244 picked v39 (brightness-gated, only burns >=0.55 bright)
as the sun-heat owner. User chose brightness-ignoring instead — "burn
whenever not in shade."

v246:
- Engine edit at top of updateLightBurn39 — early-returns when
  state.__v246SunBrightnessIgnoring is true, neutralizing v39.
- ChatGPT's state.__v244SunSingleHeatOwner stays true so
  SunRoute.tickHeat is still muzzled.
- Appended IIFE installs a parallel exposure tracker that drives
  state._v77SunHeat directly. In any v39 moon-path room:
    shaded   → exposure drains 1.5/sec
    not shaded → exposure rises 0.5/sec (any brightness)
    >= 1     → damagePlayer(1,'sunlight'); reset to 0.38; lockout 1.5s
- ChatGPT's near-player ring at v77DrawSunHeatMeter (:43588) reads our
  value automatically. No extra meter wrap needed.
- Hardened shadow check from v245 carried over (skips patches with
  bad rx/ry).

## What stays from ChatGPT v244

- Boss phase 2/3 nerf (:27185-27200)
- Heartbeat at base hp<=1 (:1923)
- BGM low-HP stress at hp<=1
- Mobile scar render off (drawRoomScars at :14632 early-returns)
- Damage attribution via damagePlayer wrap (:57675)
- Near-player heat ring (:43588)

## Verification

  noMoonV246SelfTest()        // ok: true
  noMoonV246Debug().sun       // exposure, heat, state, burnCd
  noMoonV244SelfTest()        // still ok (ChatGPT layer intact)
  state.__v246SunBrightnessIgnoring  // true
  state.__v244SunSingleHeatOwner     // true
