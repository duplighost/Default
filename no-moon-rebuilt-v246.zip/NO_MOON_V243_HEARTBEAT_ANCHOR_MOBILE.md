# No Moon v243 — Heartbeat HP=1, mobile-sterile obstacles, Black Anchor durable credit

Build tag: qual.v243-mobile-sterile-anchor-heartbeat.2026-05-19.v243
SW cache:  no-moon-v243-mobile-sterile-anchor-heartbeat-v243

Layered on top of v242 (ChatGPT v240 + my Tidefall-off + sigil-null).

## Five fixes

(B) **Heartbeat audio at HP === 1 only.** updateCriticalLowHpAudio at
    game_inline.js:1923 uses `hp <= ceil(maxHp * 0.28)` → at maxHp 6 it
    triggers at hp <= 2. Wrap global playToneBurst/playNoiseBurst; when
    the call matches heartbeat signature (startFreq 68/84, duration
    0.06-0.16 OR filterFreq 160 duration 0.08-0.13) AND player hp > 1,
    drop it. BGM stress at :1563 uses the same 28% but is a separate
    system; not touched.

(C) **Ambush enemy quiet death.** rootCyst/falseIdol breaks call
    spawnDebtAmbush at :14523 which tags each spawned enemy
    `futureDebtBorn=true` at :14533. Those enemies' deaths trigger
    killEnemy's 5-spark+ring+shake at :4815-4823. Cascade kills
    mobile framerate. Wrap killEnemy: for futureDebtBorn non-boss
    enemies, muzzle spark/ring/shake during the call. Gameplay
    (kill credit, drops) preserved.

(D) **Mobile-sterile obstacle death.** ChatGPT v240 predicts breakage
    from incoming damage but inner damage multipliers (e.g. Rook's v56
    obstacle boost) can change damage AFTER v240's prediction so v240
    fails to arm. On mobile (W < 720), v243 unconditionally muzzles
    spawnSpark/spawnRing/shake/addRoomScar/addPulseHazard/addFogHazard/
    addLaneHazard and enemy-owned createBullet for the entire
    damageObstacle call. Every break is sterile on mobile. Desktop
    keeps existing crumble visuals.

(A) **Black Anchor durable credit.** The "blank anchor" is the v82
    Black Anchor slot (drawBlackAnchorSlot82 at :47623). It reuses v56
    active slot layout when available (:47628-31) — that's why it
    moves between low and high based on which v56 candidate is open
    on mobile. Its mobile fallback is `y: Math.max(104, H - 174)` at
    :47634.
    
    More critically, chargeAnchor82 at :47333 is gated through a
    setRoomCleared wrap at :47765-47776 that checks `hadFoes` BEFORE
    the base clear runs. Later layers (captain-hold, spawn-safety,
    custom-room repair, boss-safe) clear rooms outside that contract,
    so the credit never fires.
    
    v99 fixed exactly this for Boon Moots (line :52886). v243 ports
    the same pattern to Black Anchor: each tick, mark hostile rooms
    with `_v243NadirHadHostiles`, then credit chargeAnchor82 once when
    the room becomes cleared via any path. Only runs when Nadir is
    selected.

(E) **Stale equipped-active cleanup.** If sys.active.equippedId
    doesn't resolve to a valid ACTIVE_DEFS entry, null it. Defensive.

(F) **Volatile flag belt-and-braces.** Each tick, set
    obstacle.volatile=false on all room obstacles.

## Verification

```js
noMoonV243SelfTest()       // ok: true
noMoonV243Debug()          // stats.heartbeatsBlocked / ambushDeathsQuieted /
                           //   mobileBreakFxMuzzled / anchorCreditsFired
noMoonV242SelfTest()       // still ok (Tidefall + sigil-null)
noMoonV240SelfTest()       // ChatGPT v240 still installed
```

Manual:
- Take damage to 2 HP → no heartbeat. Take to 1 HP → heartbeat plays.
- Mobile run on Rosewire Atrium → break rootCysts. Watch ambush
  enemies appear; kill them. No particle cascade.
- Play as Nadir on mobile → Black Anchor slot should recharge after
  every cleared hostile room, regardless of how the room was cleared.
