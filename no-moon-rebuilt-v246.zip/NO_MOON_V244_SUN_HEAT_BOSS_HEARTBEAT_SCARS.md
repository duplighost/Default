# No Moon v244 — Sun heat / first Sun / heartbeat / mobile scars

Build tag: `qual.v244-sun-heat-boss-heartbeat-scars.2026-05-19.v244`  
SW cache: `no-moon-v244-sun-heat-boss-heartbeat-scars-v244`

## What changed

1. **Sun heat now has one owner.**
   - The older v39 Sun-light hazard is now the authoritative heat/damage path.
   - Rebuilt/SunRoute `tickHeat()` is muzzled when `state.__v244SunSingleHeatOwner` is true, so it cannot double-fill `_v77SunHeat` after v39 has already updated it.
   - Sun-light update can run from room flags too, not only `_v39MoonPathActive`, so QA/direct-entry Sun rooms still update.

2. **Heat meter is visible and tied to the actual heat state.**
   - The meter draws from `_v77SunHeat` near/around the player rather than only as a tiny top-center arc.
   - Overlay drawing is no longer gated only by `_v39MoonPathActive && room._v39MoonPathRoom`.

3. **First Sun boss is softened.**
   - Phase 2 and 3 bullet counts, speeds, and cooldowns were reduced.
   - Boss-room sunlight heat gain is damped so sunlight still matters but no longer stacks like a second boss on top of bullets.

4. **Heartbeat is direct HP=1 now.**
   - Base heartbeat threshold changed from `ceil(maxHp * 0.28)` to `hp <= 1`.
   - BGM low-health stress also uses `hp <= 1` so full-health/max-health cases should not sound heartbeat-adjacent from that path.

5. **Mobile room scars are render-muted.**
   - Persistent `drawRoomScars()` glow/stroke loops are skipped on mobile unless `state.__v244AllowMobileScars = true`.
   - Existing scars may still exist in room data, but mobile no longer pays the per-frame draw cost.

6. **Damage attribution helpers added.**
   - Enemy bullet collision now passes source labels such as `enemy:sunCore`.
   - Sunlight, sun-ray, and sun-contact damage pass explicit source labels.
   - `noMoonV244Debug()` reports recent damage source counts.

## Quick QA

- On a Sun floor: stand in open light and confirm the player heat ring/bar fills; step into shadow and confirm it drains.
- Confirm no double-fast sunlight damage: heat should not jump like two systems are adding to it at once.
- First Sun boss: phase 2/3 should still be dangerous but should not delete HP instantly from sunlight + bullet stacking.
- Raise max HP above 8 and keep full health: no low-HP heartbeat.
- Drop to 1 HP: heartbeat plays.
- On mobile, clear/break objects in Rosewire/Rosewater-style rooms and confirm scar glow residue no longer tanks the frame rate.
- In console: `noMoonV244SelfTest()` should return `ok: true`.
