# No Moon v231 — Mobile/Firefox Hazard Overlay + Ambient Flicker Fix

Base: v230 (Claude Firefox Obstacle Ring Stabilizer) on top of no-moon-rebuilt.

Build tag: `qual.mobile-hazard-overlay-flicker-fix.2026-05-16.v231`
Service worker cache: `no-moon-mobile-hazard-overlay-flicker-fix-v231`

## What this patch does

Two specific mobile/Firefox flicker sources, both confirmed in the source:

1. **Yellow-orange "oval with dots" flashing on spore/snare/lotus hazards**
   - Source: the v67 hazard-language overlay (`drawHazards` at line 40366)
     draws an extra dashed ring + soft glow + 9 rotating ticks + a 5-dot
     ripple sparkle on top of every spore/snare/lotus hazard. The animations
     are time-modulated and the screen-blend compositing layered on the
     engine's base hazard render looks like flicker on low-FX clients.
   - Fix: on low-FX, set `state.v67HazardUiEndingClarity.config.hazardLanguage = false`.
     The engine's own hazard render at line 11841 still draws the hazard
     (glow + ellipse + glyph + 10 orbital dots), so gameplay info stays.

2. **Background decorations flashing**
   - Source: the v82 mobile optimization (`MOBILE_AMBIENT_SKIP: true`, line 47282)
     skips the ambient render every OTHER frame on mobile. On a 30 fps device
     that turns into a 15 Hz wink of the whole ambient layer.
   - Fix: on low-FX, set `state.v82BlackAnchor.config.MOBILE_AMBIENT_SKIP = false`.
     Ambient now renders every frame; per-element animations advance smoothly.

Both fixes are runtime config flips, not algorithm changes. Applied at install,
re-applied on a 250 ms / 1.5 s timer, and reasserted each `updateGame` tick.

## Console checks after deploy

```js
noMoonCurrentSelfTest()  // → ok: true
noMoonV231SelfTest()     // → ok: true; mobileAmbientSkip: false; hazardLanguage: false
noMoonV231Debug()
noMoonSetLowFx(true)     // force low-FX manually (provided by v230 layer)
```

## Stack

v99 (base) → no-moon-rebuilt (consolidated patch) → v230 (Firefox obstacle ring stabilizer) → v231 (this).
