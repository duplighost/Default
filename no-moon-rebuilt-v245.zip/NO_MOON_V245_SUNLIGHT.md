# No Moon v245 — Sunlight floor system takeover

Build tag: qual.v245-sunlight-takeover.2026-05-19.v245
SW cache:  no-moon-v245-sunlight-takeover-v245

## What this fixes

Engine sunlight system was split-brain: TWO heat systems write the same
state._v77SunHeat variable, with different rules:
- v39 updateLightBurn39 (:26974): brightness-gated drain/build
- SunRoute.tickHeat (:53499): brightness-ignoring constant build

Plus:
- v77DrawSunHeatMeter (:43557) gated draw on heat>0.02 — meter rarely
  visible because the two systems' tug-of-war pulls heat below threshold
- inShadow39 ellipse test (:26542) silently failed on bad rx/ry data

## How v245 fixes it

Parallel exposure tracker that drives state._v77SunHeat each tick:
- In v39 moon-path rooms (_v39MoonPathRoom || _v39SunThrone):
  - shaded → exposure drains 1.5/sec
  - not shaded → exposure grows 0.5/sec (regardless of brightness phase)
  - reaches 1 → damagePlayer(1), reset to 0.38, 1.5s lockout
- Shares lockout with SunRoute's _nmSunDamageCd to prevent double-fire
- Sets heat=0 after damage to block v39's bright-phase damage gate
- Hardened shadow check SKIPS patches with missing rx/ry (instead of
  defaulting to 1x1 ellipse)
- Meter wrap forces heat to 0.025 minimum so the meter is always visible
  in moon-path rooms

## Acknowledged limitations

- Cannot disable v39 or SunRoute from outside (both closure-scoped).
  My approach is to overwrite heat each tick and share lockout, which
  works for most cases but in heavy bright phases v39 may still fire
  damage of its own once per cycle. If user reports excessive damage,
  follow-up patch will need an internal architectural fix.

## Verification

  noMoonV245SelfTest()    // ok: true
  noMoonV245Debug()       // sun.exposure climbs, stats.burns increments
  noMoonV243SelfTest()    // still ok

Manual:
1. Enter a moon-path floor (False Dawn / Argument / Sun Throne).
2. Meter visible immediately, fills over ~2s.
3. At 2s exposure → 1 HP damage, meter resets.
4. Step into a shadow patch — meter drains.
5. Sun Throne: same behavior applies during the boss fight.
   If too punishing, v246 will scope sunlight off during boss.
